<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Service extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('categories');
		$this->load->model('services');
	}

	public function index() {
		redirect('service/add');
	}

	public function add() {
		$data['modules'] = array('setup/addservice');
		$data['services'] = $this->services->fetchAllServices();
		$data['categories'] = $this->categories->fetchAllCategories();

		$this->load->view('template/header');
		$this->load->view('setup/addservice', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxServiceId() {
		$result = $this->services->getMaxServiceId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function saveService() {

	// 	if (isset($_POST)) {

	// 		$service = $_POST['service'];
	// 		$result = $this->services->saveService( $service );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetchService() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->services->fetchService($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllServices() {

		$result = $this->services->fetchAllServices();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function saveService() {

		if (isset($_POST)) {

			$service = $_POST['service'];
			//$error    = $this->services->isServiceAlreadyExist($service);

			//if (!$error) {
					$result = $this->services->saveService( $service );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
					}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			// } else {
			// 	$this->output
			// 		 ->set_content_type('application/json')
			// 		 ->set_output(json_encode('duplicate'));
			// }
		}
	}

}

/* End of file service.php */
/* Location: ./application/controllers/service.php */