<?php 

/**
*  Reports
*/
class Report_all extends CI_Controller
{
	
	public function Report_all()
	{
		parent::__Construct();
		$this->load->model('minibars');
		$this->load->model('reportalls');
		$this->load->model('accounts');
		$this->load->model('items');
		$this->load->model('departments');
		$this->load->model('rooms');
		$this->load->model('categories');
		$this->load->model('types');
		$this->load->model('checkins');
		$this->load->model('Checkouts');
		$this->load->model('reservations');
		$this->load->model('reportcheckins');
		$this->load->model('reportcheckouts');
		$this->load->model('reportreservations');
		$this->load->model('reportbanquets');
		$this->load->model('halls');
		$this->load->model('events');
		$this->load->model('users');
		$this->load->model('levels');
		$this->load->model('companies');
		$this->load->model('reportbanquetreservation');
	}
	public function index()
	{
		/*$data['modules']= array('report/reportall');

		$data['roomboys']=$this->minibars->get_roomboy();
		$data['items']=$this->minibars->get_item();
		$data['categories'] = $this->items->fetchByCol('catagory');
		$data['subcategories'] = $this->items->fetchByCol('sub_catagory');
		$data['brands'] = $this->items->fetchByCol('brand');
		$data['years']=$this->minibars->getyear();
		$data['users']=$this->minibars->getuser();
		$data['users']=$this->minibars->getuser();


		$this->load->view('template/header');
		$this->load->view('reports/reportall_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);*/
	}
	public function minibar_report()
	{
		$data['modules']= array('report/reportall');

		$data['roomboys']=$this->minibars->get_roomboy();
		$data['items']=$this->minibars->get_item();
		$data['categories'] = $this->items->getItemCategory('itemcategory');
		$data['subcategories'] = $this->items->getItemSubCategory('itemsubcategory');
		$data['brands'] = $this->items->getItemBrand('brand');
		$data['years']=$this->minibars->getyear();
		$data['users']=$this->minibars->getuser();
		$data['roomnos']=$this->minibars->getroomno();
		$data['etype']='Minibar';


		$this->load->view('template/header');
		$this->load->view('reports/reportall_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function laundry_report()
	{
		$data['modules']= array('report/reportall');

		$data['roomboys']=$this->minibars->get_roomboy();
		$data['items']=$this->minibars->get_item();
		$data['categories'] = $this->items->fetchByCol('catagory');
		$data['subcategories'] = $this->items->fetchByCol('sub_catagory');
		$data['brands'] = $this->items->fetchByCol('brand');
		$data['years']=$this->minibars->getyear();
		$data['users']=$this->minibars->getuser();
		$data['roomnos']=$this->minibars->getroomno();
		$data['etype']='Laundry';


		$this->load->view('template/header');
		$this->load->view('reports/reportall_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function food_report()
	{
		$data['modules']= array('report/reportall');

		$data['roomboys']=$this->minibars->get_roomboy();
		$data['items']=$this->minibars->get_item();
		$data['categories'] = $this->items->fetchByCol('catagory');
		$data['subcategories'] = $this->items->fetchByCol('sub_catagory');
		$data['brands'] = $this->items->fetchByCol('brand');
		$data['years']=$this->minibars->getyear();
		$data['users']=$this->minibars->getuser();
		$data['roomnos']=$this->minibars->getroomno();
		$data['etype']='Food';


		$this->load->view('template/header');
		$this->load->view('reports/reportall_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function miscalenious_report()
	{
		$data['modules']= array('report/reportall');

		$data['roomboys']=$this->minibars->get_roomboy();
		$data['items']=$this->minibars->get_item();
		$data['categories'] = $this->items->fetchByCol('catagory');
		$data['subcategories'] = $this->items->fetchByCol('sub_catagory');
		$data['brands'] = $this->items->fetchByCol('brand');
		$data['years']=$this->minibars->getyear();
		$data['users']=$this->minibars->getuser();
		$data['roomnos']=$this->minibars->getroomno();
		$data['etype']='Miscalenious';


		$this->load->view('template/header');
		$this->load->view('reports/reportall_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function checkin_report()
	{
		$data['modules']= array('report/reportcheckin');

		$data['roomnos'] = $this->rooms->fetchAllRoom();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['years']=$this->checkins->getyear();
		$data['users']=$this->minibars->getuser();

		$this->load->view('template/header');
		$this->load->view('reports/reportcheckin_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function checkout_report()
	{
		$data['modules']= array('report/reportcheckout');

		$data['roomnos'] = $this->rooms->fetchAllRoom();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['customers'] = $this->accounts->fetchAll();
		$data['years']=$this->Checkouts->getyear();
		$data['users']=$this->minibars->getuser();

		$this->load->view('template/header');
		$this->load->view('reports/reportcheckout_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function reservation_report()
	{
		$data['modules']= array('report/reportreservation');

		$data['categories'] = $this->categories->fetchAllCategories();
		$data['types'] = $this->types->fetchAllTypes();
		$data['roomnos'] = $this->rooms->fetchAllRoom();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['companys'] = $this->accounts->fetchAll();
		$data['years']=$this->Checkouts->getyear();
		$data['users']=$this->minibars->getuser();

		$this->load->view('template/header');
		$this->load->view('reports/reportreservation_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function banquets_report()
	{
		$data['modules']= array('report/reportBanquet');

		$data['hall'] = $this->halls->fetchAllHalls();
		$data['event'] = $this->events->fetchAllEvents();
		$data['roomnos'] = $this->rooms->fetchAllRoom();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['companys'] = $this->accounts->fetchAll();
		$data['years']=$this->Checkouts->getyear();
		$data['users']=$this->minibars->getuser();

		$this->load->view('template/header');
		$this->load->view('reports/banquetReports_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function accounts()
	{
		$data['modules'] = array('reports/accounts/accounts_reports');

		// Advanced
		$data['parties'] = $this->accounts->fetchAll(1);
		$data['departments'] = $this->departments->fetchAllDepartments();
		$data['items'] = $this->items->fetchAll(1);
		$data['userone'] = $this->users->fetchAll();

		// ENd Advanced
		// Advanced Item
			$data['categories'] = $this->items->fetchAllCategories('catagory');
			$data['subcategories'] = $this->items->fetchAllSubCategories('sub_catagory');
			$data['brands'] = $this->items->fetchAllBrands();
			$data['uoms'] = $this->items->fetchByCol('uom');
		// End Advanced Item
		// Advanced Account
			$data['cities'] = $this->accounts->getDistinctFields('city');
			$data['cityareas'] = $this->accounts->getDistinctFields('cityarea');
			$data['l1s'] = $this->levels->fetchAllLevel1();
			$data['l2s'] = $this->levels->fetchAllLevel2();
			$data['l3s'] = $this->levels->fetchAllLevel3();
		// End Advanced Account

		$this->load->view('template/header');
		$this->load->view('reports/accounts/accounts',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}
	public function banquets_reservation_report()
	{
		$data['modules']= array('report/reportBanquetReservation');

		$data['hall'] = $this->halls->fetchAllHalls();
		$data['event'] = $this->events->fetchAllEvents();
		$data['roomnos'] = $this->rooms->fetchAllRoom();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['companys'] = $this->accounts->fetchAll();
		$data['years']=$this->Checkouts->getyear();
		$data['users']=$this->minibars->getuser();

		$this->load->view('template/header');
		$this->load->view('reports/banquetReservationReports_view',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}

	public function fetchallReportData()
	{
		$what = $this->input->post('what');
		$startDate = $this->input->post('from');
		$endDate = $this->input->post('to');
		$type = $this->input->post('type');
		$crit = $this->input->post('crit');
		$check = $this->input->post('check');
		$etype = $this->input->post('etype');


		$data=$this->reportalls->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchcheckinReportData()
	{
		$what = $this->input->post('what');
		$startDate = $this->input->post('from');
		$endDate = $this->input->post('to');
		$type = $this->input->post('type');
		$crit = $this->input->post('crit');
		$check = $this->input->post('check');
		$etype = $this->input->post('etype');


		$data=$this->reportcheckins->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchcheckoutReportData()
	{
		$what = $this->input->post('what');
		$startDate = $this->input->post('from');
		$endDate = $this->input->post('to');
		$type = $this->input->post('type');
		$crit = $this->input->post('crit');
		$check = $this->input->post('check');
		$etype = $this->input->post('etype');


		$data=$this->reportcheckouts->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function accountLedger() {
		
 		$data['modules'] = array('reports/accounts/accountledger');
 		$data['parties'] = $this->accounts->fetchAll();
 		
		$this->load->view('template/header');

		$this->load->view('reports/accounts/accountledger', $data);

		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
 	}
	public function fetchreservationReportData()
	{
		$what = $this->input->post('what');
		$startDate = $this->input->post('from');
		$endDate = $this->input->post('to');
		$type = $this->input->post('type');
		$crit = $this->input->post('crit');
		$check = $this->input->post('check');
		$etype = $this->input->post('etype');


		$data=$this->reportreservations->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchBanquetReportData()
	{
		$what 		= $this->input->post('what');
		$startDate 	= $this->input->post('from');
		$endDate 	= $this->input->post('to');
		$type 		= $this->input->post('type');
		$crit 		= $this->input->post('crit');
		$check 		= $this->input->post('check');
		$etype 		= $this->input->post('etype');

		$data=$this->reportbanquets->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function loadreport()
	{
		//$this->load->view('header_view');
		
		$this->load->view('reports/vreportall_view');
		//$this->load->view('footer_view');
	}
	////////////////////////////////chart functions/////////////////////////////////////////////
	public function loadchart()
	{
		//$this->load->view('header_view');
		
		$this->load->view('reports/vchart_view');
		//$this->load->view('footer_view');
	}
	public function fetchallChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];
		$etype = $_POST['etype'];

		if($data=$this->reportalls->fetch_chartdata($startDate,$endDate,$what,$crit,$check,$etype)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchcheckinChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];

		if($data=$this->reportcheckins->fetch_chartdata($startDate,$endDate,$what,$crit,$check)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function chartOfAccounts()
	{
		unauth_secure();
		$data['modules'] = array('reports/accounts/chartofaccounts');
		$this->load->view('template/header');
		$this->load->view('reports/accounts/chartofaccounts');
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

		public function profitloss()
	{
		$data['modules'] = array('reports/accounts/profitloss_report');
		$this->load->view('template/header');
		$this->load->view('reports/accounts/profitloss');
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}
	public function agingSheet()
	{
		// Redirect if unauthorized user.
		unauth_secure();
		
		$data['modules'] = array('reports/accounts/agingsheet');
		// $data['modules'] = array('reports/inventory/stock');
		$data['parties'] = $this->accounts->fetchAll(1);
		$data['currdate'] = date("Y/m/d");
		$data['l3sDebitors'] = $this->levels->fetchAllLevel3_crit('DEBTORS');
		$data['l3sCreditors'] = $this->levels->fetchAllLevel3_crit('CREDITORS');

		$data['wrapper_class'] = "account_ledger";
		$data['page'] = "accountledger";

		$data['companies'] = $this->companies->getAll();

		$this->load->view('template/header');
		$this->load->view('reports/accounts/agingsheet',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);

		// $this->load->view('template/head', $data);
		// $this->load->view('template/navigation', $data);
		// $this->load->view('agingsheet');
		// $this->load->view('template/foot');
	}
		public function cheques()
	{
		unauth_secure();
		$data['modules'] = array('reports/accounts/chequesReport');
		$this->load->view('template/header');
		$this->load->view('reports/accounts/cheques');
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}
	public function fetchcheckoutChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];

		if($data=$this->reportcheckouts->fetch_chartdata($startDate,$endDate,$what,$crit,$check)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchreservationChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];

		if($data=$this->reportreservations->fetch_chartdata($startDate,$endDate,$what,$crit,$check)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchBanquetChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];

		if($data=$this->reportbanquets->fetch_chartdata($startDate,$endDate,$what,$crit,$check)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function detailedprofitloss()
	{
		// Redirect if unauthorized user.
		unauth_secure();
		// if ($this->session->userdata('viewProfitLoss') === 'false'){
		// 	return;
		// }

		$data['wrapper_class'] = "profitloss";
		$data['page'] = "profitloss";

		$data['currdate'] = date("Y/m/d");
		
		$data['modules'] = array('reports/accounts/detailed_profitloss_report');

		$data['parties'] = $this->accounts->fetchAll();
		$data['items'] = $this->items->fetchAll();
		$data['companies'] = $this->companies->getAll();

		$this->load->view('template/header', $data);
		$this->load->view('template/mainnav', $data);
		$this->load->view('reports/accounts/detailedprofitloss', $data);
		$this->load->view('template/footer');
	}

	public function invoiceAging()
	{
		// Redirect if unauthorized user.
		unauth_secure();
		
		$data['modules'] = array('reports/accounts/invoiceaging');
		// $data['modules'] = array('reports/inventory/stock');
		$data['parties'] = $this->accounts->fetchAll(1);
		$data['currdate'] = date("Y/m/d");
		// $data['l3sDebitors'] = $this->levels->fetchAllLevel3_crit('DEBTORS');
		// $data['l3sCreditors'] = $this->levels->fetchAllLevel3_crit('CREDITORS');

		$data['wrapper_class'] = "invoiceAgingSheet";
		$data['page'] = "invoiceAgingSheet";

		$data['companies'] = $this->companies->getAll();

		$this->load->view('template/header');
		$this->load->view('reports/accounts/invoiceaging',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);

		// $this->load->view('template/head', $data);
		// $this->load->view('template/navigation', $data);
		// $this->load->view('agingsheet');
		// $this->load->view('template/foot');
	}
	public function fetchBanquetReservationChartData()
	{
		$what = $_POST['what'];
		$startDate = $_POST['from'];
		$endDate = $_POST['to'];
		$crit = $_POST['crit'];
		$check = $_POST['check'];

		if($data=$this->reportbanquetreservation->fetch_chartdata($startDate,$endDate,$what,$crit,$check)){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='false';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
	public function fetchBanquetReservationReportData()
	{
		$what 		= $this->input->post('what');
		$startDate 	= $this->input->post('from');
		$endDate 	= $this->input->post('to');
		$type 		= $this->input->post('type');
		$crit 		= $this->input->post('crit');
		$check 		= $this->input->post('check');
		$etype 		= $this->input->post('etype');

		$data=$this->reportbanquetreservation->fetchdata($startDate,$endDate,$what,$type,$crit,$check,$etype);

		if($data!='false'){
					
			$this->output->set_content_type('application/json')->set_output(json_encode($data));					
		} else {
			$res='falsess';
			$this->output->set_content_type('application/json')->set_output(json_encode($res));					
		}
	}
}
?>