<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Banquetinquiry extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('banquetinquirys');
        $this->load->model('minibarlists');
        $this->load->model('events');
        $this->load->model('minibars');
        $this->load->model('halls');
        $this->load->model('waiters');
        $this->load->model('rooms');
        $this->load->model('categories');
        $this->load->model('accounts');
        $this->load->model('types');
        $this->load->model('reservations');
        $this->load->model('levels');

    }

    public function index()
    {
        redirect('Banquetinquiry/add');
    }

    public function add()
    {
        $data['modules']        = array('banquet/banquetinquiry');
        $data['halls']          = $this->halls->fetchAllhalls();
        $data['waiters']        = $this->waiters->fetchAll();
        $data['rooms']          = $this->rooms->fetchAllRooms();
        $data['particulars']    = $this->minibars->fetchParticularsAll();
        $data['guests']         = $this->reservations->fetchallGuest();
        $data['allRoomServiceLists'] = $this->minibarlists->fetch_model();
        $data['waiters']        = $this->waiters->fetchAll();
        $data['rooms']          = $this->rooms->fetchAllRooms();
        $data['categories']     = $this->categories->fetchAllCategories();
        // $data['particulars'] = $this->minibars->fetchParticularsAll();
        $data['types']          = $this->types->fetchAllTypes();
        $data['guests']         = $this->reservations->fetchallGuest();
        $data['accounts']       = $this->accounts->fetchAll();
        // Accounts Modal
        $data['names']          = $this->accounts->getDistinctFields('name');
        $data['countries']      = $this->accounts->getDistinctFields('country');
        $data['cities']         = $this->accounts->getDistinctFields('city');
        $data['cityareas']      = $this->accounts->getDistinctFields('cityarea');
        $data['l3s']            = $this->levels->fetchAllLevel3();
        $data['parties']        = $this->accounts->fetchAll();
        $data['guestss']        = $this->reservations->fetchallGuest();
        $data['guestss']        = $this->reservations->fetchallGuest();
        $data['products']       = $this->banquetinquirys->getProducts();
        $data['menu_products']  = $this->banquetinquirys->getMenuProducts();
        $data['events']         = $this->events->fetchAllEvents();

        // $data['particulars'] = $this->minibars->fetchParticularsAll();
        $this->load->view('template/header');
        $this->load->view('banquet/banquetinquiry', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer');
    }

    function save()
    {
        if (isset($_POST))
        {
            $savebanquetInquiry = $_POST['savebanquetInquiry'];
            $savebanquetdetail = $_POST['savebanquetdetail'];
            $saveMenuDetail = $_POST['savemenudetail'];

            $error = $this->banquetinquirys->isHallAlreadyReserved($savebanquetInquiry);
            if ($error == 'false')
            {
                $result = $this->banquetinquirys->save($savebanquetInquiry, $savebanquetdetail, $saveMenuDetail);
                $response = array();
                if ($result === false)
                {
                    $response['error'] = 'true';
                }
                else
                {
                    $response['error'] = 'false';
                }
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
            }
            else
            {
                $this->output->set_content_type('application/json')->set_output(json_encode('duplicate'));
            }
        }
    }

    function saveGuest()
    {
        if (isset($_POST))
        {
            $saveGuestM = $_POST['saveGuestM'];
            $result = $this->banquetinquirys->saveGuest($saveGuestM);
            $response = array();
            if ($result === false)
            {
                $response['error'] = 'true';
            }
            else
            {
                $response['error'] = 'false';
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function saveAccounts()
    {
        if (isset($_POST))
        {
            $accountDetail = $_POST['accountDetail'];
            $accountDetail['account_id'] = $this->levels->genAccStr($accountDetail['level3']);
            $result = $this->accounts->save($accountDetail);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response['error'] = false;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function getMaxId()
    {
        $maxId = $this->banquetinquirys->getMaxId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    public function getMaxgId()
    {
        $maxId = $this->banquetinquirys->getMaxgId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    function fetch_Enter()
    {
        $vrno = $_POST['vrno'];
        $data = $this->banquetinquirys->fetch_Enter($vrno);
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    function fetch_guesttbl()
    {
        $gid = $_POST['gid'];
        $data = $this->banquetinquirys->fetch_guesttbl($gid);
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    public function delete()
    {
        if (isset($_POST))
        {
            $id = $_POST['id'];
            $result = $this->banquetinquirys->delete($id);

            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }
}