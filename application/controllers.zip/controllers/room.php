<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Room extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('categories');
		$this->load->model('types');
		$this->load->model('rooms');
	}

	public function index() {
		redirect('room/add');
	}

	public function getMaxId() {
		$maxId = $this->rooms->getMaxId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($maxId));
	}

	public function add() {
		$data['modules'] = array('setup/addroom');
		$data['categories'] = $this->categories->fetchAllCategories();
		$data['types'] = $this->types->fetchAllTypes();
		$data['floors'] = $this->rooms->fetchAllFloor();
		$data['status'] = $this->rooms->fetchAllRoomStatus();
		$data['rooms'] = $this->rooms->fetchAllRooms();

		$this->load->view('template/header');
		$this->load->view('setup/addroom', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function saveRoom() {

		if (isset($_POST)) {

			$room = $_POST['room'];
			$error    = $this->rooms->isRoomAlreadyExist($room);
				if (!$error) {
					$result = $this->rooms->saveRoom( $room );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}


	public function fetchRoom() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->rooms->fetchRoom($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetchRoomNotReserved() {

		if (isset( $_POST )) {

			$roomno 	 = $_POST['id'];
			$arrivaldate = $_POST['arrivaldate'];
			$departdate	 = $_POST['departdate'];
			$result 	 = $this->rooms->fetchRoomNotReserved($roomno,$arrivaldate,$departdate);

			$response = "";
			if ( $result == false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllrooms() {

		$result = $this->rooms->fetchAllrooms();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function saveCat(){
		if (isset($_POST)) {

			$cat    = $_POST['cat'];
			$error    = $this->categories->isCategoryAlreadyExist($cat);

				if (!$error) {
					$result = $this->categories->saveCat( $cat );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}
	public function saveType(){
		if (isset($_POST)) {

			$type    = $_POST['type'];
			$error    = $this->types->isTypeAlreadyExist($type);

				if (!$error) {
					$result = $this->types->savetypes( $type );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

	public function fetchRoomByCategory(){
		if (isset( $_POST )) {

			$catid = $_POST['catid'];
			$result = $this->rooms->fetchRoomByCategory($catid);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetchRoomByCategoryForcheckin(){
		if (isset( $_POST )) {

			$catid = $_POST['catid'];
			$result = $this->rooms->fetchRoomByCategoryForcheckin($catid);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */