<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Minibar extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('postingdates');
		$this->load->model('waiters');
		$this->load->model('accounts');
		$this->load->model('rooms');
		$this->load->model('minibars');
		$this->load->model('reservations');

	}

	public function index() {
		redirect('minibar/add');
	}



	public function add() {
		$data['modules'] 	 = array('roomservices/minibar');
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticulars('Minibar');
		$data['rooms'] 	 	 = $this->rooms->fetchCheckinRoooms();
		$data['roomss'] = $this->rooms->fetchCheckinRooomWithGuest();
		$data['guests'] 	 = $this->minibars->fetchallGuest();
		$data['guest'] 		= $this->minibars->fetchallGuests();
		$data['vrdate']   = $this->postingdates->fetchPostingdate();
		$data['setting_configur'] = $this->accounts->getsetting_configur();
		$data['etype'] 	 	 = 'MiniBar';

		$this->load->view('template/header');
		$this->load->view('roomservices/minibar',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}

	public function addlaundry() {
		$data['modules'] 	 = array('roomservices/minibar');
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticulars('Laundry');
		$data['rooms'] 	 	 = $this->rooms->fetchCheckinRoooms();
		$data['roomss'] 	 = $this->rooms->fetchCheckinRooom();
		$data['guests'] 	 = $this->minibars->fetchallGuest();
		$data['guest'] 		 = $this->minibars->fetchallGuests();
		$data['vrdate']   	 = $this->postingdates->fetchPostingdate();
		$data['setting_configur'] = $this->accounts->getsetting_configur();
		$data['etype'] 	 	 = 'Laundry';

		$this->load->view('template/header');
		$this->load->view('roomservices/minibar',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}
	public function addfood() {
		$data['modules'] 	 = array('roomservices/minibar');
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticulars('Food');
		$data['rooms'] 	 	 = $this->rooms->fetchCheckinRoooms();
		$data['roomss'] = $this->rooms->fetchCheckinRooom();
		$data['guests'] 	 = $this->minibars->fetchallGuest();
		$data['guest'] 		= $this->minibars->fetchallGuests();
		$data['vrdate']   = $this->postingdates->fetchPostingdate();
		$data['setting_configur'] = $this->accounts->getsetting_configur();
		$data['etype'] 	 	 = 'Food';

		$this->load->view('template/header');
		$this->load->view('roomservices/minibar',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}
	public function addmiscalenious() {
		$data['modules'] 	 = array('roomservices/minibar');
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticulars('Miscalenious');
		$data['rooms'] 	 	 = $this->rooms->fetchCheckinRoooms();
		$data['roomss'] = $this->rooms->fetchCheckinRooom();
		$data['guests'] 	 = $this->minibars->fetchallGuest();
		$data['guest'] 		= $this->minibars->fetchallGuests();
		$data['vrdate']   = $this->postingdates->fetchPostingdate();
		$data['setting_configur'] = $this->accounts->getsetting_configur();
		$data['etype'] 	 	 = 'Miscalenious';

		$this->load->view('template/header');
		$this->load->view('roomservices/minibar',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}
	function save()
	{
		if (isset($_POST)) {
			
			$saveMain 		= $_POST['saveMain'];
			$saveDetail 	= $_POST['saveDetail'];
			$etype  		= $_POST['etype'];
			$dcno 			= $_POST['vrnoa'];
            $ledger 		= $_POST['ledger'];
            $voucher_type_hidden = $_POST['voucher_type_hidden'];

            $result 		= $this->ledgers->save($ledger, $dcno, $etype ,$voucher_type_hidden);
			$result 		= $this->minibars->save($saveMain,$saveDetail,$etype);

			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response['error'] = 'false';
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	function savephoneslip()
	{
		if (isset($_POST)) {
			
			$saveMain 		= $_POST['saveMain'];
			//$saveDetail 	= $_POST['saveDetail'];
			$etype  		= $_POST['etype'];
			$dcno 			= $_POST['vrnoa'];
            $ledger 		= $_POST['ledger'];
            $voucher_type_hidden = $_POST['voucher_type_hidden'];

            $result 		= $this->ledgers->save($ledger, $dcno, $etype ,$voucher_type_hidden);
			$result 		= $this->minibars->savephoneslip($saveMain,$etype);


			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response['error'] = 'false';
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function getMaxId() {
		$etype  		= $_POST['etype'];


		$maxId = $this->minibars->getMaxId($etype) + 1;
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($maxId));
	}
	function fetch_Enter(){
		$vrno 	= $_POST['vrno'];
		$etype 	= $_POST['etype'];
		$data 	= $this->minibars->fetch_Enter($vrno,$etype);
		$response = "";
			if ( $data === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}

	function fetch_telephoneslip(){
		$vrno 	= $_POST['vrno'];
		$etype 	= $_POST['etype'];
		$data 	= $this->minibars->fetch_telephoneslip($vrno,$etype);
		$response = "";
			if ( $data === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}

	function fetchGuestName(){
		$roomid 	= $_POST['roomid'];
		$data 	= $this->minibars->fetchGuestName($roomid);
		$response = "";
			if ( $data === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function delete() {

		if (isset( $_POST )) {

			$vrno = $_POST['vrno'];
			$etype = $_POST['etype'];
			$company_id = $_POST['company_id'];
			$result = $this->minibars->delete($vrno,$etype,$company_id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function addPhoneSlip() {
		$data['modules'] 	 = array('roomservices/telephoneslip');
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticulars('misc');
		$data['rooms'] 	 	 = $this->rooms->fetchCheckinRoooms();
		$data['guests'] 	 = $this->minibars->fetchallGuest();
		$data['attention'] 	 = $this->minibars->fetchByCol('attentionmr');
		$data['operator'] 	 = $this->minibars->fetchByCol('operator');
		$data['city'] 	 	 = $this->minibars->fetchByCol('city');
		$data['country'] 	 = $this->minibars->fetchByCol('country');
		$data['vrdate']   	 = $this->postingdates->fetchPostingdate();
		$data['guest'] 		 = $this->minibars->fetchallGuests();
		$data['roomss'] 	 = $this->rooms->fetchCheckinRooomWithGuest();
		$data['setting_configur'] = $this->accounts->getsetting_configur();
		$data['etype'] 	 	 = 'telephoneslip';

		$this->load->view('template/header');
		$this->load->view('roomservices/telephoneslip',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}


	
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */