<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkout extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		$this->load->model('postingdates');
		$this->load->model('accounts');
		$this->load->model('checkouts');
		$this->load->model('waiters');
		$this->load->model('rooms');
		$this->load->model('minibars');
		$this->load->model('checkins');
		$this->load->model('categories');
		$this->load->model('accounts');
		$this->load->model('types');
		$this->load->model('reservations');
		$this->load->model('levels');
		$this->load->model('ledgers');
		
	}

	public function index() {
		redirect('checkout/add');
	}


	public function add() {
		$data['modules'] = array('vouchers/addcheckout');
		$data['parties'] = $this->accounts->fetchAll();
		$data['rooms'] = $this->rooms->fetchCheckinRoooms();
		$data['roomss'] = $this->rooms->fetchCheckinRooom();
		$data['waiters'] 	= $this->waiters->fetchAll();
		$data['categories'] = $this->categories->fetchAllCategories();
		// $data['particulars'] = $this->minibars->fetchParticulars();
		$data['types'] = $this->types->fetchAllTypes();
		$data['guests'] = $this->reservations->fetchallGuest();
		$data['accounts'] = $this->accounts->fetchAll();
		// Accounts Modal
		$data['waiters'] 	 = $this->waiters->fetchAll();
		$data['particulars'] = $this->minibars->fetchParticularsAll();
		$data['guests'] 	 = $this->reservations->fetchallGuest();
		$data['names'] = $this->accounts->getDistinctFields('name');
		$data['countries'] = $this->accounts->getDistinctFields('country');
		$data['cities'] = $this->accounts->getDistinctFields('city');
		$data['guestss'] 	 = $this->reservations->fetchallGuest();
		$data['vrdate']   = $this->postingdates->fetchPostingdate();
		$data['setting_configur'] = $this->accounts->getsetting_configur();

		$this->load->view('template/header');
		$this->load->view('frontoffice/addcheckout',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}
	public function getMaxId() {

		$maxId = $this->checkouts->getMaxId() + 1;
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($maxId));
	}
	public function fetch_Enter() {

		if (isset( $_POST )) {
			$vrno = $_POST['vrno'];
			$result = $this->checkouts->fetch_Enter($vrno,'checkout');

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetchCompelmentary() {

		if (isset( $_POST )) {

			$roomNo = $_POST['roomNo'];
			$vrdate = $_POST['vrdate'];
			$result = $this->checkouts->fetchCompelmentary($roomNo,$vrdate);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetchDatas() {

		if (isset( $_POST )) {
			$checkinid = $_POST['checkinid'];
			$roomNo = $_POST['roomNo'];
			$vrdate = $_POST['vrdate'];
			
			$data['checkins'] 		= $this->checkouts->fetch_checkRoomNo($checkinid);
			$data['complementry']   = $this->checkouts->fetchCompelmentary($roomNo,$vrdate);
			$data['nightdata'] 		= $this->checkouts->fetchNightData($roomNo);

			$response = "";
			if ( $data['nightdata'] === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	
	function save()
	{
		if (isset($_POST)) {
			
			$saveMain 		= $_POST['saveMain'];
			$saveDetail 	= $_POST['saveDetail'];
			$saveCheck  	= $_POST['saveCheck'];
			$dcno 			= $_POST['vrnoa'];
            $ledger 		= $_POST['ledger'];
            $voucher_type_hidden = $_POST['voucher_type_hidden'];

            $result 		= $this->ledgers->save($ledger, $dcno, 'checkout',$voucher_type_hidden);
			$result 		= $this->checkouts->save($saveMain,$saveDetail,$saveCheck);


			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response['error'] = 'false';
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	function fetch_checkRoomNo(){
		$srno 	= $_POST['srno'];
		$data 	= $this->checkouts->fetch_checkRoomNo($srno);
		$response = "";
			if ( $data === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	function fetchNightData(){
		$RoomNo 	= $_POST['RoomNo'];
		$data 	= $this->checkouts->fetchNightData($RoomNo);
		$response = "";
			if ( $data === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}

	public function delete() {

        if (isset( $_POST )) {

            $vrno = $_POST['vrno'];
            $etype = $_POST['etype'];
            $company_id = $_POST['company_id'];
            $result = $this->checkouts->delete($vrno,$etype,$company_id);

            $response = "";
            if ( $result === false ) {
                $response = 'false';
            } else {
                $response = $result;
            }

            $this->output
                 ->set_content_type('application/json')
                 ->set_output(json_encode($response));
        }
    }

	
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */