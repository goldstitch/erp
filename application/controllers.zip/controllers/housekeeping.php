<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Housekeeping extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('postingdates');
        $this->load->model('rooms');
        $this->load->model('accounts');
        $this->load->model('housekeepings');
        $this->load->model('waiters');
    }

    public function index()
    {
        $data['modules'] = array('vouchers/addhousekeeping');
        $data['rooms'] = $this->rooms->getAllDirtyRooms();
        $data['employee'] = $this->waiters->fetchAll();
        $data['status'] = $this->rooms->getAllRoomsStatus();
        $data['vrdate']   = $this->postingdates->fetchPostingdate();

        $this->load->view('template/header');
        $this->load->view('vouchers/addhousekeeping', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer', $data);
    }

    public function employees()
    {
        $result = $this->waiters->fetchAll();

        $response = "";
        if ($result === false) {
            $response = 'false';
        } else {
            $response = $result;
        }

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));

    }

    public function statuss()
    {
        $result = $this->rooms->getAllRoomsStatus();

        $response = "";
        if ($result === false) {
            $response = 'false';
        } else {
            $response = $result;
        }

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));

    }

    public function getMaxHouseKeepingId()
    {
        $result = $this->housekeepings->getMaxSrno() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function showHouseKeeping()
    {
        if (isset($_POST)) {

            $response['rooms'] = $this->rooms->fetchAllRooms();
            $response['acocunts'] = $this->acocunts->fetchAccountByType();

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }

    public function fetchhouseKeeping()
    {
        if (isset($_POST)) {

            $id = $_POST['houseKeepingid'];
            $result = $this->housekeepings->fetchhouseKeepings($id);

            $response = "";
            if ($result === false) {
                $response = 'false';
            } else {
                $response = $result;
            }

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }

    public function save()
    {
        if (isset($_POST)) {

            $obj = $_POST['houseKeeping'];
            $srnoa = $_POST['srnoa'];

            $result = $this->housekeepings->save($obj, $srnoa);
            $response = array();
            if ($result === false) {
                $response['error'] = 'true';
            } else {
                $response = $result;
            }

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }
}