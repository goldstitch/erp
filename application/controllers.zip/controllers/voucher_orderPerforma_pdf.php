<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Fixed Footer</title>

	<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../assets/css/bootstrap-responsive.min.css">
	<link rel="stylesheet" href="../../../assets/bootstrap/css/bootstrap.min.css">

	<style type="text/css">	
		* { margin: 0; padding: 0; font-family: tahoma !important; }
			 body {  margin: 0 !important; font-size:8px !important; }
			 p { margin: 0 !important; /* line-height: 17px !important; */ }
			 .field { font-size:10px !important; font-weight: bold !important; display: inline-block !important; width: 100px !important; } 
			 .field1 { font-size:10px !important; font-weight: bold !important; display: inline-block !important; width: 150px !important; } 
			 .voucher-table{ border-collapse: collapse; }
			 table { width: 100% !important; border: 1px solid black !important; border-collapse:collapse !important; table-layout:fixed !important; margin-left:0px}
			 th {  padding: 5px !important; }
			 td { /*text-align: center !important;*/ vertical-align: top !important;  }
			 td:first-child {  }
			 /*.voucher-table thead th {background: #ccc !important; } */
			 .voucher-table thead th {background: grey; } 
			 tfoot {border-top: 0px solid black !important; } 
			 .bold-td { font-weight: bold !important; border-bottom: 0px solid black !important;}
			 .nettotal { font-weight: bold !important; font-size: 11px !important; border-top: 0px solid black !important; }
			 .invoice-type { border-bottom: 0px solid black !important; }
			 .relative { position: relative !important; }
			 .signature-fields{ font-size: 10px;} 
			 .signature-fields th {border: 0px !important; border-top: 1px solid black !important; border-spacing: 10px !important; }
			 .inv-leftblock { width: 280px !important; }
			 .text-left { text-align: left !important; }
			 .text-centre { text-align: center !important; }
			 .text-right { text-align: right !important; }
			 td {font-size: 9px !important; font-family: tahoma !important; line-height: 10px !important; padding: 4px !important; } 
			 
			 .inwords, .remBalInWords { text-transform: uppercase !important; }
			 .barcode { margin: auto !important; }
			 h3.invoice-type {font-size: 16px !important; line-height: 50px !important;}
			 .extra-detail span { background: #7F83E9 !important; color: white !important; padding: 5px !important; margin-top: 17px !important; display: block !important; margin: 5px 0px !important; font-size: 10px !important; text-transform: uppercase !important; letter-spacing: 1px !important;}
			 .nettotal { color: red !important; font-size: 10px !important;}
			 .remainingBalance { font-weight: bold !important; color: blue !important;}
			 .centered { margin: auto; }
			 p { position: relative !important; font-size: 10px !important; }
			 thead th { font-size: 11px !important; color: black !important; font-weight: bold !important; padding: 10px !important; }
			 .fieldvalue { font-size:10px !important; position: absolute !important; width: 497px !important; }

			 @media print {
			 	.noprint, .noprint * { display: none !important; }
			 }
			 .text-centre{text-align: center !important;}
				
			.barcode { float: right !important; }
			.item-row td { font-size: 10px !important; padding: 10px !important; border-top: 0px solid black !important;}
			.footer_company td { font-size: 8px !important; padding: 10px !important; border-top: 0px solid black !important;}

			.rcpt-header { width: 700px !important; margin: 0px; display: inline;  top: 0px; right: 0px; }
			h3.invoice-type { border: none !important; margin: 0px !important; position: relative !important; top: 34px !important; }
			tfoot tr td { font-size: 10px !important; padding: 10px !important;  }
			.subtotalend { font-size: 10px !important; font-weight: bold !important;text-align: right !important; }
			.nettotal, .subtotal, .vrqty,.vrweight { font-size: 10px !important; font-weight: bold !important;text-align: right !important; color: red;}
			.newtbl tbody tr td{border:1px solid black !important;}
			.header_tbl{border: none !important; padding-left:0px !important; }
			.header{border: 1px solid black;}
			/*.voucher-table tbody tr td{border-right: 1px solid black !important; }
			.voucher-table tfoot tr td{border-right: 1px solid black !important; }*/
			/*.voucher-table{border: }*/
			.row-bank{width: 100%;margin-bottom: 8px !important;}
			/*.bank_detail{width: 50%;border: 1px solid black;}*/
			.bank_detail{width: 100%; position: relative !important:;}

			/* Report Fixed Footer */
			#footer{
				position:fixed !important;
				left:0px;
				bottom:-50px !important;
				margin-top: 50 !important;
				width:100%;
				background:white;
				line-height:25px;
				color:black;
				font-size:8px;
			}
			#footer span{padding-left:20px;}
			#footer p{padding: 0px 0px 0px 0px;  }
			

			/*#footerUpper{
				position:fixed;
				left:0px;
				bottom:0px;
				width:100%;
				background:white;
				line-height:30px;
				color:black;
				font-size:10px;
				line-height: 25px;
			}
			#footerUpper p{padding: 0px 0px 0px 0px;  }*/

		</style>
	</head>
	<body>
		<div class="container-fluid">
			<div class="row-fluid" >
				<div class="span12 centered">
					<div class="row-fluid">
						<div class="span12"><img class="rcpt-header" src="<?php echo $header_img;?>" alt=""></div>
						 <!-- <div class="span12"><h3 style="font-size: 16px !important; line-height: 24px !important;" > Hilton Gloves</h3></div> -->
					</div>
					<?php if ($header === 'header'):  ?>

						<div class="row-fluid">
							<div class="span12">
								<table class="header_tbl">
									<thead>
										<tr>
											<th style=" width: 100px; text-align:left; ">CONSIGNEE :</th>
											<td style=" width: 120px; text-align:left; "></td>
											<th style=" width: 200px; text-align:center;background-color:black;color:white !important; ">PROFORMA INVOICE</th>
											<th ></th>
											<th style=" width: 90px; text-align:right; font-size:9px;">PI# </th>
											<th style="text-align:left; font-size:9px;"><?php echo 'HE/'.$vrdetail[0]['vrnoa'] .'/'. substr($vrdetail[0]['vrdate'], 2, 2) . '/'.$vrdetail[0]['party_id'] ;?></th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td style=" width: 220px; text-align:left; font-size:9px;" colspan="4"><?php echo $vrdetail[0]['party_name'];?></td>
											<th style=" width: 90px; text-align:right; font-size:9px;" >PI Date:</th>
											<td style="text-align:left;"><?php echo $vrdetail[0]['vrdate'];?></td>
										</tr>
										<tr>
											<td style="text-align:left; " colspan="2"><?php print nl2br( $vrdetail[0]['party_address'] );?></td>
											<td style=" width: 280px !important; font-size:9px;" colspan="2">Shipment By :<?php echo $vrdetail[0]['transporter_name'];?></td>
											<th style=" width: 90px; text-align:right; font-size:9px;">Payment Terms:</th>
											<td style="text-align:left;"><?php echo $vrdetail[0]['payment_term'];?></td>
										</tr>
							
									</tbody>
								</table>
								
								<!-- <table class="newtbl" style="border:1px solid black !important;"> -->
								<table class="header_tbl">
									<thead>
									</thead>
									<tbody>
										<tr>
											<th style=" width: 100px !important; text-align:left; font-size:9px; ">Shipment From : </th>
											<td><?php echo $vrdetail[0]['shippment_from'];?></td>
											<th  style=" width: 100px !important; text-align:left; font-size:9px;">To : </th>								
											<td style="text-align:left;" ><?php echo $vrdetail[0]['shippment_to'];?></td>								
											<th style=" width: 160px; font-size:9px;" class="text-left" >Export Reg#</th>								
											<td style="text-align:left;" ><?php echo $vrdetail[0]['export_register_no'];?></td>								
										</tr>
										<tr>
											<th style=" width: 100px !important; text-align:left; font-size:9px; ">Currency : </th>
											<td><?php echo $vrdetail[0]['currencey_name'];?></td>
											<th  style=" width: 100px !important; text-align:left; font-size:9px;">Shipment Date:</th>								
											<td style="text-align:left;" ><?php echo substr($vrdetail[0]['bilty_date'],0,10);?></td>								
											<th style=" width: 160px; font-size:9px;" class="text-left" >Delivery Term:</th>								
											<td style="text-align:left;" ><?php echo $vrdetail[0]['delivery_term'];?></td>								
										</tr>
										<tr>
											<th style=" width: 100px !important; text-align:left; font-size:9px; ">Remarks : </th>
											<td colspan="5"><?php echo $vrdetail[0]['remarks'];?></td>
										</tr>
									</tbody>
								</table>
								
							</div>
						</div>
					<?php endif; ?> 
					<br>
					<br>
					<br>
					
					<div class="row-fluid">
						<table class="voucher-table">
							<thead>
								<tr style="">
									<!-- <th style=" width: 10px; " >Sr#</th> -->
									<th style=" width: 40px; text-align:left; color:white !important; ">Marks & Number</th>
									<th style=" width: 100px; text-align:left; color:white !important;">Description of goods</th>
									<th style=" width: 40px; color:white !important; " class='text-right'>Dozen</th>
									<th style=" width: 30px; color:white !important; " class='text-right'>CTN Qty</th>
									<th style=" width: 35px; color:white !important;" class='text-right'>Dzn Price</th>
									<th style=" width: 30px; color:white !important;" class='text-right'>Amount</th>
									<!-- <th style=" width: 30px; " class='text-right'>Amount</th> -->
								</tr>
							</thead>

							<tbody>
								<tr  class="item-row">
									<td class='text-left' colspan="">P.O: <?php echo $vrdetail[0]['cpono']; ?></td>
									<td class='text-left' colspan=""></td>
									<td class='text-left' colspan=""></td>
									<td class='text-left' colspan=""></td>
									<td class='text-left' colspan=""></td>
									<td class='text-left' colspan=""></td>
								</tr>
								
								<?php 
									$serial = 1;
									$netCtn_Qty = 0;
									$netAmount=0;
									$netWeight=0;
									$netCtn_Qty = 0;
									$netDzn_Qty = 0;
									$netAmount=0;
									$netWeight=0;
									$netRate = 0;

									$typee='';
									$typee22='';
									foreach ($vrdetail as $row):
													
												// $typee=$row['type'];
												
								?>
											
									<tr  class="item-row">
									   <td class='text-left'><?php echo $row['artcile_no_cus']; ?></td>
									   <td class='text-left'><?php echo $row['item_desc_cus'];?></td>
									   
									   <td class='text-right'><?php echo number_format(abs($row['dzn_qty']),2);?></td>
									   <td class='text-right'><?php echo number_format(abs($row['ctn_qty']),2);?></td>
									   <td class='text-right'><?php echo number_format(abs($row['frate']),3);?></td>
									   <td class='text-right'><?php echo number_format(($row['lprate_m']!=0 ?$row['amount']/$row['lprate_m']:$row['amount']),2) .' '. $vrdetail[0]['cur_symbol'];?></td>
									   <!-- <td class="text-right"><?php echo number_format(($row['amount']),2);?></td> -->
									</tr>
									
								<?php 
										$netCtn_Qty += abs($row['ctn_qty']);
										$netDzn_Qty += abs($row['dzn_qty']);
										$netRate += abs($row['rate']);
										$netAmount += ($row['lprate_m']!=0 ?$row['amount']/$row['lprate_m']:$row['amount']);
										$netWeight += abs($row['weight']);
								endforeach?>
							</tbody>
							<tfoot>
								<tr class="foot-comments">
									<td class="subtotalend bold-td text-right" colspan="1">H.S Code No: 6116.9200</td>
									<td class="subtotalend bold-td text-right" colspan="1">Subtotal:</td>
									<td class="subtotalend bold-td text-right"><?php echo number_format($netDzn_Qty,2);?></td>
									<td class="subtotalend bold-td text-right"><?php echo number_format($netCtn_Qty,2);?></td>
									<td class="subtotalend bold-td text-right"><?php ?></td>
									<td class="subtotalend bold-td text-right"><?php echo number_format($netAmount,2);?></td>
									<!-- <td class="subtotalend bold-td text-right"><?php echo number_format($netAmount,2);?></td> -->
								</tr>
								
								<?php if(intval($vrdetail[0]['discount'])!=0){?>
								<tr>
									<td class="subtotal bold-td text-right discount-td " colspan="4">Discount:</td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['discp']),2) . '% ';?></td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['discount']),2);?></td>
								</tr>
								<?php }?>
								<?php if(intval($vrdetail[0]['expense'])!=0){?>
								<tr>
									<td class="subtotal bold-td text-right discount-td " colspan="4">Expense:</td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['exppercent']),2) . '% ';?></td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['expense']),2);?></td>
								</tr>
								<?php }?>
								<?php if(intval($vrdetail[0]['tax'])!=0){?>
								<tr>
									<td class="subtotal bold-td text-right discount-td " colspan="4">Tax:</td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['taxpercent']),2) . '% ';?></td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['tax']),2);?></td>
								</tr>
								<?php }?>
								<?php if(intval($vrdetail[0]['paid'])!=0){?>
								<tr>
									<td class="subtotal bold-td text-right discount-td " colspan="4">Advance:</td>
									<td class="subtotal bold-td text-right"><?php ?></td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['paid']),2);?></td>
								</tr>
								<?php }?>
								<?php if(!(intval($vrdetail[0]['tax'])==0 && intval($vrdetail[0]['discount'])==0 && intval($vrdetail[0]['expense'])==0 && intval($vrdetail[0]['paid'])==0) ){?>
								<tr>
									<td class="subtotal bold-td text-right discount-td " colspan="4">Net Amount:</td>
									<td class="subtotal add-lower text-right"></td>
									<td class="subtotal bold-td text-right"><?php echo number_format(($vrdetail[0]['namount']),2) .' '. $vrdetail[0]['cur_symbol'];?></td>
								</tr>
								<?php }?>


							</tfoot>
						</table>
					</div>
					<!-- <div class="row-fluid">
						<div class="span12 add-on-detail1" style="margin-top: 10px;">
							<p class="" style="text-transform1: uppercase;">
								<strong>In words: </strong> <span class="inwords"></span><?php echo $amtInWords;?>ONLY <br>
								<br>
								<?php if ( $pre_bal_print==1  ){?>
									<p><span class="field1">Previous Balance:</span><span class="fieldvalue inv-vrnoa"><?php echo number_format($previousBalance,0);?></span></p>
									<p><span class="field1">This Invoice:</span><span class="fieldvalue inv-date"><?php echo number_format($vrdetail[0]['namount'],0);?></span></p>
									<p><span class="field1">Current Balance:</span><span class="fieldvalue cust-name"><?php echo number_format($vrdetail[0]['namount']+$previousBalance,2) ;?></span></p>
								<?php };?>
							</p>
						</div>
					</div> -->
					<!-- End row-fluid -->
					<br>
					<br>
					 <div class="row-bank">
						<div class="bank_detail">
							<p><?php print nl2br( $vrdetail[0]['bank_detail'] );?></p>
						</div>
					</div>
					
				</div>
			</div>
			
			<!-- <div id="footer1">
		    	<div class="span12">
					<table class="signature-fields">
						<thead>
							<tr>
								<th>Buyer Signature</th>
								<td></td>
								<th>Seller Signature</th>
							</tr>
						</thead>
					</table>
				</div>
			</div> -->

			<div id="footer" style="background:grey !important;">
		    	<div class="span12">
					<table class="signature-fields">
						<thead>
							<tr>
								<th><?php echo $vrdetail[0]['party_name'];?></th>
								<td></td>
								<th>Hilton Enterprises</th>
							</tr>
						</thead>
					</table>
				</div>
		    	<p class="text-centre"><?php print nl2br( $vrdetail[0]['foot_note'] );?></p>
		    	<span class="loggedin_name">User:<?php echo $user;?></span>
				<!-- <span class="website">Sofware By: www.digitalsofts.com, Mob:03218661765</span> -->
			</div>

		</div>
   <!--  <div class="" id="footerUpper">
    		
    </div> -->
    
    
	</body>
</html>
