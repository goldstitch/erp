<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kot extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('items');
		$this->load->model('waiters');
		$this->load->model('tables');
		$this->load->model('voids');
		$this->load->model('orders');
	}

	public function index() {
		redirect('kot/add');
	}

	public function add() {

		$data['modules'] = array('sale/addkot');
		$data['items'] = $this->items->fetchAll();
		$data['waiters'] = $this->waiters->fetchAllActiveWaiters();
		$data['tables'] = $this->tables->fetchAllActiveTables();
		$data['foodtypes'] = $this->orders->fetchByCol('food_type');

		$this->load->view('template/header');
		$this->load->view('sale/addkot', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxVrno() {
		$result = $this->orders->getMaxVrno('kot') + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	public function getMaxOrderno() {
		$result = $this->orders->getMaxOrderno('kot') + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	public function getMaxVrnoa() {
		$result = $this->orders->getMaxVrnoa('kot') + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	public function save() {

		if (isset($_POST)) {

			$kotmain = $_POST['kotmain'];
			$kotdetail = $_POST['kotdetail'];
			$vrnoa = $_POST['vrnoa'];

			$result = $this->orders->save($kotmain, $kotdetail, $vrnoa, 'kot');

			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function void() {

		if (isset($_POST)) {

			$voidmain = $_POST['voidmain'];
			$voiddetail = $_POST['voiddetail'];

			$voidmain['vrno'] = $this->voids->getMaxVrno('kot') + 1;
			$voidmain['vrnoa'] = $this->voids->getMaxVrnoa('kot') + 1;
			$this->voids->save($voidmain, $voiddetail);

			$result = true;
			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($result));
		}
	}

	public function fetchRunningOrders() {

		$result = $this->orders->fetchRunningOrders();
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	public function fetch() {

		if (isset($_POST)) {

			$vrnoa = $_POST['vrnoa'];
			$result = $this->orders->fetchKot($vrnoa);

			$response = array();
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function deleteVoucher() {

		if (isset($_POST)) {

			$vrnoa = $_POST['vrnoa'];
			$etype = $_POST['etype'];
			$result = $this->orders->deleteVoucher($vrnoa, $etype);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = 'true';
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
}

/* End of file kot.php */
/* Location: ./application/controllers/kot.php */