<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Waiter extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('waiters');
	}

	public function index() {
		//unauth_secure();
		
		$data['modules'] = array('setup/addwaiter');
		$data['waiters'] = $this->waiters->fetchAll();

		$this->load->view('template/header');
		$this->load->view('setup/addwaiter', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxId() {
		$result = $this->waiters->getMaxId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function save() {

	// 	if (isset($_POST)) {

	// 		$waiter = $_POST['waiter'];
	// 		$result = $this->waiters->save( $waiter );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetch() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->waiters->fetch($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllActiveWaiters() {

		$result = $this->waiters->fetchAllActiveWaiters();

		$response = "";
		if ( $result === false ) {
			$response = 'false';
		} else {
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function save() {

		if (isset($_POST)) {

			$waiter = $_POST['waiter'];
			$error    = $this->waiters->isWaiterAlreadyExist($waiter);

				if (!$error) {
					$result = $this->waiters->save( $waiter );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

}

/* End of file waiter.php */
/* Location: ./application/controllers/waiter.php */