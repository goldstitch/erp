<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Checkin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('postingdates');
        $this->load->model('accounts');
        $this->load->model('waiters');
        $this->load->model('rooms');
        $this->load->model('minibars');
        $this->load->model('checkins');
        $this->load->model('categories');
        $this->load->model('accounts');
        $this->load->model('types');
        $this->load->model('reservations');
        $this->load->model('levels');
    }

    public function index()
    {
        redirect('checkin/add');
    }

    // Night Posting voucher controll
    public function nightposting()
    {
        $data['modules'] = array('reservation/addnightposting');
        $data['vrdate'] = $this->postingdates->fetchPostingdate();
        $this->load->view('template/header');
        $this->load->view('reservation/nightposting', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer', $data);
    }

    public function fetchNightPosting()
    {
        if (isset($_POST))
        {
            $date  = $_POST['dates'];
            $result = $this->checkins->fetchNightPosting($date);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function checkDateNightPosting()
    {
        if (isset($_POST))
        {
            $dates = $_POST['dates'];
            $vrno = $_POST['vrno'];
            $result = $this->checkins->checkDateNightPosting($dates, $vrno);
            $response = "";
            if ($result === true)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    // End Night Posting
    public function add()
    {
        $data['modules'] = array('vouchers/addcheckin');
        $data['parties'] = $this->accounts->fetchAll();
        //$data['rooms'] = $this->rooms->fetchAllRooms();
        $data['roomss'] = $this->rooms->fetchAllRoom();
        $data['roomsss'] = $this->rooms->fetchAllFreeRooms();
        $data['waiters'] = $this->waiters->fetchAll();
        //$data['rooms'] 	 	= $this->rooms->fetchAllRooms();
        $data['categories'] = $this->categories->fetchAllCategories();
        // $data['particulars'] = $this->minibars->fetchParticulars();
        $data['types'] = $this->types->fetchAllTypes();
        $data['guests'] = $this->reservations->fetchallGuest();
        $data['accounts'] = $this->accounts->fetchAll();
        // Accounts Modal
        $data['waiters'] = $this->waiters->fetchAll();
        $data['particulars'] = $this->minibars->fetchParticularsAll();
        $data['rooms'] = $this->rooms->fetchAllRooms();
        //$data['guests'] 	 = $this->reservations->fetchallGuest();
        $data['names'] = $this->accounts->getDistinctFields('name');
        $data['countries'] = $this->accounts->getDistinctFields('country');
        $data['cities'] = $this->accounts->getDistinctFields('city');
        $data['guestss'] = $this->reservations->fetchallGuest();
        $data['l3s'] = $this->levels->fetchAllLevel3();
        $data['vrdate'] = $this->postingdates->fetchPostingdate();
        $data['setting_configur'] = $this->accounts->getsetting_configur();
        $this->load->view('template/header');
        $this->load->view('frontoffice/addcheckin', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer', $data);
    }

    public function getMaxId()
    {
        $result = $this->checkins->getMaxId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getMaxIdPosting()
    {
        $result = $this->checkins->getMaxIdgetMaxIdPosting() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function saveCheckin()
    {
        if (isset($_POST))
        {
            $checkin = $_POST['checkin'];
            $dcno = $_POST['id'];
            $ledger = $_POST['ledger'];
            $saveGuest = $_POST['saveGuest'];
            $arrivalDate = $this->input->post('arrival_date');
            $departureDate = $this->input->post('departure_date');
            $voucher_type_hidden = $_POST['voucher_type_hidden'];
            $error = $this->checkins->isRoomAvailable($checkin, $arrivalDate, $departureDate);
            if ($error == 'free')
            {   
                if($ledger != '')
                $result = $this->ledgers->save($ledger, $dcno, 'checkin',$voucher_type_hidden);
                $result = $this->checkins->saveCheckin($checkin, $saveGuest, $arrivalDate, $departureDate);
                $response = array();
                if ($result === false)
                {
                    $response['error'] = true;
                }
                else
                {
                    $response['error'] = false;
                }
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
            }
            else
            {
                $response['error'] = $error;
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
            }
        }
    }

    public function fetchRoomAvailability()
    {
        if (isset($_POST))
        {
            $checkin = $_POST['checkin'];
            $checkout = $_POST['checkout'];
            $result = $this->checkins->fetchRoomAvailability($checkin, $checkout);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function savePosting()
    {
        if (isset($_POST))
        {
            $saveDetail = $_POST['saveDetail'];
            // $saveMain 		= $_POST['saveMain'];
            // $result = $this->checkins->savePosting( $saveMain,$saveDetail );
            $result = $this->checkins->savePosting($saveDetail);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response['error'] = false;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function fetchCheckin()
    {
        if (isset($_POST))
        {
            $id = $_POST['id'];
            $result = $this->checkins->fetchCheckin($id);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function fetch_EnterPosting()
    {
        if (isset($_POST))
        {
            $vrno = $_POST['vrno'];
            $result = $this->checkins->fetch_EnterPosting($vrno);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function deleteCheckin()
    {
        if (isset($_POST))
        {
            $id = $_POST['id'];
            $company_id = $_POST['company_id'];
            $result = $this->checkins->deleteCheckin($id , $company_id);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function deletePosting()
    {
        if (isset($_POST))
        {
            $vrno = $_POST['vrno'];
            $result = $this->checkins->deletePosting($vrno);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }
}