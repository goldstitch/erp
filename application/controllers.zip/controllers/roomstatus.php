<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Roomstatus extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
	}

	public function index() {
		redirect('roomstatus/add');
	}


	public function add() {
		$this->load->view('template/header');
		$this->load->view('frontoffice/roomstatus');
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}

	
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */