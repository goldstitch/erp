<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Type extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('types');
	}

	public function index() {
		redirect('type/add');
	}

	public function add() {
		$data['modules'] = array('setup/addtype');
		$data['types'] = $this->types->fetchAllTypes();

		$this->load->view('template/header');
		$this->load->view('setup/addtype', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxTypeId() {
		$result = $this->types->getMaxTypeId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function saveType() {

	// 	if (isset($_POST)) {

	// 		$type = $_POST['type'];
	// 		$result = $this->types->saveType( $type );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetchType() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->types->fetchType($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllTypes() {

		$result = $this->types->fetchAllTypes();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function saveType() {

		if (isset($_POST)) {

			$type = $_POST['type'];
			$error    = $this->types->isTypeAlreadyExists($type);

				if (!$error) {
					$result = $this->types->saveType( $type );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

}

/* End of file type.php */
/* Location: ./application/controllers/type.php */