<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Roomtransfer extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('postingdates');
		$this->load->model('accounts');
		$this->load->model('rooms');
		$this->load->model('checkouts');
		$this->load->model('minibars');	
		$this->load->model('roomtransfers');	
	}

	public function index() {
		redirect('roomtransfer/add');
	}


	public function add() {
		$data['customers'] 	= $this->accounts->fetchAll();
		$data['roomss'] 	= $this->rooms->fetchAllRoom();
		$data['rooms'] 		= $this->rooms->fetchCheckinRoooms();
		$data['guests'] 	= $this->minibars->fetchallGuests();
		$data['vrdate']   	= $this->postingdates->fetchPostingdate();
		
		$data['modules'] = array('vouchers/addroomtransfer');
		$this->load->view('template/header');
		$this->load->view('frontoffice/roomtransfer',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function fetchDatas() {

		if (isset( $_POST )) {
			$roomNo = $_POST['roomNo'];
			$vrdate = $_POST['dates'];
			$data['nightdata'] 		= $this->checkouts->fetchNightData($roomNo);
			$data['complementry']   = $this->checkouts->fetchCompelmentary($roomNo,$vrdate);

			$response = "";
			if ( $data['nightdata'] === false ) {
				$response = 'false';
			} else {
				$response = $data;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function getMaxRoomTransferId() {

		$maxId = $this->roomtransfers->getMaxRoomTransferId() + 1;
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($maxId));
	}
	public function save()
	{
		if (isset($_POST)) {
			
			$saveMain 		= $_POST['saveMain'];
			$saveDetail 	= $_POST['saveDetail'];
			$result 		= $this->roomtransfers->save($saveMain,$saveDetail);

			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response['error'] = 'false';
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetch() {

		if (isset( $_POST )) {
			$dcno = $_POST['dcno'];
			$result = $this->roomtransfers->fetch($dcno);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function delete() {

        if (isset( $_POST )) {

            $dcno = $_POST['dcno'];
            $result = $this->roomtransfers->delete($dcno);

            $response = "";
            if ( $result === false ) {
                $response = 'false';
            } else {
                $response = $result;
            }

            $this->output
                 ->set_content_type('application/json')
                 ->set_output(json_encode($response));
        }
    }


	
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */