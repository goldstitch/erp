<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Minibarlist extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('minibarlists');
	}
	public function index() {
		redirect('minibarlist/add');
	}

	public function add() {
		$data['modules'] = array('roomservices/roomserviceList');
		$data['allcatogeoryromServices'] = $this->minibarlists->fetchallcatogeoryromServices();
		$data['allRoomServiceLists'] 	= $this->minibarlists->fetch_model();

		$this->load->view('template/header');
		$this->load->view('roomservices/minibarlist',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}
	public function getMaxId() {

		$maxId = $this->minibarlists->getMaxId() + 1;
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($maxId));
	}
	function fetch()
		{
			$data 	= $this->add_godown->fetch_model();
			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($data));
		}
	public function save() {

			if (isset($_POST)) {
				$saveRSl = $_POST['saveRSl'];
				$result = $this->minibarlists->save($saveRSl);
				$response = array();
				if ( $result === false ) {
					$response['error'] = 'true';
				} else {
					$response['error'] = 'false';
				}
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			}
		}
	public function fetch_Enter() {
			if (isset( $_POST )) {
				$id = $_POST['id'];
				$result = $this->minibarlists->fetch_Enter($id);
				$response = "";
				if ( $result === false ) {
					$response = 'false';
				} else {
					$response = $result;
				}
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			}

		}

	
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */