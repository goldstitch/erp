<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('categories');
	}

	public function index() {
		redirect('category/add');
	}

	public function add() {
		$data['modules'] = array('setup/addcategory');
		$data['categories'] = $this->categories->fetchAllCategories();

		$this->load->view('template/header');
		$this->load->view('setup/addcategory', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxCategoryId() {
		$result = $this->categories->getMaxCategoryId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function saveCategory() {

	// 	if (isset($_POST)) {

	// 		$category = $_POST['category'];
	// 		$result = $this->categories->saveCategory( $category );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetchCategory() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->categories->fetchCategory($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllcategories() {

		$result = $this->categories->fetchAllCategories();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}
	public function saveCategory() {

		if (isset($_POST)) {

			$category = $_POST['category'];
			$error    = $this->categories->iscategoryAlreadyExists($category);

				if (!$error) {
					$result = $this->categories->savecategory( $category );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

}

/* End of file category.php */
/* Location: ./application/controllers/category.php */