<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Postingdate extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('postingdates');
		
	}

	public function index() {
		redirect('postingdate/add');
	}


	public function add() {
		$data['modules'] = array('setup/addpostingdate');

		$data['vrdate']   = $this->postingdates->fetchPostingdate();
		$this->load->view('template/header');
		$this->load->view('setup/addpostingdate',$data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer',$data);
	}
	public function savePostingdate() {

		if (isset($_POST)) {

			$saveMain = $_POST['saveMain'];
			$result   = $this->postingdates->savePostingdate( $saveMain );

			$response = array();
			if ($result === false) {
				$response['error'] = true;
			} else {
				$response['error'] = false;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */