<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('events');
	}

	public function index() {
		redirect('event/add');
	}

	public function add() {
		$data['modules'] = array('setup/addevent');
		$data['events'] = $this->events->fetchAllEvents();

		$this->load->view('template/header');
		$this->load->view('setup/addevent', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxEventId() {
		$result = $this->events->getMaxEventId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function saveEvent() {

	// 	if (isset($_POST)) {

	// 		$event = $_POST['event'];
	// 		$result = $this->events->saveEvent( $event );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetchEvent() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->events->fetchEvent($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllEvents() {

		$result = $this->events->fetchAllEvents();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}

	public function saveEvent() {

		if (isset($_POST)) {

			$event = $_POST['event'];
			$error    = $this->events->isEventAlreadyExist($event);

				if (!$error) {
					$result = $this->events->saveEvent( $event );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

}

/* End of file event.php */
/* Location: ./application/controllers/event.php */