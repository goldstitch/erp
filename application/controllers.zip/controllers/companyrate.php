<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Companyrate extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('accounts');
		$this->load->model('categories');
		$this->load->model('services');
		$this->load->model('companyrates');
	}

	public function index() {
		redirect('companyrate/add');
	}

	public function add() {
		$data['modules'] = array('setup/addcompanyrates');
		$data['parties'] = $this->accounts->fetchAll();
		$data['categories'] = $this->categories->fetchAllCategories();
		$data['services'] = $this->services->fetchAllServices();

		$this->load->view('template/header');
		$this->load->view('setup/addcompanyrates', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxId() {
		$result = $this->companyrates->getMaxId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	public function save() {

		if (isset($_POST)) {

			$rates = $_POST['rates'];
			$services = $_POST['services'];
			$id = $_POST['id'];

			$result = $this->companyrates->save($rates, $services, $id);

			$response = array();
			if ( $result === false ) {
				$response['error'] = 'true';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetch() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$rates = $this->companyrates->fetchRates($id);
			$services = $this->companyrates->fetchServices($id);

			$response = array();
			if ( $rates === false ) {
				$response = 'false';
			} else {
				$response['rates'] = $rates;
				$response['services'] = $services;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	
	public function checkRoomRentFirstForCompany() {

		if (isset( $_POST )) {

			$catid = $_POST['catid'];
			$partyid = $_POST['partyid'];
			$rates = $this->companyrates->checkRoomRentFirstForCompany($catid,$partyid);
			//$services = $this->companyrates->fetchServices($id);

			$response = array();
			if ( $rates === false ) {
				$response = 'false';
			} else {
				$response = $rates;
				//$response['services'] = $services;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function checkRoomRentFirstForCompanys() {

		if (isset( $_POST )) {

			$roomid = $_POST['roomid'];
			$partyid = $_POST['partyid'];
			$rates = $this->companyrates->checkRoomRentFirstForCompanys($roomid,$partyid);
			//$services = $this->companyrates->fetchServices($id);

			$response = array();
			if ( $rates === false ) {
				$response = 'false';
			} else {
				$response = $rates;
				//$response['services'] = $services;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
	public function fetchServiceCategory() {

		if (isset( $_POST )) {

			$catid = $_POST['catid'];
			$result = $this->companyrates->fetchServiceCategory($catid);

			$response = array();
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function delete() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->companyrates->delete($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}
}

/* End of file companyrate.php */
/* Location: ./application/controllers/companyrate.php */