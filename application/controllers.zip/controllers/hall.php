<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Hall extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('halls');
	}

	public function index() {
		redirect('hall/add');
	}

	public function add() {
		$data['modules'] = array('setup/addhall');
		$data['halls'] = $this->halls->fetchAllhalls();

		$this->load->view('template/header');
		$this->load->view('setup/addhall', $data);
		$this->load->view('template/mainnav');
		$this->load->view('template/footer', $data);
	}

	public function getMaxHallId() {
		$result = $this->halls->getMaxHallId() + 1;
		$this->output->set_content_type('application/json')->set_output(json_encode($result));
	}

	// public function saveHall() {

	// 	if (isset($_POST)) {

	// 		$hall = $_POST['hall'];
	// 		$result = $this->halls->saveHall( $hall );

	// 		$response = array();
	// 		if ($result === false) {
	// 			$response['error'] = true;
	// 		} else {
	// 			$response['error'] = false;
	// 		}

	// 		$this->output
	// 			 ->set_content_type('application/json')
	// 			 ->set_output(json_encode($response));
	// 	}
	// }

	public function fetchHall() {

		if (isset( $_POST )) {

			$id = $_POST['id'];
			$result = $this->halls->fetchHall($id);

			$response = "";
			if ( $result === false ) {
				$response = 'false';
			} else {
				$response = $result;
			}

			$this->output
				 ->set_content_type('application/json')
				 ->set_output(json_encode($response));
		}
	}

	public function fetchAllHalls() {

		$result = $this->halls->fetchAllHalls();

		$response = array();
		if ( $result === false ) {
			$response = 'false';
		} else {			
			$response = $result;
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($response));
	}

	public function saveHall() {

		if (isset($_POST)) {

			$hall = $_POST['hall'];
			$error    = $this->halls->isHallAlreadyExist($hall);

				if (!$error) {
					$result = $this->halls->saveHall( $hall );
					$response = array();
					if ( $result === false ) {
						$response['error'] = 'true';
					} else {
						$response = $result;
				}

				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode($response));
			} else {
				$this->output
					 ->set_content_type('application/json')
					 ->set_output(json_encode('duplicate'));
			}
		}
	}

}

/* End of file hall.php */
/* Location: ./application/controllers/hall.php */