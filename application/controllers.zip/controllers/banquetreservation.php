<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');

class banquetreservation extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('banquetinquirys');
        $this->load->model('banquetreservations');
        $this->load->model('minibarlists');
        $this->load->model('minibars');
        $this->load->model('halls');
        $this->load->model('events');
        $this->load->model('waiters');
        $this->load->model('rooms');
        $this->load->model('categories');
        $this->load->model('accounts');
        $this->load->model('types');
        $this->load->model('reservations');
        $this->load->model('levels');
        $this->load->model('ledgers');
    }   

    public function index()
    {
        redirect('banquetreservation/add');
    }

    public function add()
    {
        $data['modules']    = array('banquet/banquetreservation');
        $data['halls']      = $this->halls->fetchAllhalls();
        $data['waiters']    = $this->waiters->fetchAll();
        $data['rooms']      = $this->rooms->fetchAllRooms();
        $data['particulars']= $this->minibars->fetchParticularsAll();
        $data['waiters']    = $this->waiters->fetchAll();
        $data['rooms']      = $this->rooms->fetchAllRooms();
        $data['categories'] = $this->categories->fetchAllCategories();
        $data['types']      = $this->types->fetchAllTypes();
        $data['guests']     = $this->reservations->fetchallGuest();
        $data['accounts']   = $this->accounts->fetchAll();
        $data['events']     = $this->events->fetchAllEvents();
        $data['menu_item']  = $this->banquetreservations->fetchAllMenuItems();
        $data['item_name']  = $this->banquetreservations->fetchAllOtherItems();
        $data['inquiry']    = $this->banquetinquirys->fetchAllInquiriesNo();
        $data['setting_configur'] = $this->accounts->getsetting_configur();
        //die(print_r($data['inquiry']));
        
        $this->load->view('template/header');
        $this->load->view('banquet/banquetreservation', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer');
    }

    function save()
    {
        if (isset($_POST))
        {
            $banquetsaveReservation = $_POST['banquetsaveReservation'];
            $banquetsavedeatailMenu = $_POST['banquetsavedeatailMenu'];
            $banquetsavedeatailAdd  = $_POST['banquetsavedeatailAdd'];
            $dcno  = $_POST['vrnoa'];
            $ledger = $_POST['ledger'];
            $voucher_type_hidden = $_POST['voucher_type_hidden'];

            $result = $this->ledgers->save($ledger, $dcno, 'banquetreservation',$voucher_type_hidden);
            $result = $this->banquetreservations->save($banquetsaveReservation, $banquetsavedeatailMenu, $banquetsavedeatailAdd);
            $response = array();
            if ($result === false)
            {
                $response['error'] = 'true';
            }
            else
            {
                $response['error'] = 'false';
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    function saveGuest()
    {
        if (isset($_POST))
        {
            $saveGuestM = $_POST['saveGuestM'];
            $result = $this->banquetreservations->saveGuest($saveGuestM);
            $response = array();
            if ($result === false)
            {
                $response['error'] = 'true';
            }
            else
            {
                $response['error'] = 'false';
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function saveAccounts()
    {
        if (isset($_POST))
        {
            $accountDetail = $_POST['accountDetail'];
            $accountDetail['account_id'] = $this->levels->genAccStr($accountDetail['level3']);
            $result = $this->accounts->save($accountDetail);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response['error'] = false;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function getMaxId()
    {
        $maxId = $this->banquetreservations->getMaxId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    public function getMaxgId()
    {
        $maxId = $this->banquetreservations->getMaxgId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    public function fetch_Inquiry()
    {
        if (isset($_POST)) {

            $inquiryno  = $_POST['inquiryno'];
            $result     = $this->banquetreservations->fetch_Inquiry($inquiryno);
            $response = "";
            if ($result === false) {
                $response = 'false';
            } else {
                $response = $result;
            }
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }
     
    public function fetch()
    {
        if (isset($_POST)) {

            $vrno       = $_POST['vrno'];
            $result     = $this->banquetreservations->fetch($vrno);
            $response   = "";
            if ($result === false) {
                $response = 'false';
            } else {
                $response = $result;
            }
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }

    function fetch_EnterMenu()
    {
        $vrno = $_POST['vrno'];
        $data = $this->banquetreservations->fetch_EnterMenu($vrno);
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    public function fetch_guesttbl()
    {
        $gid = $_POST['gid'];
        $data = $this->banquetreservations->fetch_guesttbl($gid);
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }
    public function delete()
    {

        if (isset($_POST)) {

            $id = $_POST['id'];
            $company_id = $_POST['company_id'];
            $result = $this->banquetreservations->delete($id,'banquetreservation',$company_id);

            $response = "";
            if ($result === false) {
                $response = 'false';
            } else {
                $response = $result;
            }

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }
     public function fetchHallAvailability()
    {
        if (isset($_POST))
        {
            $from = $_POST['from'];
            $to = $_POST['to'];
            $result = $this->banquetreservations->fetchHallAvailability($from, $to);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }
}