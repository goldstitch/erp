<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staticdashboard extends CI_Controller {

	public function index()
	{
		$this->load->view('template/header');
		$this->load->view('user/staticdashboard');
		$this->load->view('template/mainnav');
		$this->load->view('template/footer');
	}

}

/* End of file staticdashboard.php */
/* Location: ./application/controllers/staticdashboard.php */