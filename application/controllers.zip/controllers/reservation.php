<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');

class Reservation extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('postingdates');
        $this->load->model('categories');
        $this->load->model('companyrates');
        $this->load->model('waiters');
        $this->load->model('minibars');
        $this->load->model('rooms');
        $this->load->model('accounts');
        $this->load->model('types');
        $this->load->model('reservations');
        $this->load->model('levels');
        $this->load->model('services');
    }

    public function index()
    {
        redirect('reservation/add');
    }

    public function add()
    {
        $data['modules'] = array('reservation/reservation');
        $data['waiters'] = $this->waiters->fetchAll();
        $data['rooms'] = $this->rooms->fetchAllRoom();
        $data['categories'] = $this->categories->fetchAllCategories();
        $data['categori'] = $this->categories->fetchAllCategories();
        // $data['particulars'] = $this->minibars->fetchParticulars();
        $data['types'] = $this->types->fetchAllTypes();
        $data['guests'] = $this->reservations->fetchallGuest();
        $data['companyrate'] = $this->companyrates->fetchAllCompanyRates();
        //$data['categories'] = $this->categories->fetchAllCategories();
        //$data['services'] = $this->services->fetchAllServices();
        $data['accounts'] = $this->accounts->fetchAll();
        // Accounts Modal
        $data['particulars'] = $this->minibars->fetchParticularsAll();
        //$data['rooms'] 	 	 = $this->rooms->fetchAllRooms();
        $data['guests'] = $this->reservations->fetchallGuest();
        $data['names'] = $this->accounts->getDistinctFields('name');
        $data['countries'] = $this->accounts->getDistinctFields('country');
        $data['cities'] = $this->accounts->getDistinctFields('city');
        $data['cityareas'] = $this->accounts->getDistinctFields('cityarea');
        $data['l3s'] = $this->levels->fetchAllLevel3();
        $data['parties'] = $this->accounts->fetchAll();
        $data['guestss'] = $this->reservations->fetchallGuest();
        $data['reservationcancel'] = $this->reservations->fecthReservationCancel();
        $data['vrdate'] = $this->postingdates->fetchPostingdate();
        // $data['particulars'] = $this->minibars->fetchParticulars();
        $this->load->view('template/header');
        $this->load->view('reservation/reservation', $data);
        $this->load->view('template/mainnav');
        $this->load->view('template/footer');
    }

    public function save()
    {
        if (isset($_POST))
        {
            $saveReservation = $_POST['saveReservation'];
            $saveGuest = $_POST['saveGuest'];
            $arrivalDate = $this->input->post('arrival_date');
            $departureDate = $this->input->post('departure_date');
            $error = $this->reservations->isRoomAlreadyReserved($saveReservation, $arrivalDate, $departureDate);
            if ($error == 'false')
            {
                $result = $this->reservations->save($saveReservation, $saveGuest, $arrivalDate, $departureDate);
                $response = array();
                if ($result === false)
                {
                    $response['error'] = 'true';
                }
                else
                {
                    $response = $result;
                }
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
            }
            else
            {
                $this->output->set_content_type('application/json')->set_output(json_encode('duplicate'));
            }
        }
    }

    function saveGuest()
    {
        if (isset($_POST))
        {
            $saveGuestM = $_POST['saveGuestM'];
            $result = $this->reservations->saveGuest($saveGuestM);
            $response = array();
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function saveAccounts()
    {
        if (isset($_POST))
        {
            $accountDetail = $_POST['accountDetail'];
            $accountDetail['account_id'] = $this->levels->genAccStr($accountDetail['level3']);
            $result = $this->accounts->save($accountDetail);
            $response = array();
            if ($result === false)
            {
                $response['error'] = true;
            }
            else
            {
                $response['error'] = false;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    public function getMaxId()
    {
        $maxId = $this->reservations->getMaxId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    public function getMaxgId()
    {
        $maxId = $this->reservations->getMaxgId() + 1;
        $this->output->set_content_type('application/json')->set_output(json_encode($maxId));
    }

    function fetch_Enter()
    {
        if (isset($_POST))
        {
            $vrno = $_POST['vrno'];
            $error = $this->reservations->isRservationAlreadySaved($vrno);
            if (!$error)
            {
                $result = $this->reservations->fetch_Enter($vrno);
                $response = array();
                if ($result === false)
                {
                    $response = false;
                }
                else
                {
                    $response = $result;
                }
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
            }
            else
            {
                $this->output->set_content_type('application/json')->set_output(json_encode('duplicate'));
            }
        }
    }

    function fetch_Enter_REservation()
    {
        if (isset($_POST))
        {
            $vrno = $_POST['vrno'];
            //$error    = $this->reservations->isRservationAlreadySaved($vrno);
            $result = $this->reservations->fetch_Enter($vrno);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    function fetch_guesttbl()
    {
        $id = $_POST['id'];
        $data = $this->reservations->fetch_guesttbl($id);
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    public function delete()
    {
        if (isset($_POST))
        {
            $id = $_POST['id'];
            $result = $this->reservations->delete($id);
            $response = "";
            if ($result === false)
            {
                $response = 'false';
            }
            else
            {
                $response = $result;
            }
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }

    function fetchAllCheckinReservation()
    {
        $data = $this->reservations->fetchAllCheckinReservation();
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    function fetchAllReservations()
    {
        $data = $this->reservations->fetchAllReservations();
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    function fetchAllReservationsNotCheckIn()
    {
        $data = $this->reservations->fetchAllReservationsNotCheckIn();
        $response = "";
        if ($data === false)
        {
            $response = 'false';
        }
        else
        {
            $response = $data;
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }
}