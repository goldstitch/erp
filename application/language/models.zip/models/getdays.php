<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class getdays extends CI_Model
{
    public function getTDays($sStartDate, $sEndDate)
    {
        $sStartDate = date("Y-m-d", strtotime($sStartDate));
        $sEndDate = date("Y-m-d", strtotime($sEndDate));

        $aDays[] = $sStartDate;
        $sCurrentDate = $sStartDate;

        while($sCurrentDate < $sEndDate)
        {
            $sCurrentDate = date("Y-m-d", strtotime("+1 day", strtotime($sCurrentDate)));
            $aDays[] = $sCurrentDate;
        }
        return $aDays;
    }
}