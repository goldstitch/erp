<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Types extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxTypeId() {

		$this->db->select_max('id');
		$result = $this->db->get('types');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function saveType( $types ) {

		$this->db->where(array('id' => $types['id']));
		$result = $this->db->get('types');

		$affect = 0;
		if ($result->num_rows() > 0) {

			$this->db->where(array('id' => $types['id'] ));
			$affect = $this->db->update('types', $types);
			//$affect = $this->db->affected_rows();
		} else {

			unset($types['id']);
			$result = $this->db->insert('types', $types);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchType( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('types');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	public function fetchAllTypes() {

		$sql = "Select * from types order by name";
		$result = $this->db->query($sql);

		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function saveTypes( $type ) {

		$this->db->insert('types', $type);
		$id = $this->db->insert_id();
		$this->db->where(array('id' => $id));
		$result = $this->db->get('types');
		//$affect = $this->db->affected_rows();
		return $result->row_array();

	}
	
	public function isTypeAlreadyExist( $name ) {

		$this->db->where('name', $name['name']);
		$result = $this->db->get('types');
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	public function isTypeAlreadyExists($type){
		$result = $this->db->query("SELECT *
									FROM types 
									WHERE id<>".$type['id']." AND name ='".$type['name']."'");
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}

	}

}

/* End of file types.php */
/* Location: ./application/models/types.php */