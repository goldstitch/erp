<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Rooms extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getMaxId()
    {
        $this->db->select_max('id');
        $result = $this->db->get('rooms');
        $result = $result->row_array();
        return $result['id'];
    }

    public function fetchAllFloor()
    {
        $result = $this->db->query('SELECT DISTINCT floor FROM rooms');
        return $result->result_array();
    }

    public function fetchAllRoomStatus()
    {
        $result = $this->db->query('SELECT * FROM roomstatus');
        return $result->result_array();
    }

    public function fetchCheckinRoooms()
    {
        //$result = $this->db->query("SELECT id,roomNo from checkin  where status = 'checkin'");
        // $result = $this->db->query("SELECT distinct checkin.roomNo id,rooms.room roomNo
        // 							from checkin
        // 							inner join rooms on checkin.roomno=rooms.id where checkin.status = 'checkin';");
        // $result = $this->db->query("SELECT c.id,c.roomno,r.room
        // 							FROM checkin c
        // 							INNER JOIN rooms r on r.id = c.roomno
        // 							where c.status='checkin'
        // 							order by c.roomno");
        $result = $this->db->query("SELECT c.id,c.roomno,r.room,c.`status`,p.name,g.guestName,c.gid,t.name as type_name,cat.id as cat_id,
                                    cat.name as cat_name,r.extrabedcharges
									FROM checkin c
									INNER JOIN rooms r ON r.id = c.roomno
									INNER JOIN party p ON p.id = c.partyid
									INNER JOIN guest g ON g.id = c.gid
									INNER join types t on t.id = r.typeid
									INNER JOIN category cat on cat.id= r.catid 
									WHERE c.status = 'checkin'
									group by c.roomno
									ORDER BY c.roomno ");

        return $result->result_array();
    }

    public function fetchCheckinRooomWithGuest()
    {
        $result = $this->db->query("SELECT distinct r.room,r.id as roomno FROM rooms r ");

        $data = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result() as $row) {
                $data[] = array(
                    'id' => $row->room,
                    'roomno' => $row->roomno,
                    'room' => $row->room,
                    'gid' => $this->checkInStatus($row->room)
                );
            }
        }
        return $data;
    }

    public function checkInStatus($id)
    {
        $result = $this->db->query("SELECT c.gid
									FROM checkin c
									INNER JOIN rooms r ON r.id = c.roomno
									INNER JOIN party p ON p.id = c.partyid
									left JOIN guest g ON g.id = c.gid
									INNER join types t on t.id = r.typeid
									INNER JOIN category cat on cat.id= r.catid
									WHERE c.status='checkin' and r.room = '" . $id . "'
									ORDER BY c.roomno ");
        if ($result->num_rows() > 0) {
            $res = $result->result_array();
            return $res[0]['gid'];
        } else {
            return '0';
        }
    }

    public function fetchCheckinRooom()
    {
        //$result = $this->db->query("SELECT id,roomNo from checkin  where status = 'checkin'");
        // $result = $this->db->query("SELECT distinct checkin.roomNo id,rooms.room roomNo
        // 							from checkin
        // 							inner join rooms on checkin.roomno=rooms.id where checkin.status = 'checkin';");
        $result = $this->db->query("SELECT distinct r.room,r.id as roomno FROM rooms r ");
        $data = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result() as $row) {
                $data[] = array(
                    'id' => $row->room,
                    'roomno' => $row->roomno,
                    'room' => $row->room,
                    'gid' => $this->checkInStatus($row->room)
                );
            }
        }
        return $data;
    }

    public function saveRoom($room)
    {

        $this->db->where(array('id' => $room['id']));
        $result = $this->db->get('rooms');

        $affect = 0;
        if ($result->num_rows() > 0) {
            $id = $result->row_array();
            $i = $id['id'];
            $this->db->where(array('id' => $i));
            $affect = $this->db->update('rooms', $room);
            // $affect = $this->db->affected_rows();
        } else {
            unset($room['id']);
            $result = $this->db->insert('rooms', $room);
            $affect = $this->db->affected_rows();
        }

        if ($affect === 0) {
            return false;
        } else {
            return true;
        }
    }

    public function fetchRoom($id)
    {
        $this->db->where(array('id' => $id));
        $result = $this->db->get('rooms');
        if ($result->num_rows() > 0) {
            return $result->row_array();
        } else {
            return false;
        }
    }

    public function fetchRoomNotReserved($roomno, $arrivaldate, $departdate)
    {
        $result = $this->db->query("select * from rooms where id = " . $roomno);

        $checkin_result = $this->db->query("SELECT roomno,date(max(checkin_date)) as reservationdates
								FROM checkin_dates
								WHERE checkin_date BETWEEN '" . $arrivaldate . "'
								AND '" . $departdate . "' and roomno= '" . $roomno . "'
								group by roomno
								ORDER BY roomno");

        $reservation_result = $this->db->query("SELECT roomId,date(max(reservation_date)) as reservationdates
								FROM reservation_dates rd
								WHERE reservation_date BETWEEN '" . $arrivaldate . "'
								AND '" . $departdate . "' and roomId= '" . $roomno . "'
								group by roomId
								ORDER BY roomId");

        $dirty_result = $this->db->query("SELECT roomno FROM dirty_rooms where roomno = " . $roomno);

        if ($checkin_result->num_rows() > 0)
        {
            return 'checkin';
        }
        elseif ($reservation_result->num_rows() > 0)
        {
            return 'reserved';
        }
        elseif ($dirty_result->num_rows() > 0)
        {
            return 'dirty';
        }
        else
        {
            return false;
        }
    }


    public function fetchAllRooms()
    {

        // $result = $this->db->query("SELECT distinct r.id,r.*, c.name AS 'cat_name', t.name AS 'type_name'
        // 							FROM rooms r
        // 							INNER JOIN category c ON c.id = r.catid
        // 							INNER JOIN types t ON t.id = r.typeid
        // 							where r.id Not in (select roomno from checkin where status='checkin');");

        $result = $this->db->query("SELECT DISTINCT r.*, c.name AS 'cat_name', t.name AS 'type_name', c.id as cat_id, r.id as room_id,
                                    res.status AS reservstatus,c.`status` AS checkinstatus,rs.roomstatus as status
									FROM rooms r
									left join roomstatus rs on rs.rmstatusid= r.statusid
									INNER JOIN category c ON c.id = r.catid
									INNER JOIN types t ON t.id = r.typeid
									LEFT JOIN(
									SELECT STATUS,roomid
									FROM reservation) AS res ON res.roomid = r.id
									LEFT JOIN(
									SELECT STATUS,roomno
									FROM checkin) AS c ON c.roomno = r.id
									ORDER BY r.id");
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchAllFreeRooms()
    {

        $result = $this->db->query("SELECT distinct r.id,r.*, c.name AS 'cat_name', t.name AS 'type_name'
									FROM rooms r
									INNER JOIN category c ON c.id = r.catid
									INNER JOIN types t ON t.id = r.typeid
									where r.id Not in (select roomno from checkin where status='checkin');");

        //$result = $this->db->query("select * from rooms");
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchAllRoom()
    {

        $result = $this->db->query("SELECT r.*, c.name AS 'cat_name', t.name AS 'type_name'
									FROM rooms r
									INNER JOIN category c ON c.id = r.catid
									INNER JOIN types t ON t.id = r.typeid");

        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function getAllRooms()
    {

        $result = $this->db->query("SELECT id,room FROM rooms");

        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function getAllDirtyRooms()
    {

        $result = $this->db->query("SELECT d.roomno as id,r.room
					FROM dirty_rooms d
					INNER JOIN rooms r on r.id=d.roomno");

        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function getAllRoomsStatus()
    {

        $result = $this->db->query("select * from roomstatus where rmstatusid=3");

        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function isRoomAlreadyExist($room)
    {
        $result = $this->db->query("SELECT *
									FROM rooms 
									WHERE id<>" . $room['id'] . " AND room =" . $room['room'] . "");
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }

    }

    public function fetchRoomByCategory($catid)
    {

        $sql = "select * from rooms where catid=$catid";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchRoomByCategoryForcheckin($catid)
    {

        $sql = "select * from rooms where catid=$catid";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }
}

/* End of file rooms.php */
/* Location: ./application/models/rooms.php */