<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function getMaxCategoryId() {

		$this->db->select_max('id');
		$result = $this->db->get('category');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function saveCategory( $category ) {

		$this->db->where(array('id' => $category['id']));
		$result = $this->db->get('category');

		$affect = 0;
		if ($result->num_rows() > 0) {

			$this->db->where(array('id' => $category['id'] ));
			$affect = $this->db->update('category', $category);
			//$affect = $this->db->affected_rows();
		} else {

			unset($category['id']);
			$result = $this->db->insert('category', $category);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchCategory( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('category');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	public function fetchAllCategories() {
		$sql = "Select * from category order by name";
		$result = $this->db->query($sql);

		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function saveCat( $cat ) {

		$this->db->insert('category', $cat);
		$id = $this->db->insert_id();
		$this->db->where(array('id' => $id));
		$result = $this->db->get('category');
		//$affect = $this->db->affected_rows();
		return $result->row_array();

	}
	
	public function isCategoryAlreadyExist( $name ) {

		$this->db->where('name', $name['name']);
		$result = $this->db->get('category');
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public function isCategoryAlreadyExists($cat){
		$result = $this->db->query("SELECT *
									FROM category
									WHERE id<>".$cat['id']." AND `name`='".$cat['name']."'");
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}

	}

}

/* End of file categories.php */
/* Location: ./application/models/categories.php */
