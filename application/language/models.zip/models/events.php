<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxEventId() {

		$this->db->select_max('id');
		$result = $this->db->get('events');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function saveEvent( $event ) {

		$this->db->where(array('id' => $event['id']));
		$result = $this->db->get('events');

		$affect = 0;
		if ($result->num_rows() > 0) {

			$this->db->where(array('id' => $event['id'] ));
			$affect = $this->db->update('events', $event);
			//$affect = $this->db->affected_rows();
		} else {

			unset($event['id']);
			$result = $this->db->insert('events', $event);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchEvent( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('events');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	public function fetchAllEvents() {

		$result = $this->db->get('events');

		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function isEventAlreadyExist($event){
		$result = $this->db->query("SELECT *
									FROM events 
									WHERE id<>".$event['id']." AND name ='".$event['name']."'");
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}

	}
}

/* End of file events.php */
/* Location: ./application/models/events.php */