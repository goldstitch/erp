<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Banquetinquirys extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getMaxId()
    {
        $this->db->select_max('vrno');
        $result = $this->db->get('banquetinquiry');
        $row = $result->row_array();
        $maxId = $row['vrno'];
        return $maxId;
    }

    public function getMaxgId()
    {
        $this->db->select_max('gid');
        $result = $this->db->get('guest');
        $row = $result->row_array();
        $maxId = $row['gid'];
        return $maxId;
    }

    public function fetchallcatogeoryromServices()
    {
        $result = $this->db->get('catogeory_roomservices');
        if ($result->num_rows() === 0)
        {
            return false;
        }
        else
        {
            return $result->result_array();
        }
    }

    function save($savebanquetInquiry, $savebanquetdetail, $saveMenuDetail)
    {
        $this->db->select('banqinid');
        $this->db->where(array('vrno' => $savebanquetInquiry['vrno']));
        $this->db->where(array('etype' => 'banquetinquiry'));
        $vrno = $this->db->get('banquetinquiry');
        if ($vrno->num_rows() > 0)
        {
            $vrno = $vrno->row_array();
            $this->db->where(array('banqinid' => $vrno['banqinid']));
            $result = $this->db->get('banquetinquiry');
            $affect = 0;
            if ($result->num_rows() > 0)
            {
                $this->db->where(array('banqinid' => $vrno['banqinid']));
                $affect = $this->db->update('banquetinquiry', $savebanquetInquiry);
                $this->db->delete('banquetinquirydetail', array('banqinid' => $vrno['banqinid']));
                foreach ($savebanquetdetail as $sd)
                {
                    $sd['banqinid'] = $vrno['banqinid'];
                    $this->db->insert('banquetinquirydetail', $sd);
                }

                $this->db->delete('banquet_inquiry_menu', array('banquet_inquiry_id' => $vrno['banqinid']));
                foreach ($saveMenuDetail as $item)
                {
                    $item['banquet_inquiry_id'] = $vrno['banqinid'];
                    $this->db->insert('banquet_inquiry_menu', $item);
                }
            }
        }
        else
        {
            $this->db->select('banqinid');
            $this->db->where(array('vrno' => $savebanquetInquiry['vrno']));
            $vrno = $this->db->get('banquetinquiry');
            $vrno = $vrno->row_array();
            unset($vrno['banqinid']);
            $this->db->insert('banquetinquiry', $savebanquetInquiry);
            $last_id = $this->db->insert_id();
            foreach ($savebanquetdetail as $sd)
            {
                $sd['banqinid'] = $last_id;
                $this->db->insert('banquetinquirydetail', $sd);
            }

            foreach ($saveMenuDetail as $item)
            {
                $item['banquet_inquiry_id'] = $last_id;
                $this->db->insert('banquet_inquiry_menu', $item);
            }

            $affect = $this->db->affected_rows();
        }
        if ($affect === 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    function saveGuest($saveGuestM)
    {
        $this->db->select('gid');
        $this->db->where(array('gid' => $saveGuestM['gid']));
        $gid = $this->db->get('guest');
        if ($gid->num_rows() > 0)
        {
            $gid = $gid->row_array();
            $this->db->where(array('gid' => $gid['gid']));
            $result = $this->db->get('guest');
            $affect = 0;
            if ($result->num_rows() > 0)
            {
                $this->db->where(array('gid' => $gid['gid']));
                $affect = $this->db->update('guest', $saveGuestM);
            }
        }
        else
        {
            $this->db->insert('guest', $saveGuestM);
            $affect = $this->db->affected_rows();
        }
        if ($affect === 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public function fetchCheckin($srno)
    {
        $this->db->where(array('srno' => $srno));
        $result = $this->db->get('checkin');
        if ($result->num_rows() > 0)
        {
            return $result->row_array();
        }
        else
        {
            return false;
        }
    }

    public function fetch_Enter($vrno)
    {
        $sql = "SELECT *, banquetinquiry.status AS status_inquiry, banquetinquiry.address AS inquery_address,banquetinquiry.vrno AS inqno,party.name AS party_name,events.name AS event_name,hall.name AS hall_name
                FROM banquetinquiry
                LEFT JOIN banquetinquirydetail ON banquetinquiry.banqinid = banquetinquirydetail.banqinid
                LEFT JOIN banquet_inquiry_menu ON banquet_inquiry_menu.banquet_inquiry_id = banquetinquiry.banqinid
                INNER JOIN party ON banquetinquiry.partyid = party.id
                INNER JOIN events ON events.id = banquetinquiry.eventid
                INNER JOIN hall ON hall.id = banquetinquiry.hallid
                WHERE banquetinquiry.vrno = '".$vrno."' AND banquetinquiry.etype = 'banquetinquiry'";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
        else{
            return false;
        }
    }

    public function fetchAllInquiriesNo()
    {
        $sql = "select vrno from banquetinquiry where status='1';";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    function fetch_model()
    {
        $sql = "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*, catogeory_roomservices.id as 'catid'
						FROM roomservicelist
						INNER JOIN catogeory_roomservices
						ON roomservicelist.cat_romId =catogeory_roomservices.id;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    function fetchallGuest()
    {
        $sql = "SELECT * FROM guest";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    function fetch_guesttbl($gid)
    {
        $sql = "SELECT * FROM guest WHERE gid = $gid";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    public function fetchDetailedVoucher($vrno, $etype)
    {
        $query = $this->db->query("SELECT * FROM stockmain m
					Inner join stockdetail d ON m.stid = d.stid
					inner join roomservicelist r on r.id=d.item_id
					inner join waiter w on w.waiter_id = m.roomboy
					WHERE m.vrno = $vrno AND etype = 'miniBar'");
        return $query->result_array();
    }

    function fetchParticulars()
    {
        $sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    public function delete($vrNo)
    {
        $this->db->where(array('vrno' => $vrNo));
        $result = $this->db->get('banquetinquiry');
        if ($result->num_rows() == 0)
        {
            return false;
        }
        else
        {
            $this->db->where(array('banqinid' => $vrNo));
            $this->db->delete('banquetinquiry');
            $this->db->where(array('banqinid' => $vrNo));
            $this->db->delete('banquetinquirydetail');
            return true;
        }
    }

    public function getProducts()
    {
        $result = $this->db->query('select product_name from banquetinquirydetail group by product_name');
        return $result->result_array();
    }
    public function getMenuProducts()
    {
        $result = $this->db->query('select distinct banquet_inquiry_menu as product_name from banquet_inquiry_menu');
        return $result->result_array();
    }

    public function isHallAlreadyReserved($savebanquetInquiry){
        
        $timeFrom = $savebanquetInquiry["timefrom"];
        $timeTo   = $savebanquetInquiry["timeto"];
        $date     = $savebanquetInquiry["eventdate"];

        $datetimeFrom = $this->merge_date_time($date,$timeFrom );
        $datetimeTo   = $this->merge_date_time($date,$timeTo );

        $result   = $this->db->query("SELECT timefrom,timeto,hallid,eventdate from banq_res where hallid = '".$savebanquetInquiry['hallid']."' and eventdate='".$savebanquetInquiry['eventdate']."'");
        //die(print_r($result->result_array()));
        $data = array();
        if ($result->num_rows() > 0)
        {
            foreach ($result->result() as $row)
            {
               //die(substr($row->eventdate, 0,10));
                $dbDatetimeFrom = $this->merge_date_time(substr($row->eventdate, 0,10),$row->timefrom );
                $dbDatetimeTo   = $this->merge_date_time(substr($row->eventdate, 0,10),$row->timeto );
                
                if( ($datetimeFrom <= $dbDatetimeFrom && $datetimeFrom >= $dbDatetimeTo ) || ($datetimeFrom >= $dbDatetimeFrom && $datetimeFrom <= $dbDatetimeTo ) ){
                    return 'true';
                }
                else if ( ($datetimeTo <= $dbDatetimeFrom && $datetimeTo >= $dbDatetimeTo ) || ($datetimeTo >= $dbDatetimeFrom && $datetimeTo <= $dbDatetimeTo ) ){
                    return 'true';
                }
                else if ( ($datetimeFrom <= $dbDatetimeFrom && $datetimeTo >= $dbDatetimeTo ) ){
                    return 'true';
                }
            }
        }
        return 'false';
    }

    public function merge_date_time($date,$time){

        //date_default_timezone_set('Asia/Karachi');
        
        $datetime = $date.' '.$time;
        $datetime = strtotime($datetime);
        
        return $datetime;
    }

}