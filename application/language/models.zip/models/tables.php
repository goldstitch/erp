<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tables extends CI_Model {

	public function __construct() {
		parent::__construct();
	}	

	public function getMaxId() {

		$this->db->select_max('id');
		$result = $this->db->get('tables');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function save( $tables ) {

		$this->db->where(array('id' => $tables['id']));
		$result = $this->db->get('tables');

		$affect = 0;
		if ($result->num_rows() > 0) {

			$this->db->where(array('id' => $tables['id'] ));
			$affect = $this->db->update('tables', $tables);
			//$affect = $this->db->affected_rows();
		} else {

			unset($tables['id']);
			$result = $this->db->insert('tables', $tables);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetch( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('tables');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	public function fetchAll() {

		$result = $this->db->get('tables');
		return $result->result_array();
	}

	public function fetchAllActiveTabless() {

		$result = $this->db->query("SELECT * FROM `tables` WHERE id NOT IN (SELECT tables_id FROM kotmain WHERE DATE(vrdate)= DATE(NOW()) AND EType ='kot' AND STATUS='running')");
		return $result->result_array();
	}
	public function isTableAlreadyExist($tables){
		$result = $this->db->query("SELECT *
									FROM tables
									WHERE id<>".$tables['id']." AND name ='".$tables['name']."'");
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}

	}
}

/* End of file tables.php */
/* Location: ./application/models/tables.php */