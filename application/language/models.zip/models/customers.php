<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customers extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function save($customer, $vrnoa) {

		$this->db->where(array('billid' => $vrnoa));
		$this->db->delete('customer');

		$this->db->insert('customer', $customer);
		$affect = $this->db->affected_rows();

		if ( $affect == 0 ) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchAll() {
		$result = $this->db->query("SELECT DISTINCT name FROM customer");
		return $result->result_array();
	}

	public function delete($vrnoa) {
		$this->db->where(array('billid' => $vrnoa));
		$this->db->delete('customer');

		return true;
	}
}

/* End of file customers.php */
/* Location: ./application/models/customers.php */