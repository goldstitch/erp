<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reservations extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getMaxId()
    {
        $this->db->select_max('resid');
        $result = $this->db->get('reservation');
        $row = $result->row_array();
        $maxId = $row['resid'];
        return $maxId;
    }

    public function getMaxgId()
    {
        $this->db->select_max('id');
        $result = $this->db->get('guest');
        $row = $result->row_array();
        $maxId = $row['id'];
        return $maxId;
    }

    public function fetchallcatogeoryromServices()
    {
        $result = $this->db->get('catogeory_roomservices');
        if ($result->num_rows() === 0)
        {
            return false;
        }
        else
        {
            return $result->result_array();
        }
    }

    function save($saveReservation, $saveGuest, $arrivalDate, $departureDate)
    {
        $this->db->where(array('resid' => $saveReservation['resid']));
        $result = $this->db->get('reservation');
        $affect = 0;
        $daysArray = $this->getdays->getTDays($arrivalDate, $departureDate);
        if ($result->num_rows() > 0)
        {
            $resid = $result->row_array();
            $this->db->where(array('resid' => $resid['resid']));
            $affect = $this->db->update('reservation', $saveReservation);
            unset($saveGuest['id']);
            $this->db->where(array('id' => $resid['gid']));
            $this->db->update('guest', $saveGuest);
            //die(print_r($saveGuest));
            $this->deteleReservationDates($resid['resid']);
            $this->addReservationDates($affect, $daysArray, $resid['resid'], $saveReservation['roomId']);
        }
        else
        {
            $this->db->insert('reservation', $saveReservation);
            $last_id = $this->db->insert_id();
            $this->db->where(array('resid' => $last_id));
            $result = $this->db->get('reservation');
            if ($result->num_rows() > 0)
            {
                $resid = $result->row_array();
            }
            $this->db->where(array('id' => $resid['gid']));
            $result = $this->db->get('guest');
            $affect = 0;
            if ($result->num_rows() > 0)
            {
                $gid = $result->row_array();
                $this->db->where(array('id' => $gid['id']));
                $affect = $this->db->update('guest', $saveGuest);
            }
            else
            {
                $this->db->insert('guest', $saveGuest);
            }
            $this->addReservationDates('1', $daysArray, $resid['resid'], $saveReservation['roomId']);
        }
        if ($saveReservation['status'] == 'cancel')
        {
            $this->deteleReservationDates($resid['resid']);
        }
        if ($affect === 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public function addReservationDates($affect, $daysArray, $resid, $roomId)
    {
        if ($affect > 0)
        {
            foreach ($daysArray as $key => $row)
            {
                $this->db->query("insert into reservation_dates (resid, roomId, reservation_date)
                                      values ('" . $resid . "', '" . $roomId . "', '" . $row . "')");
            }
        }
    }

    public function deteleReservationDates($resid)
    {
        $this->db->query("delete from reservation_dates where resid = '" . $resid . "'");
    }

    function saveGuest($saveGuestM)
    {
        $this->db->select('id');
        $this->db->where(array('id' => $saveGuestM['id']));
        $id = $this->db->get('guest');
        if ($id->num_rows() > 0)
        {
            $id = $id->row_array();
            $this->db->where(array('id' => $id['id']));
            $result = $this->db->get('guest');
            $affect = 0;
            if ($result->num_rows() > 0)
            {
                $this->db->where(array('id' => $id['id']));
                $affect = $this->db->update('guest', $saveGuestM);
            }
        }
        else
        {
            $this->db->insert('guest', $saveGuestM);
            $affect = $this->db->affected_rows();
            $id = $this->db->insert_id();
            $this->db->where(array('id' => $id));
            $result = $this->db->get('guest');
            //$affect = $this->db->affected_rows();
            return $result->row_array();
        }
        if ($affect === 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public function fetchCheckin($srno)
    {
        $this->db->where(array('srno' => $srno));
        $result = $this->db->get('checkin');
        if ($result->num_rows() > 0)
        {
            return $result->row_array();
        }
        else
        {
            return false;
        }
    }

    public function fetch_Enter($vrno)
    {
        $sql = "SELECT *,cat.name as cat_name,r.status as reservationtatus,g.id as guestid,g.email as gemail,
                g.fax as gfax,g.fname as gfname,r.status as checkinstatus,r.partyid as partys,ty.name as typename,
                cat.name as catname,g.design as designation,g.email as gemail,g.fax as gfax,r.cat_id as categoryid,
                (select count(reservation_date) from reservation_dates where resid = '" . $vrno . "') as stay_duration
                from reservation r
                inner join guest g on r.gid = g.id
                inner join rooms rom on r.roomId = rom.id
                inner join category cat on r.cat_id = cat.id
                inner join types ty on r.roomTyoe = ty.id
                inner join  party p on r.partyid = p.id
                where r.resid = " . $vrno;
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0)
        {
            return $result->row_array();
        }
        else
        {
            return false;
        }
    }

    function fetch_model()
    {
        $sql = "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,
                catogeory_roomservices.id as 'catid'
                FROM roomservicelist
                INNER JOIN catogeory_roomservices
                ON roomservicelist.cat_romId =catogeory_roomservices.id;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    function fetchallGuest()
    {
        $sql = "select *,g.id as gid from guest as g left join party as p on g.partyid=p.id;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    function fetch_guesttbl($id)
    {
        $sql = "SELECT * FROM guest WHERE id = $id";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    public function fetchDetailedVoucher($vrno, $etype)
    {
        $query = $this->db->query("SELECT * FROM stockmain m
                                    Inner join stockdetail d ON m.stid = d.stid
                                    inner join roomservicelist r on r.id=d.item_id
                                    inner join waiter w on w.waiter_id = m.roomboy
                                    WHERE m.vrno = $vrno AND etype = 'miniBar'");
        return $query->result_array();
    }

    function fetchParticulars()
    {
        $sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    public function deleteCheckin($srno)
    {
        $this->db->where(array('srno' => $srno));
        $result = $this->db->get('checkin');
        if ($result->num_rows() == 0)
        {
            return false;
        }
        else
        {
            $this->db->where(array('srno' => $srno));
            $result = $this->db->delete('checkin');
            return true;
        }
    }

    public function delete($resid)
    {
        $this->db->where(array('resid' => $resid));
        $result = $this->db->get('reservation');
        if ($result->num_rows() == 0)
        {
            return false;
        }
        else
        {
            $this->db->where(array('resid' => $resid));
            $result = $this->db->delete('reservation');
            $this->deteleReservationDates($resid);
            $this->resettableautoincrement->resetTableAutoIncre('reservation', 'resid');
            return true;
        }
    }

    public function isRoomAlreadyReserved($saveReservation, $arrivalDate, $departureDate)
    {
        $daysArray = $this->getdays->getTDays($arrivalDate, $departureDate);
        $status = 'false';
        $result = $this->db->query("select * from reservation where resid = '" . $saveReservation['resid'] . "' ");
        $resArray = $result->result_array();
        if (count($resArray) == 0 || $resArray[0]['roomId'] != $saveReservation['roomId'])
        {
            foreach ($daysArray as $key => $row)
            {
                $result = $this->db->query("SELECT * from reservation_dates
                                            where reservation_date = '" . $row . "'
                                            and roomId = '" . $saveReservation['roomId'] . "'");
                if ($result->num_rows() > 0)
                {
                    $status = 'true';
                }
            }
        }
        return $status;
    }

    public function isRservationAlreadySaved($vrno)
    {
        $result = $this->db->query("select * from checkin where resid = " . $vrno);

        if ($result->num_rows() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    function fecthReservationCancel()
    {
        $sql = "select r.room,c.name as catname,t.name as typename,re.datetime,re.status from reservation  as re
                INNER JOIN rooms r on r.id=re.roomId
                INNER JOIN types t on t.id = re.roomTyoe
                INNER JOIN category c on c.id = re.cat_id
                where re.`status`='cancel';";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }

    function fetchAllCheckinReservation()
    {
        $sql = "SELECT r.room,c.name AS catname,t.name AS typename,re.datetime,re.status,re.resid,
                re.arrivaldate,re.departuredate as departdate
                FROM checkin AS re
                INNER JOIN rooms r ON r.id=re.roomno
                INNER JOIN types t ON t.id = re.roomtype
                INNER JOIN category c ON c.id = re.catid
                where re.resid<>0 and re.`status` = 'checkin'";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }

    function fetchAllReservations()
    {
        $sql = "SELECT r.room,c.name AS catname,t.name AS typename,re.datetime,re.status,re.arrivaldate,re.departdate
                FROM reservation AS re
                INNER JOIN rooms r ON r.id=re.roomId
                INNER JOIN types t ON t.id = re.roomTyoe
                INNER JOIN category c ON c.id = re.cat_id
                ";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }

    function fetchAllReservationsNotCheckIn()
    {
        $sql = "SELECT r.room,c.name AS catname,t.name AS typename,re.datetime,re.status,re.arrivaldate,re.departdate
                FROM reservation AS re
                INNER JOIN rooms r ON r.id=re.roomId
                INNER JOIN types t ON t.id = re.roomTyoe
                INNER JOIN category c ON c.id = re.cat_id
                INNER JOIN reservation_dates ON reservation_dates.resid = re.resid
                where reservation_dates.is_checkin = '0'
                group by reservation_dates.resid
                ";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }
}