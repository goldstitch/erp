<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stocks extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxVrno($etype) {

		$result = $this->db->query("SELECT MAX(vrno) vrno FROM stockmain WHERE etype = '". $etype ."' AND DATE(vrdate) = DATE(NOW())");
		$row = $result->row_array();
		$maxId = $row['vrno'];

		return $maxId;
	}

	public function getMaxVrnoa($etype) {

		$result = $this->db->query("SELECT MAX(vrnoa) vrnoa FROM stockmain WHERE etype = '". $etype ."'");
		$row = $result->row_array();
		$maxId = $row['vrnoa'];

		return $maxId;
	}

	public function save( $stockmain, $stockdetail, $vrnoa, $etype ) {

		$this->db->where(array('salebillno' => $vrnoa, 'etype' => $etype ));
		$result = $this->db->get('stockmain');

		if ($result->num_rows() > 0) {

			$result = $result->row_array();
			$stid = $result['stid'];

			////////////////////////////////
			// delete from stock main     //
			////////////////////////////////
			$this->db->where(array('salebillno' => $vrnoa, 'etype' => $etype ));
			$result = $this->db->delete('stockmain');
			//////////////////////////////
			// delete from stock detail //
			//////////////////////////////
			$this->db->where(array('stid' => $stid));
			$result = $this->db->delete('stockdetail');
		}

		$this->db->insert('stockmain', $stockmain);
		$stid = $this->db->insert_id();

		$affect = 0;
		foreach ($stockdetail as $detail) {

			$detail['stid'] = $stid;
			$this->db->insert('stockdetail', $detail);
			$affect = $this->db->affected_rows();
		}

		if ( $affect == 0 ) {
			return false;
		} else {
			return true;
		}
	}

	public function delete( $vrnoa, $etype ) {

		$this->db->where(array('salebillno' => $vrnoa, 'etype' => $etype ));
		$result = $this->db->get('stockmain');

		if ($result->num_rows() > 0) {

			$result = $result->row_array();
			$stid = $result['stid'];

			////////////////////////////////
			// delete from stock main     //
			////////////////////////////////
			$this->db->where(array('salebillno' => $vrnoa, 'etype' => $etype ));
			$result = $this->db->delete('stockmain');
			//////////////////////////////
			// delete from stock detail //
			//////////////////////////////
			$this->db->where(array('stid' => $stid));
			$result = $this->db->delete('stockdetail');
		}

		return true;
	}


	public function fetchDailyVoucherReport($startDate, $endDate, $what, $type, $company_id, $etype,$field,$crit,$orderBy,$groupBy,$name){

		
		
		$get_crit="(
									SELECT $field as VOUCHER,item.ITEM_ID, m.ETYPE,date_format(m.VRDATE,'%d %b %y') AS VRDATE,dept.name DEPT_NAME,m.DATE_TIME ,m.VRNOA, party.NAME, m.REMARKS, abs(ROUND(if(item.uom='dozen', d.QTY/12,d.QTY), 2)) QTY, ROUND(d.NETAMOUNT, 2) NETAMOUNT,item.ITEM_DES,item.UOM,d.RATE,d.AMOUNT
									FROM stockmain m
									INNER JOIN stockdetail d ON m.stid = d.stid
									INNER JOIN party party ON party.pid = m.party_id
									INNER JOIN level3 leveltbl3 ON leveltbl3.l3 = party.level3
									INNER JOIN level2 leveltbl2 ON leveltbl2.l2 = leveltbl3.l2
									INNER JOIN level1 leveltbl1 ON leveltbl1.l1 = leveltbl2.l1
									INNER JOIN user ON user.uid = m.uid
									INNER JOIN company ON company.company_id = m.company_id
									left JOIN department dept ON d.godown_id = dept.did
									INNER JOIN item item ON d.item_id = item.item_id
									WHERE m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' $crit
									ORDER BY $orderBy, m.VRDATE
									)
									union(
									SELECT $field as VOUCHER,item.ITEM_ID,m.ETYPE,date_format(m.VRDATE,'%d %b %y') as VRDATE,dept.name DEPT_NAME,m.DATE_TIME ,m.VRNOA, party.NAME, m.REMARKS, abs(ROUND(if(item.uom='dozen', d.QTY/12,d.QTY), 2)) QTY, ROUND(d.NETAMOUNT, 2) NETAMOUNT,item.ITEM_DES,item.UOM,d.RATE,d.AMOUNT
									FROM ordermain m
									INNER JOIN orderdetail d ON m.oid = d.oid
									INNER JOIN party party ON party.pid = m.party_id
									INNER JOIN level3 leveltbl3 ON leveltbl3.l3 = party.level3
									INNER JOIN level2 leveltbl2 ON leveltbl2.l2 = leveltbl3.l2
									INNER JOIN level1 leveltbl1 ON leveltbl1.l1 = leveltbl2.l1
									INNER JOIN user ON user.uid = m.uid
									INNER JOIN company ON company.company_id = m.company_id
									left JOIN department dept ON d.godown_id = dept.did
									INNER JOIN item item ON d.item_id = item.item_id
									WHERE m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' $crit
									ORDER BY $orderBy, m.VRDATE
									)";
		$query = $this->db->query($get_crit);
		return $query->result_array();
	}

	public function fetchStockReport($startDate, $endDate, $what , $company_id ,$crit) {

			if($what=='summary'){
				$query = $this->db->query("call spw_Inventory_Summary('$startDate', '$endDate', $crit, $company_id)");
				// return $query->result_array();
			}else if($what=='outhouse'){
				$query = $this->db->query("call spw_Inventory_Summary3('$startDate', '$endDate', $crit, $company_id)");
				// return $query->result_array();
												
			}else{
				$get_crit='';
				if ($what == 'location') {
					$get_crit='dep.name';
				}else if ($what == 'item') {
					$get_crit='i.item_des,dep.name';
				}else if ($what == 'category') {
					$get_crit='cat.name';
				}else if ($what == 'subcategory') {
					$get_crit='subcat.name';
				}else if ($what == 'brand') {
					$get_crit='b.name';
				}else if ($what == 'uom') {
					$get_crit='i.uom';
				}else if ($what == 'type') {
					$get_crit='i.barcode';
				}else if ($what == 'order') {
					$get_crit='m.workorder';
				}else if ($what == 'phase') {
					$get_crit='i.item_des,sp.name';
				}else if ($what == 'article') {
					$get_crit='i.artcile_no';
				}else if ($what == 'unit') {
					$get_crit='company.company_name';
				}
				
				$query = $this->db->query("SELECT  $get_crit as DESCRIPTION,i.artcile_no as ARTICLE,i.uom as UOM,i.item_des NAME,i.item_id, dep.NAME as dept_name ,if(i.uom='dozen', round(IFNULL(SUM(d.qty)/12,0),0),round(IFNULL(SUM(d.qty),0),0)) AS qty, ROUND(IFNULL(lp.rate,0),2) AS cost, ROUND(IFNULL(SUM(d.qty),0)* IFNULL(lp.rate,0),2) AS value
					FROM stockdetail d
					INNER JOIN item i ON i.item_id=d.item_id
					INNER JOIN brand b ON b.bid=i.bid
					INNER JOIN category cat ON cat.catid=i.catid
					INNER JOIN subcategory subcat ON subcat.subcatid=i.subcatid
					INNER JOIN stockmain m on m.stid = d.stid
					INNER JOIN company on company.company_id = m.company_id
					LEFT JOIN department dep ON dep.did = d.godown_id
					LEFT JOIN subphase  AS sp ON sp.id=d.phase_id
					LEFT JOIN (SELECT d.item_id,d.rate AS rate FROM orderdetail d WHERE d.qty>0 AND d.oid=(
					SELECT `oid` FROM orderdetail WHERE item_id=d.item_id ORDER BY oid DESC LIMIT 1) 
					GROUP BY d.item_id
					ORDER BY d.item_id ) AS lp ON lp.item_id=d.item_id
					WHERE m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' AND m.company_id<>0 $crit
					GROUP BY $get_crit,i.item_des");
												

			}
			if ( $query->num_rows() > 0 ) {
				return $query->result_array();
			} else {
				return false;
			}
												
		}

	public function fetchOrderStockReport($startDate, $endDate, $what , $company_id ,$crit, $etype) {
				$ord_etypee='';
				$stk_etypee='';

				if($etype=='all'){
					$ord_etypee=" and m.etype in('pur_order','fabricPurchaseContract','yarnPurchaseContract')";
					$stk_etypee=" and m.approved_by in('pur_order','fabricPurchaseContract','yarnPurchaseContract')";
				}else{
					$ord_etypee=" and m.etype='$etype' ";
					$stk_etypee=" and m.approved_by ='$etype' ";
				}

			
				$get_crit='';
				$get_crit_ord ='';
				$get_fd='';
				if ($what == 'location') {
					$get_crit_ord ='dep.name';
					$get_crit='dep.name';

					$get_fd='name';
				}else if ($what == 'item') {
					$get_crit_ord ='i.item_des';
					$get_crit='i.item_des';
					$get_fd='item_des';
				}else if ($what == 'category') {
					$get_crit_ord ='c.name';
					$get_crit='c.name';
					$get_fd='name';
				}else if ($what == 'subcategory') {
					$get_crit_ord ='subcat.name';
					$get_crit='subcat.name';
					$get_fd='name';
				}else if ($what == 'brand') {
					$get_crit_ord ='b.name';
					$get_crit='b.name';
					$get_fd='name';
				}else if ($what == 'uom') {
					$get_crit_ord ='i.uom';
					$get_crit='i.uom';
					$get_fd='uom';
				}else if ($what == 'type') {
					$get_crit_ord ='i.barcode';
					$get_crit='i.barcode';
					$get_fd='barcode';
				}else if ($what == 'order') {
					$get_crit_ord ='m.vrnoa';
					$get_crit='m.inv_no';
					$get_fd='inv_no';
				}else if ($what == 'workorder') {
					$get_crit_ord ='m.workorderno';
					$get_crit='m.workorder';
					$get_fd='workorder';
				}else if ($what == 'phase') {
					$get_crit_ord ='sp.name';
					$get_crit='sp.name';
					$get_fd='name';
				}else if ($what == 'article') {
					$get_crit_ord ='i.artcile_no';
					$get_crit='i.artcile_no';
					$get_fd='artcile_no';
				}else if ($what == 'unit') {
					$get_crit_ord ='company.company_name';
					$get_crit='company.company_name';
					$get_fd='company_name';
				}else if ($what == 'party') {
					$get_crit_ord ='p.name';
					$get_crit='p.name';
					$get_fd='name';
				}else if ($what == 'contract') {
					$get_crit_ord ='m.etype';
					$get_crit='m.approved_by';
					$get_fd='approved_by';
				}
				
				$query = $this->db->query("SELECT $get_crit_ord AS NAME,i.item_id AS ITEM_ID,i.item_des as DESCRIPTION,i.uom as UOM, ROUND(IFNULL(SUM(d.qty),0), 2)- ROUND(IFNULL(SUM(stk.qty),0), 2) QTY,ROUND(IFNULL(SUM(d.qty),0), 2) as ORDER_QTY, ROUND(IFNULL(SUM(stk.qty),0), 2) IN_QTY
											FROM ordermain m
											INNER JOIN orderdetail d ON m.oid = d.oid
											INNER JOIN item i ON i.item_id = d.item_id
											LEFT JOIN department dep ON dep.did = d.godown_id
											INNER JOIN category c ON c.catid = i.catid
											INNER JOIN brand b ON b.bid=i.bid
											INNER JOIN subcategory subcat ON subcat.subcatid=i.subcatid
											INNER JOIN company on company.company_id = m.company_id
											LEFT JOIN subphase  AS sp ON sp.id=d.phase_id
											LEFT JOIN party  AS p ON p.pid=m.party_id

											LEFT JOIN (
											SELECT $get_crit,i.item_id, ROUND(SUM(d.qty), 2) QTY
											FROM stockdetail d
											INNER JOIN item i ON i.item_id=d.item_id
											INNER JOIN brand b ON b.bid=i.bid
											INNER JOIN category c ON c.catid=i.catid
											INNER JOIN subcategory subcat ON subcat.subcatid=i.subcatid
											INNER JOIN stockmain m on m.stid = d.stid
											INNER JOIN company on company.company_id = m.company_id
											LEFT JOIN department dep ON dep.did = d.godown_id
											LEFT JOIN subphase  AS sp ON sp.id=d.phase_id
											LEFT JOIN party  AS p ON p.pid=m.party_id
																
											WHERE  m.etype='inward' $crit $stk_etypee AND m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."'  AND m.company_id=$company_id 
											GROUP BY $get_crit,i.item_id
														) AS stk ON stk.$get_fd=$get_crit_ord AND stk.item_id=i.item_id
											WHERE  m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' $crit $ord_etypee  AND m.company_id=$company_id 
											GROUP BY $get_crit_ord,i.item_id
											HAVING ROUND(IFNULL(SUM(d.qty),0), 2)- ROUND(IFNULL(SUM(stk.qty),0), 2)>0
											ORDER BY $get_crit_ord,i.item_id;");
												

			
			if ( $query->num_rows() > 0 ) {
				return $query->result_array();
			} else {
				return false;
			}
												
		}


	public function fetchOrderStatusReport($startDate, $endDate, $what , $company_id ,$crit) {

			
				$get_crit='';
				if ($what == 'location') {
					$get_crit='dep.name';
				}else if ($what == 'item') {
					$get_crit='i.item_des,dep.name';
				}else if ($what == 'category') {
					$get_crit='cat.name';
				}else if ($what == 'subcategory') {
					$get_crit='subcat.name';
				}else if ($what == 'brand') {
					$get_crit='b.name';
				}else if ($what == 'uom') {
					$get_crit='i.uom';
				}else if ($what == 'type') {
					$get_crit='i.barcode';
				}else if ($what == 'order') {
					$get_crit='m.workorder';
				}else if ($what == 'phase') {
					$get_crit='i.item_des,sp.name';
				}else if ($what == 'article') {
					$get_crit='i.artcile_no';
				}else if ($what == 'unit') {
					$get_crit='company.company_name';
				}else if ($what == 'party') {
					$get_crit='party.name';
				}
				
				$query = $this->db->query("SELECT $get_crit as DESCRIPTION,i.artcile_no as article,i.item_id,m.vrnoa as order_no,i.uom, i.item_des AS 'item_name',d.ctn_qty as order_ctn, round(IF(i.uom='dozen',d.qty/12,d.qty),0) AS order_qty,round(d.weight,2) AS order_weight, round(IFNULL(stk.st_weight,0),2) AS dis_weight, round(IF(i.uom='dozen', IFNULL(stk.st_qty,0)/12, IFNULL(stk.st_qty,0)),0) AS dis_qty, round(IFNULL(d.weight,0)- IFNULL(stk.st_weight,0),2) AS bal_weight, round(IF(i.uom='dozen',(IFNULL(d.qty,0)- IFNULL(stk.st_qty,0))/12, IFNULL(d.qty,0)- IFNULL(stk.st_qty,0)),0) AS bal_qty
		FROM ordermain AS m
		INNER JOIN orderdetail AS d ON m.oid = d.oid
		INNER JOIN item AS i ON i.item_id = d.item_id
		INNER JOIN brand b ON b.bid=i.bid
	    INNER JOIN category cat ON cat.catid=i.catid
		INNER JOIN subcategory subcat ON subcat.subcatid=i.subcatid
		INNER JOIN company on company.company_id = m.company_id
		left JOIN department AS dep ON dep.did = d.godown_id
		LEFT JOIN subphase  AS sp ON sp.id=d.phase_id
		INNER JOIN party party ON m.party_id = party.pid
		INNER JOIN level3 leveltbl3 ON leveltbl3.l3 = party.level3
		INNER JOIN level2 leveltbl2 ON leveltbl2.l2 = leveltbl3.l2
		INNER JOIN level1 leveltbl1 ON leveltbl1.l1 = leveltbl2.l1
			
		left join (
		SELECT m.ordno,d.item_id, ifnull(abs(sum(d.weight)),0) as st_weight, ifnull(abs(sum(d.qty)),0) as st_qty
		FROM ordermain AS m
		INNER JOIN orderdetail AS d ON m.oid = d.oid
		INNER JOIN item AS i ON i.item_id = d.item_id
		where m.etype='sale' and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' $company_id
		group by m.ordno,d.item_id
		) as stk on stk.ordno=m.vrnoa and stk.item_id=d.item_id
		where m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' AND m.company_id<>0 and  m.etype='sale_order'  and if(i.uom='kg' || i.uom='kgs',ifnull(d.weight,0)-ifnull(stk.st_weight,0)>0, ifnull(d.qty,0)-ifnull(stk.st_qty,0)>0) $crit
		group by $get_crit,m.vrnoa,i.item_des order by m.vrnoa ");
		
		// return $query->result_array();
			if ( $query->num_rows() > 0 ) {
				return $query->result_array();
			} else {
				return false;
			}

		}


	public function fetchissueReceiveReport($startDate, $endDate,$what,$company_id,$crit) {
			if($what=='summary'){
				$query = $this->db->query("call spw_Inventory_Summary2('$startDate', '$endDate', '', $company_id)");
				if ( $query->num_rows() > 0 ) {
					return $query->result_array();
				} else {
					return false;
				}
			}else{
				if ($what == 'party') {
					$query = $this->db->query("SELECT p.name DESCRIPTION,i.item_id,i.item_des NAME,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY p.name");
					
				}else if ($what == 'item') {
					$query = $this->db->query("SELECT i.item_des DESCRIPTION,p.name NAME,i.item_id,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY i.item_des");
					
				}else if ($what == 'category') {
					$query = $this->db->query("SELECT cat.name DESCRIPTION,i.item_des NAME,i.item_id,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id  INNER JOIN item i ON i.item_id= d.item_id INNER JOIN category  cat ON cat.catid = i.catid WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY cat.name");
					
				}else if ($what == 'subcategory') {
					$query = $this->db->query("SELECT subcat.name DESCRIPTION,i.item_des NAME,i.item_id,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id INNER JOIN subcategory  subcat ON subcat.subcatid = i.subcatid  WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY subcat.name");
					
				}else if ($what == 'brand') {
					$query = $this->db->query("SELECT b.name DESCRIPTION,i.item_id,i.item_des NAME,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id INNER JOIN brand b ON b.bid = i.bid WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY b.name");
					
				}else if ($what == 'uom') {
					$query = $this->db->query("SELECT i.uom DESCRIPTION,i.item_id,i.item_des NAME,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY i.uom");
					
				}else if ($what == 'type') {
					$query = $this->db->query("SELECT  i.barcode DESCRIPTION,i.item_id,i.item_des NAME,i.uom,m.workorder, if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY i.barcode");
					
				}else if ($what == 'workorder') {
					$query = $this->db->query("SELECT m.workorder DESCRIPTION,i.item_id,i.item_des NAME,i.uom,m.workorder ,if(i.uom='dozen', -round(IFNULL(SUM(d.qty)/12,0),0),-round(IFNULL(SUM(d.qty),0),0)) AS qty, IFNULL(SUM(d.weight),0) AS weight FROM stockdetail d INNER JOIN stockmain m ON m.stid = d.stid INNER JOIN party p ON p.pid= m.party_id INNER JOIN item i ON i.item_id= d.item_id WHERE  d.type<>'less' and m.etype IN ('issuetovenders','receivefromvenders','tr_consume','tr_produce','rejection','settelment') and m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' and m.company_id=$company_id  $crit  GROUP BY m.workorder,p.name,i.item_id,i.item_des,i.uom having IFNULL(SUM(d.qty),0)<>0 ORDER BY m.workorder ");
					
				}
				if ( $query->num_rows() > 0 ) {
					return $query->result_array();
				} else {
					return false;
				}
		}
			// if ($what == 'location') {
			// 	$query = $this->db->query("SELECT i.item_des as DESCRIPTION, dep.NAME, round(SUM(d.qty), 2) QTY, round(SUM(d.weight), 2) WEIGHT FROM stockmain m INNER JOIN stockdetail d ON m.stid = d.stid INNER JOIN item i ON i.item_id = d.item_id INNER JOIN department dep ON dep.did = d.godown_id WHERE m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' AND m.company_id=". $company_id ." GROUP BY d.item_id, dep.did ORDER BY dep.name");
			// 	return $query->result_array();
			// } else if ($what == 'item') {
			// 	$query = $this->db->query("SELECT i.item_des as DESCRIPTION, dep.NAME, round(SUM(d.qty), 2) QTY , round(SUM(d.weight), 2) WEIGHT FROM stockmain m INNER JOIN stockdetail d ON m.stid = d.stid INNER JOIN item i ON i.item_id = d.item_id INNER JOIN department dep ON dep.did = d.godown_id WHERE m.VRDATE BETWEEN '". $startDate ."' AND '". $endDate ."' AND m.company_id=". $company_id ." GROUP BY d.item_id, dep.did ORDER BY i.item_id");
			// 	return $query->result_array();
			// }
		}
}

/* End of file stocks.php */
/* Location: ./application/models/stocks.php */