<?php

class reportBanquets extends CI_Model
{

	public function fetchdata($datafrom,$datato,$by,$type,$crit,$check,$etype)
	{
		switch ($by) {
			
			case 'voucher':
					if ($check=='show') {
						$orderby='main.banqinid';
					} else if ($check=='hidden') {
					 $orderby='main.banqinid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'party':
					if ($check=='show') {
						$orderby='main.partyid';
					} else if ($check=='hidden') {
					 $orderby='main.partyid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'hall':
					if ($check=='show') {
						$orderby='main.hallid';
					} else if ($check=='hidden') {
					 $orderby='main.hallid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;	
			case 'event':
					if ($check=='show') {
						$orderby='main.eventid';
					} else if ($check=='hidden') {
					 $orderby='main.eventid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;	
			case 'event date':
					if ($check=='show') {
						$orderby='main.eventdate';
					} else if ($check=='hidden') {
					 $orderby='main.eventdate';
					 $crit=" main.eventdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;		
			case 'company':
					if ($check=='show') {
						$orderby='cname';
					} else if ($check=='hidden') {
					 $orderby='cname';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='month';
					} else if ($check=='hidden') {
					 	$orderby='month';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year';
					} else if ($check=='hidden') {
					 	$orderby='year';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user_f';
					} else if ($check=='hidden') {
					 	$orderby='user_f';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	
	public function fetch_byquery($datafrom,$datato,$type,$crit,$orderby)
	{
		// $etype = 'MiniBar';
		$sql2="SELECT main.banqinid,main.vrdate,p.name AS cname,user.uname AS user_f, YEAR(main.datetime) AS year, CONCAT(MONTHNAME(main.datetime),' ', YEAR(main.datetime)) AS month,h.name as hallname,ev.name as eventname,main.menu_rate,main.vrno,main.eventdate 
			FROM banquetinquiry AS main
			INNER JOIN party AS p ON main.partyid = p.id
			INNER JOIN events AS ev ON ev.id = main.eventid
			INNER JOIN hall AS h ON h.id = main.hallid
			INNER JOIN user AS user ON user.uid = main.userId
			where $crit order by $orderby asc ";

			if ($type=='Summary') {
				$sql=$sql2;
				
			} else if($type=='Detailed'){
				$sql="SELECT main.banqinid,main.vrdate,p.name AS cname,user.uname AS user_f, YEAR(main.datetime) AS year, CONCAT(MONTHNAME(main.datetime),' ', YEAR(main.datetime)) AS month,h.name AS hallname,ev.name AS eventname,main.menu_rate,main.vrno,main.eventdate,main.`status`,main.contactno,main.noofpersons,main.`status`,main.description
					FROM banquetinquiry AS main
					INNER JOIN party AS p ON main.partyid = p.id
					INNER JOIN events AS ev ON ev.id = main.eventid
					INNER JOIN hall AS h ON h.id = main.hallid
					INNER JOIN user AS user ON user.uid = main.userId
											where $crit order by $orderby asc ";
			}
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
	public function fetch_chartdata($datafrom,$datato,$by,$crit,$check)
	{
		switch ($by) {
			case 'voucher':
						if ($check=='show') {
							$orderby='main.banqinid';
						} else if ($check=='hidden') {
						 $orderby='main.banqinid';
						 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
						}
						 return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
					break;
			case 'party':
					if ($check=='show') {
						$orderby='p.name';
					} else if ($check=='hidden') {
					 $orderby='p.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'hall':
					if ($check=='show') {
						$orderby='h.name';
					} else if ($check=='hidden') {
					 $orderby='h.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;	
			case 'event':
					if ($check=='show') {
						$orderby='ev.name';
					} else if ($check=='hidden') {
					 $orderby='ev.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;	
			case 'event date':
					if ($check=='show') {
						$orderby='main.eventdate';
					} else if ($check=='hidden') {
					 $orderby='main.eventdate';
					 $crit=" main.eventdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;		
			case 'company':
					if ($check=='show') {
						$orderby='party.name';
					} else if ($check=='hidden') {
					 $orderby='party.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='concat(monthname(main.vrdate)," ",year(main.vrdate))';
					} else if ($check=='hidden') {
					 	$orderby='concat(monthname(main.vrdate)," ",year(main.vrdate))';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year(main.vrdate)';
					} else if ($check=='hidden') {
					 	$orderby='year(main.vrdate)';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user.uname';
					} else if ($check=='hidden') {
					 	$orderby='user.uname';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	public function fetch_chartbyquery($datafrom,$datato,$crit,$field)
	{
	
		$sql="SELECT ".$field." as voucher,SUM(main.menu_rate) AS rate
			FROM banquetinquiry AS main
			INNER JOIN party AS p ON main.partyid = p.id
			INNER JOIN events AS ev ON ev.id = main.eventid
			INNER JOIN hall AS h ON h.id = main.hallid
			INNER JOIN user AS user ON user.uid = main.userId
			where ".$crit." group by ".$field." order by ".$field;
			
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
}
	
?>