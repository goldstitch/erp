<?php

class Reportreservations extends CI_Model
{

	public function fetchdata($datafrom,$datato,$by,$type,$crit,$check)
	{
		switch ($by) {
			
			case 'voucher':
					if ($check=='show') {
						$orderby='main.resid';
					} else if ($check=='hidden') {
					 $orderby='main.resid';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'room no':
					if ($check=='show') {
						$orderby='roomno';
					} else if ($check=='hidden') {
					 $orderby='roomno';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'room type':
					if ($check=='show') {
						$orderby='type';
					} else if ($check=='hidden') {
					 $orderby='type';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'catagory':
					if ($check=='show') {
						$orderby='category';
					} else if ($check=='hidden') {
					 $orderby='category';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'guest':
					if ($check=='show') {
						$orderby='gname';
					} else if ($check=='hidden') {
					 $orderby='gname';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'company':
					if ($check=='show') {
						$orderby='cname';
					} else if ($check=='hidden') {
					 $orderby='cname';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.rsdate';
					} else if ($check=='hidden') {
					 	$orderby='main.rsdate';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='month';
					} else if ($check=='hidden') {
					 	$orderby='month';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year';
					} else if ($check=='hidden') {
					 	$orderby='year';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user_f';
					} else if ($check=='hidden') {
					 	$orderby='user_f';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	
	public function fetch_byquery($datafrom,$datato,$type,$crit,$orderby)
	{
		// $etype = 'MiniBar';
		$sql2="select main.resid,main.rsdate,guest.guestName as gname,room.room as roomno,party.name as cname,
				category.name as category,types.name as type,main.roomRate as roomrent,main.roomrenttax as roomrentwtax,
				user.uname as user_f,year(main.datetime) as year,
				concat(monthname(main.datetime),' ',year(main.datetime)) as month 
				from reservation as main
				inner join rooms as room on  room.id = main.roomId
				inner join guest on guest.id = main.gid
				inner join party on party.id = main.partyid
				inner join category on category.id = room.catid
				inner join types on types.id = room.typeid
				inner join user as user on user.uid = main.userId
				where $crit order by $orderby asc ";

			if ($type=='Summary') {
				$sql=$sql2;
				
			} else if($type=='Detailed'){
				$sql="select main.resid,main.rsdate,guest.guestName as gname,room.room as roomno,
						party.name as cname,category.name as category,types.name as type,
						main.arrivaldate,main.departdate as departuredate,
						main.roomRate as roomrent,main.roomrenttax as roomrentwtax,
						user.uname as user_f,year(main.datetime) as year,
						concat(monthname(main.datetime),' ',year(main.datetime)) as month 
						from reservation as main
						inner join rooms as room on  room.id = main.roomId
						inner join guest on guest.id = main.gid
						inner join party on party.id = main.partyid
						inner join category on category.id = room.catid
						inner join types on types.id = room.typeid
						inner join user as user on user.uid = main.userId
						where $crit order by $orderby asc ";
			}
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
	public function fetch_chartdata($datafrom,$datato,$by,$crit,$check)
	{
		switch ($by) {
			case 'voucher':
						if ($check=='show') {
							$orderby='main.resid';
						} else if ($check=='hidden') {
						 $orderby='main.resid';
						 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
						}
						 return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
					break;
			case 'room no':
					if ($check=='show') {
						$orderby='room.room';
					} else if ($check=='hidden') {
					 $orderby='room.room';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'room type':
					if ($check=='show') {
						$orderby='types.name';
					} else if ($check=='hidden') {
					 $orderby='types.name';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'catagory':
					if ($check=='show') {
						$orderby='category.name';
					} else if ($check=='hidden') {
					 $orderby='category.name';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'guest':
					if ($check=='show') {
						$orderby='guest.guestName';
					} else if ($check=='hidden') {
					 $orderby='guest.guestName';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'company':
					if ($check=='show') {
						$orderby='party.name';
					} else if ($check=='hidden') {
					 $orderby='party.name';
					 $crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.rsdate';
					} else if ($check=='hidden') {
					 	$orderby='main.rsdate';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='concat(monthname(main.rsdate)," ",year(main.rsdate))';
					} else if ($check=='hidden') {
					 	$orderby='concat(monthname(main.rsdate)," ",year(main.rsdate))';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year(main.rsdate)';
					} else if ($check=='hidden') {
					 	$orderby='year(main.rsdate)';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user.uname';
					} else if ($check=='hidden') {
					 	$orderby='user.uname';
					 	$crit=" main.rsdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	public function fetch_chartbyquery($datafrom,$datato,$crit,$field)
	{
	
		$sql="select $field as voucher,sum(main.roomRate) as rent,
			  sum(main.roomrenttax) as rentwtax
			  from reservation as main
			  inner join rooms as room on  room.id = main.roomId
			  inner join guest on guest.id = main.gid
			  inner join party on party.id = main.partyid
			  inner join category on category.id = room.catid
			  inner join types on types.id = room.typeid
			  inner join user as user on user.uid = main.userId
			  where $crit group by $field order by $field";
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
}
	
?>