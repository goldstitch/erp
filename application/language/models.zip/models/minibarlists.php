<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Minibarlists extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxId() {

		$this->db->select_max('id');
		$result = $this->db->get('roomservicelist');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}
	public function fetchallcatogeoryromServices() {

			$result = $this->db->get('catogeory_roomservices');
			if ( $result->num_rows() === 0 ) {
				return false;
			} else {
				return $result->result_array();
			}
	}

	public function save( $saveRSl ) {

		// $this->db->where(array('rslid' => $saveRSl['rslid']));
		// $result = $this->db->get('roomservicelist');

		// $affect = 0;
		// if ($result->num_rows() > 0) {

		// 	$this->db->where(array('rslid' => $saveRSl['rslid'] ));
		// 	$result = $this->db->update('roomservicelist', $saveRSl);
		// 	$affect = $this->db->affected_rows();
		// } else {

		// 	unset($saveRSl['rslid']);
		// 	$result = $this->db->insert('roomservicelist', $saveRSl);
		// 	$affect = $this->db->affected_rows();
		// }

		// if ($affect === 0) {
		// 	return false;
		// } else {
		// 	return true;
		// }
		$this->db->where(array('id' => $saveRSl['id'] ));
			$result = $this->db->get('roomservicelist');

			$affect = 0;
			if ($result->num_rows() > 0 ) {
				$this->db->where(array('id' => $saveRSl['id'] ));
				$affect = $this->db->update('roomservicelist',$saveRSl);
			} else {
				// unset($saveRSl['id']);
				$this->db->insert('roomservicelist', $saveRSl);
				$affect = $this->db->affected_rows();
			}
			if ( $affect === 0 ) {
				return false;
			} else {
				return true;
			}
	}

	public function fetchCheckin( $srno ) {

		$this->db->where(array('srno' => $srno));
		$result = $this->db->get('checkin');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}
	public function fetch_Enter( $id ) {

			$this->db->where(array(
									'id' => $id
								));
			$result = $this->db->get('roomservicelist');

			if ( $result->num_rows() > 0 ) {
				return $result->row_array();
			} else {
				return false;
			}
		}
	function fetch_model()
		{
			$sql 	= "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,						catogeory_roomservices.id as 'catid'
						FROM roomservicelist
						INNER JOIN catogeory_roomservices
						ON roomservicelist.cat_romId =catogeory_roomservices.id;";
			$query 	= $this->db->query($sql);
			if ($query->num_rows() != 0) {
					return $query->result_array();
			}
		}

	public function deleteCheckin( $srno ) {

		$this->db->where(array('srno' => $srno ));
		$result = $this->db->get('checkin');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$this->db->where(array('srno' => $srno ));
			$result = $this->db->delete('checkin');

			return true;
		}
	}
}

/* End of file checkins.php */
/* Location: ./application/models/checkins.php */