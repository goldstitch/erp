<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Companyrates extends CI_Model {

	public function getMaxId() {

		$this->db->select_max('id');
		$result = $this->db->get('party_rates');
		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function save( $rates, $services, $id ) {

		$this->db->where(array('id' => $id ));
		$this->db->delete('party_rates');
		$this->db->where(array('id' => $id ));
		$this->db->delete('party_services');

		$affect = 0;
		foreach ($rates as $rate) {
			$this->db->insert('party_rates', $rate);
			$affect = $this->db->affected_rows();
		}

		$affect = 0;
		foreach ($services as $service) {
			$this->db->insert('party_services', $service);
			$affect = $this->db->affected_rows();
		}
		if ( $affect == 0 ) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchRates( $id ) {

		$result = $this->db->query("SELECT party_rates.*, party.name AS 'party_name', category.name 'category_name' FROM party_rates INNER JOIN party ON party.id = party_rates.pid INNER JOIN category ON category.id = party_rates.catid WHERE party_rates.id = $id");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function fetchAllCompanyRates() {

		$result = $this->db->query("SELECT party_rates.*, party.name AS 'party_name', category.name 'category_name' FROM party_rates INNER JOIN party ON party.id = party_rates.pid INNER JOIN category ON category.id = party_rates.catid");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function fetchServiceCategory( $catid ) {

		$result = $this->db->query("SELECT * from services where catid = $catid ");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}

	public function fetchServices( $id ) {

		$result = $this->db->query("SELECT party_services.*, party.name AS 'party_name', category.name 'category_name', services.name AS 'service_name' FROM party_services INNER JOIN party ON party.id = party_services.pid INNER JOIN category ON category.id = party_services.catid INNER JOIN services ON services.id = party_services.serviceid WHERE party_services.id = $id");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}

	public function delete( $id ) {

		$this->db->where(array('id' => $id ));
		$result = $this->db->get('party_rates');

		if ($result->num_rows() == 0) {
			return false;
		} else {

			$this->db->where(array('id' => $id ));
			$this->db->delete('party_rates');
			$this->db->where(array('id' => $id ));
			$this->db->delete('party_services');

			return true;
		}
	}
	public function checkRoomRentFirstForCompany( $catid,$partyid ) {

		$result = $this->db->query("SELECT prate.srate
									FROM party_rates as prate
									WHERE prate.pid =$partyid and prate.catid=$catid");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function checkRoomRentFirstForCompanys( $roomid,$partyid ) {

		$result = $this->db->query("select pr.srate from rooms as r inner join party_rates as pr on r.catid = pr.catid where r.id=$roomid and pr.pid=$partyid");
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
}

/* End of file companyrates.php */
/* Location: ./application/models/companyrates.php */