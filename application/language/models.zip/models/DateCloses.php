<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DateCloses extends CI_Model {

	public function __construct() {
		parent::__construct();
	}	

	public function getMaxDateCloseId() {

		$this->db->select_max('id');
		$result = $this->db->get('dateclose');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function saveDateClose( $dateclose ) {

		$this->db->where(array('date_cl' => $dateclose['date_cl']));
		$result = $this->db->get('dateclose');

		$affect = 0;
		
		if ($result->num_rows() > 0) {
			return "Already Save";
		} else {
			$result = $this->db->insert('dateclose', $dateclose);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return "false";
		} else {
			return "true";
		}
	}
	public function openDateClose( $dateclose ) {

		$this->db->where(array('date_cl' => $dateclose['date_cl']));
		$result = $this->db->get('dateclose');

		$affect = 0;
		if ($result->num_rows() > 0) {
			$this->db->where(array('date_cl' => $dateclose['date_cl']));
			$affect = $this->db->delete('dateclose');
			
			$result = $this->db->insert('dateopen', $dateclose);
			$affect = $this->db->affected_rows();

		} else {
			return "Already Open";
		}

		if ($affect === 0) {
			return "false";
		} else {
			return "true";
		}
	}

	public function fetchDateClose( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('dateclose');
		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}

	public function fetchAllDateClose() {

		// $result = $this->db->get('dateclose');
		$result = $this->db->query(" select d.id, date_format(d.date_cl, '%d %b %y') as date_cl,d.remarks,d.date_time,u.uname as user_name 
									from dateclose d 
									inner join user u on u.uid=d.uid
									order by d.date_cl desc");

		// if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		// } else {
		// 	return false;
		// }
	}
}

/* End of file Departments.php */
/* Location: ./application/models/Departments.php */