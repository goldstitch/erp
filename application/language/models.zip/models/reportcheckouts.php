<?php

class Reportcheckouts extends CI_Model
{

	public function fetchdata($datafrom,$datato,$by,$type,$crit,$check)
	{
		switch ($by) {
			
			case 'voucher':
					if ($check=='show') {
						$orderby='main.vrno';
					} else if ($check=='hidden') {
					 $orderby='main.vrno';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'room no':
					if ($check=='show') {
						$orderby='main.roomno';
					} else if ($check=='hidden') {
					 $orderby='main.roomno';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'guest':
					if ($check=='show') {
						$orderby='gname';
					} else if ($check=='hidden') {
					 $orderby='gname';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'customer':
					if ($check=='show') {
						$orderby='cname';
					} else if ($check=='hidden') {
					 $orderby='cname';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='month';
					} else if ($check=='hidden') {
					 	$orderby='month';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year';
					} else if ($check=='hidden') {
					 	$orderby='year';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user_f';
					} else if ($check=='hidden') {
					 	$orderby='user_f';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	
	public function fetch_byquery($datafrom,$datato,$type,$crit,$orderby)
	{
		// $etype = 'MiniBar';
		$sql2="select main.vrno,main.vrdate,main.tamount,main.billAmount as bamount,
				guest.guestName as gname,room.room as roomno,party.name as cname,
				user.uname as user_f,year(main.datetime) as year,
				concat(monthname(main.datetime),' ',year(main.datetime)) as month 
				from checkmain as main
				inner join rooms as room on  room.id = main.roomno
				inner join guest on guest.id = main.gid
				inner join party on party.id = main.partyid
				inner join user as user on user.uid = main.userId
				where $crit and main.etype = 'checkout' order by $orderby asc ";

			if ($type=='Summary') {
				$sql=$sql2;
				
			} else if($type=='Detailed'){
				$sql="select main.vrno,main.vrdate,guest.guestName as gname,room.room as roomno,
				party.name as cname,
				main.arrdate as arrivaldate,main.depdate as departuredate,
				main.tamount,main.billAmount as bamount,
				user.uname as user_f,year(main.datetime) as year,
				concat(monthname(main.datetime),' ',year(main.datetime)) as month 
				from checkmain as main
				inner join rooms as room on  room.id = main.roomno
				inner join guest on guest.id = main.gid
				inner join party on party.id = main.partyid
				inner join user as user on user.uid = main.userId
				where $crit and main.etype = 'checkout' order by $orderby asc ";
			}
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
	public function fetch_chartdata($datafrom,$datato,$by,$crit,$check)
	{
		switch ($by) {
			case 'voucher':
						if ($check=='show') {
							$orderby='main.vrno';
						} else if ($check=='hidden') {
						 $orderby='main.vrno';
						 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
						}
						 return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
					break;
			case 'room no':
					if ($check=='show') {
						$orderby='room.room';
					} else if ($check=='hidden') {
					 $orderby='room.room';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'guest':
					if ($check=='show') {
						$orderby='guest.guestName';
					} else if ($check=='hidden') {
					 $orderby='guest.guestName';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'customer':
					if ($check=='show') {
						$orderby='party.name';
					} else if ($check=='hidden') {
					 $orderby='party.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='concat(monthname(main.vrdate)," ",year(main.vrdate))';
					} else if ($check=='hidden') {
					 	$orderby='concat(monthname(main.vrdate)," ",year(main.vrdate))';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year(main.vrdate)';
					} else if ($check=='hidden') {
					 	$orderby='year(main.vrdate)';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user.uname';
					} else if ($check=='hidden') {
					 	$orderby='user.uname';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby);
				break;

			default:
				return false;
				break;
		}
	}
	public function fetch_chartbyquery($datafrom,$datato,$crit,$field)
	{
	
		$sql="select $field as voucher,sum(main.tamount) as tamount,sum(main.billAmount) as bamount
				from checkmain as main
				inner join rooms as room on  room.id = main.roomno
				inner join guest on guest.id = main.gid
				inner join party on party.id = main.partyid
				inner join user as user on user.uid = main.userId
				where $crit group by $field order by $field asc";
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
}
	
?>