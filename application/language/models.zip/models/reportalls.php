<?php

class Reportalls extends CI_Model
{

	public function fetchdata($datafrom,$datato,$by,$type,$crit,$check,$etype)
	{
		switch ($by) {
			
			case 'voucher':
					if ($check=='show') {
						$orderby='main.stid';
					} else if ($check=='hidden') {
					 $orderby='main.stid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'room boy':
					if ($check=='show') {
						$orderby='main.roomboy';
					} else if ($check=='hidden') {
					 $orderby='main.roomboy';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'room no':
					if ($check=='show') {
						$orderby='main.roomno';
					} else if ($check=='hidden') {
					 $orderby='main.roomno';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'type':
					if ($check=='show') {
						$orderby='main.type';
					} else if ($check=='hidden') {
					 $orderby='main.type';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'item':
					if ($check=='show') {
						$orderby='item.item_des';
					} else if ($check=='hidden') {
					 $orderby='item.item_des';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'catagory':
					if ($check=='show') {
						$orderby='cat.catid';
					} else if ($check=='hidden') {
					 $orderby='cat.catid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'sub catagory':
					if ($check=='show') {
						$orderby='subcat.subcatid';
					} else if ($check=='hidden') {
					 $orderby='subcat.subcatid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'brand':
					if ($check=='show') {
						$orderby='brand.bid';
					} else if ($check=='hidden') {
					 $orderby='brand.bid';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='month(vrdate)';
					} else if ($check=='hidden') {
					 	$orderby='month(vrdate)';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year';
					} else if ($check=='hidden') {
					 	$orderby='year';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user_f';
					} else if ($check=='hidden') {
					 	$orderby='user_f';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype);
				break;

			default:
				return false;
				break;
		}
	}
	
	public function fetch_byquery($datafrom,$datato,$type,$crit,$orderby,$etype)
	{
		// $etype = 'MiniBar';
		$sql2="select main.vrno as vrno,main.vrdate,main.type,detail.amount,main.tamount
				,waiter.name as roomboy,room.room as roomno,guest.guestName,item.item_des,cat.name as catagory
				,subcat.name as sub_catagory
				,brand.name as brand,user.uname as user_f,year(main.vrdate) as year,
				concat(monthname(main.vrdate),' ',year(main.vrdate)) as month 
				from rsmain as main
				left join rsdetail as detail on detail.stid = main.stid
				inner join waiter on waiter.id = main.roomboy
				left join item on item.id = detail.item_id
				left join itemcategory as cat on cat.catid = item.catagory
				left join itemsubcategory as subcat on subcat.subcatid = item.sub_catagory
				left join brand as brand on brand.bid = item.brand
				inner join rooms as room on  room.id = main.roomNo
				inner join guest on guest.id = main.gid
				inner join user as user on user.uid = main.userId
				where $crit and etype = '$etype' order by $orderby asc";

			if ($type=='Summary') {
				$sql=$sql2;
				
			} else if($type=='Detailed'){
				$sql="select main.vrno as vrno,main.vrdate,main.type
				,waiter.name as roomboy,room.room as roomno,guest.guestName as gname,
				detail.qty,detail.rate,detail.amount,main.tamount,item.item_des,cat.name as catagory
				,subcat.name as sub_catagory
				,brand.name as brand,user.uname as user_f,year(main.vrdate) as year,
				concat(monthname(main.vrdate),' ',year(main.vrdate)) as month 
				from rsmain as main
				left join rsdetail as detail on detail.stid = main.stid
				inner join waiter on waiter.id = main.roomboy
				left join item on item.id = detail.item_id
				left join itemcategory as cat on cat.catid = item.catagory
				left join itemsubcategory as subcat on subcat.subcatid = item.sub_catagory
				left join brand as brand on brand.bid = item.brand
				inner join rooms as room on  room.id = main.roomNo
				inner join guest on guest.id = main.gid
				inner join user as user on user.uid = main.userId
				where $crit and etype = '$etype' order by $orderby asc";
			}
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
	public function fetch_chartdata($datafrom,$datato,$by,$crit,$check,$etype)
	{
		switch ($by) {
			case 'voucher':
						if ($check=='show') {
							$orderby='main.stid';
						} else if ($check=='hidden') {
						 $orderby='main.stid';
						 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
						}
						 return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
					break;
			case 'room boy':
					if ($check=='show') {
						$orderby='waiter.name';
					} else if ($check=='hidden') {
					 $orderby='waiter.name';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'room no':
					if ($check=='show') {
						$orderby='room.room';
					} else if ($check=='hidden') {
					 $orderby='room.room';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'type':
					if ($check=='show') {
						$orderby='main.type';
					} else if ($check=='hidden') {
					 $orderby='main.type';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'item':
					if ($check=='show') {
						$orderby='item.item_des';
					} else if ($check=='hidden') {
					 $orderby='item.item_des';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'catagory':
					if ($check=='show') {
						$orderby='cat.catagory';
					} else if ($check=='hidden') {
					 $orderby='cat.catagory';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'sub catagory':
					if ($check=='show') {
						$orderby='subcat.sub_catagory';
					} else if ($check=='hidden') {
					 $orderby='subcat.sub_catagory';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'brand':
					if ($check=='show') {
						$orderby='brand.brand';
					} else if ($check=='hidden') {
					 $orderby='brand.brand';
					 $crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'date':
					if ($check=='show') {
						$orderby='main.vrdate';
					} else if ($check=='hidden') {
					 	$orderby='main.vrdate';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'month':
					if ($check=='show') {
						$orderby='month(vrdate)';
					} else if ($check=='hidden') {
					 	$orderby='month(vrdate)';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'year':
					if ($check=='show') {
						$orderby='year(main.vrdate)';
					} else if ($check=='hidden') {
					 	$orderby='year(main.vrdate)';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;
			case 'user':
					if ($check=='show') {
						$orderby='user.uname';
					} else if ($check=='hidden') {
					 	$orderby='user.uname';
					 	$crit=" main.vrdate between '$datafrom' and  '$datato' ";	
					}
					return $this->fetch_chartbyquery($datafrom,$datato,$crit,$orderby,$etype);
				break;

			default:
				return false;
				break;
		}
	}
	public function fetch_chartbyquery($datafrom,$datato,$crit,$field,$etype)
	{
	
		$sql="select room.room as voucher,sum(detail.qty) as qty,sum(detail.amount) as amount 
				from rsmain as main
				left join rsdetail as detail on detail.stid = main.stid
				inner join waiter on waiter.id = main.roomboy
				left join item on item.id = detail.item_id
				left join item as cat on cat.id = item.id
				left join item as subcat on subcat.id = item.id
				left join item as brand on brand.id = item.id
				inner join rooms as room on  room.id = main.roomNo
				inner join guest on guest.id = main.gid
				inner join user as user on user.uid = main.userId
				where $crit and etype = '$etype' 
				group by $field order by $field asc";
		$q=$this->db->query($sql);

		if($q->num_rows()>0){
			return $q->result_array();
		}
		 else
		{
		 	return false;
		}
	}
}
	
?>