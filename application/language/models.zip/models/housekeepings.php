<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Housekeepings extends CI_Model {

	public function __construct() {
		parent::__construct();
	}	

	public function getMaxSrno() {

		$this->db->select_max('srnoa');
		$result = $this->db->get('housekeeping');

		$row = $result->row_array();
		$maxId = $row['srnoa'];

		return $maxId;
	}

	public function fetchhouseKeepings($id){
		//$sql	=	"SELECT * FROM housekeeping WHERE house_id = '$id' ";

		// $this->db->where('srnoa',$id);
		// $result =   $this->db->get('housekeeping');
		// if ( $result->num_rows() > 0 ) {
		// 	return $result->result_array();
		// } else {
		// 	return false;
		// }

		$sql = "select * from housekeeping inner join rooms on rooms.id=housekeeping.roomno where housekeeping.srnoa=".$id;
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
	}

	public function save( $obj ,$srnoa) {

		$this->db->where('srnoa', $srnoa);
		$result = $this->db->get('housekeeping');

		$id = '';
		if ($result->num_rows() > 0) {
			$result = $result->row_array();
			$id = $result['srnoa'];
			$this->db->where(array('srnoa' => $id));
			$this->db->delete('housekeeping');
		}


		foreach ($obj as $details) {
			//$details['serial'] = $m_v_id;
			$this->db->insert('housekeeping', $details);
			$this->deteleDirtyRooms($details['roomno']);
		}

		return true;
	}
	 public function deteleDirtyRooms($roomno)
    {
        $this->db->query("delete from dirty_rooms where roomno = '" . $roomno . "'");
    }

}

/* End of file housekeepings.php */
/* Location: ./application/models/housekeepings.php */