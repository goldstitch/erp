<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Postingdates extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function savePostingdate( $save ) {

		$result = $this->db->get('posting_date');

		if ($result->num_rows() > 0) {
			$affect = $this->db->update('posting_date',$save);
		} else {
			$affect = $this->db->insert('posting_date',$save);
		}
		if ( $affect === 0 ) {
			return false;
		} else {
			return true;
		}
	}
	public function fetchPostingdate() {

		$result = $this->db->get('posting_date');
		if ($result -> num_rows() > 0) {
			$row = $result->row_array();
			$vrdate = $row['vrdate'];
		} else {
			$vrdate = '';
		}
		
		return $vrdate;
	}
}

/* End of file categories.php */
/* Location: ./application/models/categories.php */
