<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Datechecks extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function dateChecking($vrDate)
    {
        $userId = $this->session->userdata('uid');
        $result = $this->db->query("SELECT rgid FROM `user` WHERE uid ='" . $userId . "' ");
        $row = $result->row_array();
        $rgId = $row['rgid'];

        if ($rgId != 2)
        {
            date_default_timezone_get('Asia/Karachi');
            $currentDate = date("Y/m/d");
            $previousDate = date('Y-m-d', strtotime($currentDate . ' -3 day'));

            if ($vrDate <= $currentDate && $vrDate >= $previousDate)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return true;
        }
    }
}
