<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Services extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxServiceId() {

		$this->db->select_max('id');
		$result = $this->db->get('services');

		$row = $result->row_array();
		$maxId = $row['id'];

		return $maxId;
	}

	public function saveService( $service ) {

		$this->db->where(array('id' => $service['id']));
		$result = $this->db->get('services');

		$affect = 0;
		if ($result->num_rows() > 0) {

			$this->db->where(array('id' => $service['id'] ));
			$affect = $this->db->update('services', $service);
			//$affect = $this->db->affected_rows();
		} else {

			unset($service['id']);
			$result = $this->db->insert('services', $service);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchService( $id ) {

		$this->db->where(array('id' => $id));
		$result = $this->db->get('services');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	public function fetchAllServices() {

		$result = $this->db->query("SELECT services.*, category.name AS 'category_name' FROM services INNER JOIN category ON services.catid = category.id");

		if ( $result->num_rows() > 0 ) {
			return $result->result_array();
		} else {
			return false;
		}
	}
	public function isServiceAlreadyExist($service){
		$result = $this->db->query("SELECT *
									FROM services 
									WHERE id<>".$service['id']." AND name ='".$service['name']."'");
		if ($result->num_rows() > 0) {
			return true;
		} else {
			return false;
		}

	}

}

/* End of file services.php */
/* Location: ./application/models/services.php */