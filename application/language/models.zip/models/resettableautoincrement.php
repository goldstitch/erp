<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class resettableautoincrement  extends CI_Model
{
    public function resetTableAutoIncre($tableName, $columnName)
    {
        $result = $this->db->query("SELECT MAX(" . $columnName . ") as count FROM " . $tableName . ";");
        $result = $result->result_array();
        $autoIncrement = $result[0]['count'] + 1;
        $this->db->query("ALTER TABLE " . $tableName . " AUTO_INCREMENT = " . $autoIncrement . "; ");
    }
}