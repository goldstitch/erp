<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class checkouts extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getMaxId()
    {

        $this->db->select_max('vrno');
        $result = $this->db->get('checkmain');

        $row = $result->row_array();
        $maxId = $row['vrno'];

        return $maxId;
    }

    function getyear()
    {
        $sql = "SELECT distinct year(vrdate) as year FROM `checkmain` order by vrdate desc";
        $query = $this->db->query($sql);

        if ($query->num_rows() > 0) {

            return $query->result_array();
        }
    }

    public function fetchallcatogeoryromServices()
    {

        $result = $this->db->get('catogeory_roomservices');
        if ($result->num_rows() === 0) {
            return false;
        } else {
            return $result->result_array();
        }
    }

    function save($saveMain, $saveDetail, $saveCheck)
    {
        $this->db->select('stid');
        $this->db->where(array('vrno' => $saveMain['vrno']));
        $this->db->where(array('etype' => 'checkout'));

        $vrno = $this->db->get('checkmain');
        if ($vrno->num_rows() > 0) {
            $vrno = $vrno->row_array();
            $this->db->where(array('stid' => $vrno['stid']));
            $result = $this->db->get('checkmain');
            $affect = 0;
            if ($result->num_rows() > 0) {

                $this->db->where(array('stid' => $vrno['stid']));
                $affect = $this->db->update('checkmain', $saveMain);
                $this->db->delete('checkdetail', array('stid' => $vrno['stid']));
                foreach ($saveDetail as $sd) {
                    $sd['stid'] = $vrno['stid'];
                    $this->db->insert('checkdetail', $sd);
                }
            }
        } else {
            $this->db->select('stid');
            $this->db->where(array('vrno' => $saveMain['vrno']));
            $vrno = $this->db->get('checkmain');
            $vrno = $vrno->row_array();
            unset($vrno['stid']);
            $this->db->insert('checkmain', $saveMain);
            $last_id = $this->db->insert_id();
            foreach ($saveDetail as $sd) {
                $sd['stid'] = $last_id;
                $this->db->insert('checkdetail', $sd);
            }
            $affect = $this->db->affected_rows();
        }

        $this->db->where(array('id' => $saveCheck['id']));
        $affect = $this->db->update('checkin', $saveCheck);

        $this->addDirtyRooms('1', $saveMain['roomno'], '2');
        $this->deteleCheckInDates($saveCheck['id']);

        if ($affect === 0) {
            return false;
        } else {
            return true;
        }
    }

    public function deteleCheckInDates($checkInId)
    {
        $this->db->query("delete from checkin_dates where checkin_id = '" . $checkInId . "'");
        $result = $this->db->query('select * from checkin
                                    where id = "' . $checkInId . '"');
        $result = $result->result_array();
        if (count($result) > 0) {
            $resId = $result[0]['resid'];
            if ($resId != "0") {
                $this->db->query("delete from reservation_dates where resId = '" . $resId . "'");
            }
        }
    }

    public function addDirtyRooms($affect, $roomno, $status)
    {
        if ($affect > 0) {
            $this->db->query("insert into dirty_rooms (roomno, room_status_id)
                                      values ('" . $roomno . "', '" . $status . "')");
        }
    }

    public function fetch_Enter($vrno, $etype)
    {

        // $this->db->where(array('srno' => $srno));
        // $result = $this->db->get('checkin');
        // 	 $sql = "SELECT m.vrno,m.advance,r.room,p.name partyname,ch.id AS chekinid,m.arrdate,m.depdate,m.address,m.roomno,m.gid,g.guestName,m.partyid,m.card,m.total,m.gstP,m.gst,m.extraNight,m.PreRomBal,m.compelemanatry,m.gAmount,m.advance,m.refunds,m.discount,m.discountA,m.tamount,m.cash,m.billAmount,d.date,d.bedtax,d.rent,d.telephone,d.bedtax,d.extrabed,d.minibar,d.misc,d.food,d.laundary,d.totald
        // FROM checkmain m
        // INNER JOIN checkdetail d ON m.stid = d.stid
        // INNER JOIN checkin ch ON m.roomno = ch.roomno
        // INNER JOIN party p ON p.id = ch.partyid
        // INNER JOIN guest g ON g.id = ch.gid
        // INNER JOIN rooms r ON r.id = ch.roomno
        // WHERE m.vrno =$vrno AND m.etype = '".$etype."'";
        $sql = "SELECT m.vrno,m.advance,r.room,p.name partyname,m.arrdate,m.depdate,m.address,m.roomno,
                m.gid,g.guestName,m.partyid,m.card,m.total,m.gstP,m.gst,m.extraNight,m.PreRomBal,m.compelemanatry,
                m.gAmount,m.advance,m.refunds,m.discount,m.discountA,m.tamount,m.cash,m.billAmount,d.date,d.bedtax,
                d.rent,d.telephone,d.bedtax,d.extrabed,d.minibar,d.misc,d.food,d.laundary,d.totald,m.vrdate
				FROM checkmain m
				INNER JOIN checkdetail d ON d.stid = m.stid
				INNER JOIN party p ON p.id = m.partyid
				INNER JOIN guest g ON g.id = m.gid
				INNER JOIN rooms r ON r.id = m.roomno
				WHERE m.vrno =$vrno AND m.etype = '" . $etype . "'";
        //$sql = "SELECT *
        // FROM checkmain m
        // INNER JOIN checkdetail d ON m.stid = d.stid
        // WHERE m.vrno =$vrno AND m.etype = 'checkout'";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchCompelmentary($roomno, $vrdate)
    {
        $sql = "SELECT IFNULL(sum(tamount),0) AS amount
					FROM rsmain r
					WHERE TYPE = 'Complementary' AND roomNo = '" . $roomno . "' AND
					vrdate BETWEEN '" . $vrdate . "' AND r.vrdate";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0)
        {
            $result = $result->result_array();
            $amount = $result[0]['amount'];
            return $amount;
        }
        else
        {
            return false;
        }
    }

    public function fetchCheckin($srno)
    {

        $this->db->where(array('srno' => $srno));
        $result = $this->db->get('checkin');
        if ($result->num_rows() > 0) {
            return $result->row_array();
        } else {
            return false;
        }
    }

    public function fetch_checkRoomNo($id)
    {


        // $sql = "SELECT *,m.amount as mamount FROM rsmain m
        // 		Inner join rsdetail d ON m.stid = d.stid
        // 		inner join roomservicelist r on r.id=d.item_id
        // 		WHERE m.vrno = $vrno AND etype = '$etype  ' ";
        // $sql = "SELECT * FROM checkin ch  Inner join party p ON p.id = ch.partyid Inner join guest g ON g.id = ch.gid WHERE ch.id = $id ";
        $sql = "SELECT ch.arrivaldate,ch.departuredate,ch.gid,g.guestName,ch.address,ch.cardno,ch.partyid,ch.advance,ch.roomno
					FROM checkin ch
					INNER JOIN party p ON p.id = ch.partyid
					INNER JOIN guest g ON g.id = ch.gid
					WHERE ch.id =$id";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0) {
            return $query->result_array();
        }
    }

    public function fetchNightData($RoomNo)
    {
        $sql = "SELECT ch.departuredate,ch.arrivaldate,ch.gid,g.guestName,ch.cardno,ch.address,pos.vrdate,pos.roomRate,pos.bedtaxA,pos.bedtaxP,pos.amount,pos.extraBedC,ch.partyid,p.name as party_name,ch.id as checkinid,ch.pre_amount,ch.complementry
				FROM posting pos
				INNER JOIN party p ON p.id = pos.Partyid
				INNER JOIN guest g ON g.id = pos.gid
				INNER JOIN checkin ch ON ch.id = pos.checkinID
				INNER JOIN rooms rom ON rom.id=pos.roomNo
				WHERE pos.roomNo= $RoomNo AND ch.status='checkin'
				GROUP BY pos.vrdate";
        $result = $this->db->query($sql);
        $data = array();
        if ($result->num_rows() > 0) {
            $totals = 0;
            foreach ($result->result() as $row) {
                $minibaramount  = $this->roomserviceCharges($RoomNo, 'MiniBar', $row->vrdate);
                $miscamount     = $this->roomserviceCharges($RoomNo, 'Miscalenious', $row->vrdate);
                $foodamount     = $this->roomserviceCharges($RoomNo, 'Food', $row->vrdate);
                $laundryamount  = $this->roomserviceCharges($RoomNo, 'Laundry', $row->vrdate);
                $telephoneslip  = $this->roomserviceCharges($RoomNo, 'telephoneslip', $row->vrdate);
                
                $data[] = array(
                    'checkinid'     => $row->checkinid,
                    'departuredate' => $row->departuredate,
                    'arrivaldate'   => $row->arrivaldate,
                    'guestid'       => $row->gid,
                    'guestName'     => $row->guestName,
                    'cardno'        => $row->cardno,
                    'partyid'       => $row->partyid,
                    'partyname'     => $row->party_name,
                    'address'       => $row->address,
                    'newvrdate'     => $row->vrdate,
                    'roomrent'      => $row->roomRate,
                    'bedtaxA'       => $row->amount,
                    'extraBedC'     => $row->bedtaxP,
                    'minibaramount' => $minibaramount,
                    'miscamount'    => $miscamount,
                    'foodamount'    => $foodamount,
                    'laundryamount' => $laundryamount,
                    'telephoneslip' => $telephoneslip,
                    'totals'        => $row->roomRate + $row->bedtaxA + $row->extraBedC + $minibaramount + $miscamount + $foodamount + $laundryamount + $telephoneslip,
                    'pre_amount'    => $row->pre_amount,
                    'complementry'  => $row->complementry
                );
                //$totals+=$row->roomRate+$row->bedtaxA+$row->extraBedC+$minibaramount+$miscamount+$foodamount+$laundryamount+$telephoneslip;
            }

            // foreach($data as $row){

            // }
            //die(print_r($data));
            // $sql = "SELECT *,m.amount as mamount FROM rsmain m
            // 		Inner join rsdetail d ON m.stid = d.stid
            // 		inner join roomservicelist r on r.id=d.item_id
            // 		WHERE m.vrno = $vrno AND etype = '$etype  ' ";
            // $sql = "SELECT *,ifnull(food.amount,0) as foodamount, ifnull(minibar.amount,0) as minibaramount,ifnull(laundry.amount,0) as laundryamount, ifnull(misc.amount,0) as miscamount,pos.vrdate as newvrdate FROM posting pos Inner join party p on p.id = pos.Partyid  Inner join guest g ON g.id = pos.gid inner join checkin ch on ch.id = pos.checkinID inner join rooms rom on rom.id=pos.roomNo
            // left join(select ifnull(sum(tamount),0)-ifnull(sum(discount),0) as amount,vrdate,roomno from rsmain where etype='food' group by vrdate,roomno) as food on food.roomNo= rom.id and food.vrdate=pos.vrdate
            // left join(select ifnull(sum(tamount),0)-ifnull(sum(discount),0) as amount,vrdate,roomno from rsmain where etype='minibar' group by vrdate,roomno) as minibar on minibar.roomNo= rom.id and minibar.vrdate=pos.vrdate
            // left join(select ifnull(sum(tamount),0)-ifnull(sum(discount),0) as amount,vrdate,roomno from rsmain where etype='laundry' group by vrdate,roomno) as laundry on laundry.roomNo= rom.id and laundry.vrdate=pos.vrdate
            // left join(select ifnull(sum(tamount),0)-ifnull(sum(discount),0) as amount,vrdate,roomno from rsmain where etype='misc' group by vrdate,roomno) as misc on misc.roomNo= rom.id and misc.vrdate=pos.vrdate
            // WHERE pos.roomNo = $RoomNo and ch.status='checkin'";
            // $sql ="SELECT *, IFNULL(food.amount,0) AS foodamount, IFNULL(minibar.amount,0) AS minibaramount, IFNULL(laundry.amount,0) AS laundryamount, IFNULL(misc.amount,0) AS miscamount,IFNULL(telephoneslip.amount,0) as telephoneslip,pos.vrdate AS newvrdate
            // 	FROM posting pos
            // 	INNER JOIN party p ON p.id = pos.Partyid
            // 	INNER JOIN guest g ON g.id = pos.gid
            // 	INNER JOIN checkin ch ON ch.id = pos.checkinID
            // 	INNER JOIN rooms rom ON rom.id=pos.roomNo
            // 	LEFT JOIN(
            // 	SELECT IFNULL(SUM(tamount),0)- IFNULL(SUM(discount),0) AS amount,vrdate,roomno
            // 	FROM rsmain
            // 	WHERE etype='food'
            // 	GROUP BY vrdate,roomno) AS food ON food.roomNo= rom.id AND food.vrdate=pos.vrdate
            // 	LEFT JOIN(
            // 	SELECT IFNULL(SUM(tamount),0)- IFNULL(SUM(discount),0) AS amount,vrdate,roomno
            // 	FROM rsmain
            // 	WHERE etype='minibar'
            // 	GROUP BY vrdate,roomno) AS minibar ON minibar.roomNo= rom.id AND minibar.vrdate=pos.vrdate
            // 	LEFT JOIN(
            // 	SELECT IFNULL(SUM(tamount),0)- IFNULL(SUM(discount),0) AS amount,vrdate,roomno
            // 	FROM rsmain
            // 	WHERE etype='laundry'
            // 	GROUP BY vrdate,roomno) AS laundry ON laundry.roomNo= rom.id AND laundry.vrdate=pos.vrdate
            // 	LEFT JOIN(
            // 	SELECT amount,vrdate,roomno
            // 	FROM rsmain
            // 	WHERE etype='telephoneslip'
            // 	GROUP BY vrdate,roomno) AS telephoneslip ON telephoneslip.roomNo= rom.id AND telephoneslip.vrdate=pos.vrdate
            // 	LEFT JOIN(
            // 	SELECT IFNULL(SUM(tamount),0)- IFNULL(SUM(discount),0) AS amount,vrdate,roomno
            // 	FROM rsmain
            // 	WHERE etype='misc'
            // 	GROUP BY vrdate,roomno) AS misc ON misc.roomNo= rom.id AND misc.vrdate=pos.vrdate
            // 	WHERE pos.roomNo = $RoomNo AND ch.status='checkin'";
            // 	$query 	= $this->db->query($sql);
            // 	if ($query->num_row[') != 0) {
            // 			return $query->result_array();
            //die(print_r($data));
            return $data;
        } else {
            return false;
        }
    }

    public function roomserviceCharges($room, $etype, $vrdate)
    {
        $sql = "SELECT IFNULL(SUM(r.tamount),0) AS amount,r.vrdate,r.roomno
					FROM rsmain r inner join posting p on p.roomno=r.roomNo
					WHERE r.etype='" . $etype . "' and p.roomno=$room and p.vrdate='$vrdate' and r.vrdate= '$vrdate' and r.`type`='Bill'
					GROUP BY r.vrdate,p.roomno";
        $query = $this->db->query($sql);
        // if ($query->num_rows() != 0) {

        // 	return $query->result_array();
        // }
        if ($query->num_rows() > 0) {
            $result = $query->result_array();

            $amount = $result[0]['amount'];
            //die($amount);
            // foreach($query->result() as $row)
            // {
            return $amount;
            // }
        } else {
            return 0;
        }
    }

    function fetch_model()
    {
        $sql = "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,						catogeory_roomservices.id as 'catid'
					FROM roomservicelist
					INNER JOIN catogeory_roomservices
					ON roomservicelist.cat_romId =catogeory_roomservices.id;";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0) {
            return $query->result_array();
        }
    }

    public function fetchDetailedVoucher($vrno, $etype)
    {
        $query = $this->db->query("SELECT *,r.name as itemName,m.amount as mamount  FROM rsmain m
					Inner join rsdetail d ON m.stid = d.stid
					inner join roomservicelist r on r.id=d.item_id
					inner join waiter w on w.waiter_id = m.roomboy
					inner join guest g on g.gid = m.gid  
					WHERE m.vrno = $vrno AND etype = '$etype'");
        return $query->result_array();
    }

    function fetchParticulars($name)
    {
        //$sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
        $sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId in (select id from catogeory_roomservices where name like '$name')";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0) {
            return $query->result_array();
        }
    }

    function fetchParticularsAll()
    {
        $sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
        //$sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId in (select id from catogeory_roomservices where name like '$name')" ;
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0) {
            return $query->result_array();
        }
    }


    public function deleteCheckin($srno)
    {

        $this->db->where(array('srno' => $srno));
        $result = $this->db->get('checkin');

        if ($result->num_rows() == 0) {
            return false;
        } else {
            $this->db->where(array('srno' => $srno));
            $result = $this->db->delete('checkin');

            return true;
        }
    }

    public function delete($vrno, $etype , $company_id)
    {//, $company_id) {

        $this->db->where(array('etype' => $etype, 'dcno' => $vrno , 'company_id' => $company_id ));
        $this->db->delete('pledger');

        $this->db->where(array('etype' => $etype, 'vrno' => $vrno)); //, 'company_id' => 1 ));
        $result = $this->db->get('checkmain');

        if ($result->num_rows() == 0) {
            return false;
        } else {

            $result = $result->row_array();
            $stid = $result['stid'];

            $this->db->where(array('etype' => $etype, 'vrno' => $vrno));
            $this->db->delete('checkmain');
            $this->db->where(array('stid' => $stid));
            $this->db->delete('checkdetail');

            return true;
        }
    }
}

/* End of file checkins.php */
/* Location: ./application/models/checkins.php */