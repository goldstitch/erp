<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Banquetreservations extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxId() {

		$this->db->select_max('vrno');
		$result = $this->db->get('banq_res');

		$row = $result->row_array();
		$maxId = $row['vrno'];

		return $maxId;
	}
	public function getMaxgId() {

		$this->db->select_max('gid');
		$result = $this->db->get('guest');

		$row = $result->row_array();
		$maxId = $row['gid'];

		return $maxId;
	}
	public function fetchallcatogeoryromServices() {

			$result = $this->db->get('catogeory_roomservices');
			if ( $result->num_rows() === 0 ) {
				return false;
			} else {
				return $result->result_array();
			}
	}

    public function save($banquetsaveReservation,$banquetsavedeatailMenu,$banquetsavedeatailAdd)
	{
		
		//die(print($rowtime));

		$this->db->select('banqresid');
		$this->db->where(array('vrno' => $banquetsaveReservation['vrno'] ));
		$this->db->where(array('etype' => 'banquetreservation' ));

		$vrno = $this->db->get('banq_res');
		if ($vrno->num_rows() > 0) {
			$vrno = $vrno->row_array();
			$this->db->where(array('banqresid' => $vrno['banqresid'] ));
			$result = $this->db->get('banq_res');
			$affect = 0;
			if ($result->num_rows() > 0 ) {

				$this->db->where(array('banqresid' => $vrno['banqresid'] ));
				$affect 	= $this->db->update('banq_res',$banquetsaveReservation);
				$this->db->delete('banq_resmenu', array('banqresid' => $vrno['banqresid'])); 
				$this->db->delete('banq_resadd', array('banqresid' => $vrno['banqresid'])); 

				foreach ($banquetsavedeatailMenu as $sd) 
				{
					$sd['banqresid'] = $vrno['banqresid'];
					$this->db->insert('banq_resmenu',$sd);				
				}
				foreach ($banquetsavedeatailAdd as $sd) 
				{
					$sd['banqresid'] = $vrno['banqresid'];
					$this->db->insert('banq_resadd',$sd);				
				}
			}
		} else {
			$this->db->select('banqresid');
			$this->db->where(array('vrno' => $banquetsaveReservation['vrno'] ));
			$vrno = $this->db->get('banq_res');
			$vrno = $vrno->row_array();
			unset($vrno['banqresid']);
			$this->db->insert('banq_res', $banquetsaveReservation);
			$last_id	= $this->db->insert_id();
			foreach ($banquetsavedeatailMenu as $sd)
			 {
			 	$sd['banqresid'] = $last_id;
				$this->db->insert('banq_resmenu',$sd);				
			 }
			foreach ($banquetsavedeatailAdd as $sd) 
			{
				$sd['banqresid'] = $last_id;
				$this->db->insert('banq_resadd',$sd);				
			}
			$affect = $this->db->affected_rows();
		}


		if ( $affect === 0 ) {
			return false;
		} else {
			return true;
		}
	}

    public function saveGuest($saveGuestM)
	{
	
		$this->db->select('gid');
		$this->db->where(array('gid' => $saveGuestM['gid'] ));

		$gid = $this->db->get('guest');
		if ($gid->num_rows() > 0) {
			$gid = $gid->row_array();
			$this->db->where(array('gid' => $gid['gid'] ));
			$result = $this->db->get('guest');
			$affect = 0;
			if ($result->num_rows() > 0 ) {
				$this->db->where(array('gid' => $gid['gid'] ));
				$affect 	= $this->db->update('guest',$saveGuestM);
			}
		} else {
			$this->db->insert('guest', $saveGuestM);
			$affect = $this->db->affected_rows();
		}


		if ( $affect === 0 ) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchCheckin( $srno ) {

		$this->db->where(array('srno' => $srno));
		$result = $this->db->get('checkin');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}
	public function fetch_EnterMenu( $vrno ) {
		$sql = "SELECT *
				FROM banq_res b
				inner join  banq_resadd as br on br.banqresid = b.banqresid
				inner join banq_resmenu as brm on brm.banqresid= b.banqresid
				WHERE b.vrno = $vrno AND b.etype = 'banquetreservation'";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}

	public function fetch( $vrno ) {

		$sql = "SELECT *,br.item_name AS product_name,b.other_tamount AS tamount,b.tamount AS totalamount,p.name as party_name,h.name hall_name,ev.name as event_name
				FROM banq_res b
				INNER JOIN banq_resadd AS br ON br.banqresid = b.banqresid
				INNER JOIN banq_resmenu AS brm ON brm.banqresid= b.banqresid
				inner join party as p on p.id = b.partyid
				inner join hall as h on h.id = b.hallid
				inner join events ev on ev.id = b.eventid
				WHERE b.vrno ='".$vrno."' AND b.etype = 'banquetreservation'";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
		else{
			return false;	
		}
	}


	public function fetch_model()
	{
		$sql 	= "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,						catogeory_roomservices.id as 'catid'
					FROM roomservicelist
					INNER JOIN catogeory_roomservices
					ON roomservicelist.cat_romId =catogeory_roomservices.id;";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}
		
	public	function fetchAllMenuItems()
	{
		$sql 	= "select distinct item_menu from  banq_resmenu;";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}

	public	function fetchAllOtherItems()
	{
		$sql 	= "select distinct item_name from banq_resadd;";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}

	public function fetchallGuest()
	{
		$sql 	= "SELECT * FROM guest";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}

	public function fetch_guesttbl($gid)
	{
		$sql 	= "SELECT * FROM guest WHERE gid = $gid";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}

	public function fetchDetailedVoucher( $vrno, $etype )
	{
		$query = $this->db->query("SELECT * FROM stockmain m 
					Inner join stockdetail d ON m.stid = d.stid
					inner join roomservicelist r on r.id=d.item_id
					inner join waiter w on w.waiter_id = m.roomboy
					WHERE m.vrno = $vrno AND etype = 'miniBar'");
		return $query->result_array();
	}
	public function fetchParticulars()
	{
		$sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}


	public function deleteCheckin( $srno ) {

		$this->db->where(array('srno' => $srno ));
		$result = $this->db->get('checkin');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$this->db->where(array('srno' => $srno ));
			$result = $this->db->delete('checkin');
			return true;
		}
	}
	public function delete( $vrno, $etype , $company_id ) {

		$this->db->where(array('etype' => $etype, 'dcno' => $vrno , 'company_id' => $company_id ));
        $this->db->delete('pledger');
        
		$this->db->where(array('vrno' => $vrno ));
		$result = $this->db->get('banq_res');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$result = $result->row_array();
			$banqresid = $result['banqresid'];
			$this->db->where(array('vrno' => $vrno ));
			$result = $this->db->delete('banq_res');
			$this->db->where(array('banqresid' => $banqresid ));
			$result = $this->db->delete('banq_resadd');
			$this->db->where(array('banqresid' => $banqresid ));
			$result = $this->db->delete('banq_resmenu');


			return true;
		}
	}

	public function fetch_Inquiry($vrno)
    {
        $sql = "SELECT  *, banquetinquiry.status as status_inquiry, banquetinquiry.address as inquery_address,banquetinquiry.vrno as inqno
                from banquetinquiry
                left join banquetinquirydetail
                  on banquetinquiry.banqinid = banquetinquirydetail.banqinid
                left join banquet_inquiry_menu
                  on banquet_inquiry_menu.banquet_inquiry_id = banquetinquiry.banqinid
				inner join  party
				  on banquetinquiry.partyid = party.id
				where banquetinquiry.vrno = '" . $vrno . "' and  banquetinquiry.etype = 'banquetinquiry' AND banquetinquiry.`status`='1' AND banquetinquiry.vrno not in (select inqno from banq_res)";
        $query = $this->db->query($sql);
        if ($query->num_rows() != 0)
        {
            return $query->result_array();
        }
    }

    public function fetchHallAvailability($from, $to)
    {
        $sql = "select br.eventdate,br.partyid,p.name as party_name,br.eventid,e.name as event_name,br.timefrom,br.timeto,br.hallid,h.name as hall_name 
				from banq_res br 
				inner join hall h on br.hallid = h.id
				inner join events e on br.eventid = e.id
				inner join party p on br.partyid = p.id
				where br.eventdate between '".$from."' and '".$to."'";
        $result = $this->db->query($sql);
        $data = array();
        if ($result->num_rows() > 0)
        {
            foreach ($result->result() as $row)
            {
                $data[] = array(
                    'eventdate'		=> $row->eventdate,
                    'party_name' 	=> $row->party_name,
                    'event_name' 	=> $row->event_name,
                    'timefrom' 		=> $row->timefrom,
                    'timeto' 		=> $row->timeto,
                    'hall_name' 	=> $row->hall_name
                );
            }
            return $data;
        }
        else
        {
            return false;
        }
    }

}

/* End of file checkins.php */
/* Location: ./application/models/checkins.php */