<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Checkins extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getMaxId()
    {
        $this->db->select_max('id');
        $result = $this->db->get('checkin');

        $row = $result->row_array();
        $maxId = $row['id'];

        return $maxId;
    }

    function getyear()
    {
        $sql = "SELECT distinct year(datetime) as year FROM `checkin` order by datetime desc";
        $query = $this->db->query($sql);

        if ($query->num_rows() > 0) {

            return $query->result_array();
        }
    }

    public function getMaxIdgetMaxIdPosting()
    {
        $this->db->select_max('vrno');
        $result = $this->db->get('posting');

        $row = $result->row_array();
        $maxId = $row['vrno'];

        return $maxId;
    }

    public function saveCheckin($checkin, $saveGuest, $arrivalDate, $departureDate)
    {
        $daysArray = $this->getdays->getTDays($arrivalDate, $departureDate);

        $this->db->where(array('id' => $checkin['id']));
        $result = $this->db->get('checkin');
        $affect = 0;
        if ($result->num_rows() > 0) {
            $checkid = $result->row_array();
            $this->db->where(array('id' => $checkid['id']));
            $result = $this->db->update('checkin', $checkin);
            $affect = $this->db->affected_rows();
            unset($saveGuest['id']);
            $this->db->where(array('id' => $checkid['gid']));
            $this->db->update('guest', $saveGuest);

            $this->deteleCheckInDates($checkid['id']);
            $this->addCheckInDates('1', $daysArray, $checkid['id'], $checkid['resid'], $checkin['roomno']);
        } else {

            unset($checkin['id']);
            $result = $this->db->insert('checkin', $checkin);
            //$affect = $this->db->affected_rows();
            $last_id = $this->db->insert_id();

            $this->db->where(array('id' => $last_id));
            $result = $this->db->get('checkin');
            if ($result->num_rows() > 0) {
                $checkid = $result->row_array();
            }

            $this->db->where(array('id' => $checkid['gid']));
            $result = $this->db->get('guest');
            $affect = 0;
            if ($result->num_rows() > 0) {
                $gid = $result->row_array();
                $this->db->where(array('id' => $gid['id']));
                $affect = $this->db->update('guest', $saveGuest);
            }
            else
            {
                $this->db->insert('guest', $saveGuest);
            }

            $reservationRoom = $this->getReservationRoomId($checkid['resid']);
            if(($reservationRoom != $checkin['roomno']) && $checkin['resid'] != "" && $checkin['resid'] != "0")
            {
                $this->deleteReservationDates($checkid['resid']);
            }
            $affect = $this->db->affected_rows();

            $this->addCheckInDates('1', $daysArray, $checkid['id'], $checkid['resid'], $checkin['roomno']);
        }


        if ($affect === 0) {
            return false;
        } else {
            return true;
        }
    }

    public function getReservationRoomId($reservationId)
    {
        $sql = "SELECT roomId from reservation where resid = '". $reservationId ."' ";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0)
        {
            $result = $result->result_array();
            return $result[0]['roomId'];
        }
        else
        {
            return "";
        }
    }

    public function deleteReservationDates($reservationId)
    {
        $this->db->query("delete from reservation_dates where resid = '" . $reservationId . "'");
    }

    public function addCheckInDates($affect, $daysArray, $checkid, $resId, $roomId)
    {
        if ($affect > 0) {
            foreach ($daysArray as $key => $row) {
                $this->db->query("insert into checkin_dates (checkin_id, resid, roomno, checkin_date)
                                      values ('" . $checkid . "', '" . $resId . "', '" . $roomId . "', '" . $row . "')");
            }
        }
    }

    public function deteleCheckInDates($checkInId)
    {
        $this->db->query("delete from checkin_dates where checkin_id = '" . $checkInId . "'");
    }

    public function savePosting($saveDetail)
    {
        $this->db->select('vrno');
        $this->db->where(array('vrno' => $saveDetail[0]['vrno']));

        $vrno = $this->db->get('posting');
        $affect = 0;
        if ($vrno->num_rows() > 0) {
            $vrno = $vrno->row_array();
            $this->db->delete('posting', array('vrno' => $vrno['vrno']));
            $affect = 1;
            foreach ($saveDetail as $sd) {
                $sd['vrno'] = $vrno['vrno'];
                $this->db->insert('posting', $sd);
            }

        } else {

            $this->db->select_max('vrno');
            $result = $this->db->get('posting');

            $row = $result->row_array();
            $maxId = $row['vrno'] + 1;
            // $this->db->select('vrno');
            // $this->db->where(array('vrno' => $saveMain['vrno'] ));
            // $vrno = $this->db->get('posting');
            // $vrno = $vrno->row_array();
            // unset($vrno['poid']);
            // $this->db->insert('posting', $saveMain);
            // $last_id	= $this->db->insert_id();
            foreach ($saveDetail as $sd) {
                $sd['vrno'] = $maxId;
                $this->db->insert('posting', $sd);
            }
            $affect = $this->db->affected_rows();
        }


        if ($affect === 0) {
            return false;
        } else {
            return true;
        }
    }

    /*public function savePosting( $saveMain,$saveDetail ) {

                    $this->db->select('pid');
                    $this->db->where(array('vrno' => $saveMain['vrno'] ));

                    $vrno = $this->db->get('postingmain');
                    if ($vrno->num_rows() > 0) {
                            $vrno = $vrno->row_array();

                                $this->db->where(array('pid' => $vrno['pid'] ));
                                $result = $this->db->get('postingmain');
                                $affect = 0;
                                if ($result->num_rows() > 0 ) {

                                    $this->db->where(array('pid' => $vrno['pid'] ));
                                    $affect 	= $this->db->update('postingmain',$saveMain);
                                    $this->db->delete('posting', array('pid' => $vrno['pid']));
                                    foreach ($saveDetail as $sd)
                                    {
                                        $sd['pid'] = $vrno['pid'];
                                        $this->db->insert('posting',$sd);
                                    }
                                }
                    // $vrnoa = $vrnoa->row_array();

                    // $this->db->where(array('pid' => $vrnoa['pid'] ));
                    // $result = $this->db->get('postingmain');
                    // $affect = 0;
                    // if ($result->num_rows() > 0 ) {

                    // 	$this->db->where(array('pid' => $vrnoa['pid'] ));
                    // 	$affect 	= $this->db->update('postingmain',$saveMain);
                    // 	$this->db->delete('posting', array('pid' => $vrnoa['pid']));
                    // 	foreach ($saveDetail as $sd)
                    // 	{
                    // 		$this->db->insert('posting',$sd);
                    // 	}
                    } else {
                        $this->db->select('pid');
                        $this->db->where(array('vrno' => $saveMain['vrno'] ));
                        $vrno = $this->db->get('postingmain');
                        $vrno = $vrno->row_array();
                        unset($vrno['pid']);
                        $this->db->insert('postingmain', $saveMain);
                        $last_id	= $this->db->insert_id();
                        foreach ($saveDetail as $sd)
                         {
                             $sd['pid'] = $last_id;
                            $this->db->insert('posting',$sd);
                         }
                        $affect = $this->db->affected_rows();
                    }


                    if ( $affect === 0 ) {
                        return false;
                    } else {
                        return true;
                    }
    }*/

    public function fetchCheckin($id)
    {
        // $this->db->where(array('id' => $id));
        // $result = $this->db->get('checkin');
        $sql = "SELECT *,p.name as partyname,ch.partyid as partys,t.name as typename,ch.address as adres,ch.advance,ch.extrabedcharges as extrabed,ch.bedtaxperc as bedtax,ch.extrabedcharges as chextrabedcharges from checkin ch inner join  party p on ch.partyid =  p.id 	inner join  guest g on g.id =  ch.gid INNER JOIN rooms r on r.id = ch.roomno INNER JOIN types t on t.id = r.typeid
				where ch.id = $id";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchRoomAvailability($checkin, $checkout)
    {
        $sql = "SELECT r.id as room_id, r.room, r.statusid, t.name typename, cat.name catname, rms.roomstatus as roomstatus
				FROM rooms r
				INNER JOIN types t ON t.id = r.typeid
				INNER JOIN category cat ON cat.id = r.catid
				left join roomstatus rms on rms.rmstatusid = r.statusid
				ORDER BY r.id asc";
        $result = $this->db->query($sql);
        $daysArray = $this->getdays->getTDays($checkin, $checkout);

        $data = array();
        if ($result->num_rows() > 0)
        {
            foreach ($result->result() as $row)
            {
                $roomStatus = "FREE";
                $departureDate = "-";
                $checkinStatus = $this->getCkeckInStatus($row->room_id, $daysArray);
                $reservationStatus = $this->getReservationStatus($row->room_id, $daysArray);
                if($checkinStatus['checkin_status'] == "CheckedIn")
                {
                    $roomStatus = "CHECKIN";
                    $departureDate = $checkinStatus['departure_date'];
                }
                elseif($reservationStatus['reservation_status'] == "Reserved")
                {
                    $roomStatus = "RESERVED";
                    $departureDate = $reservationStatus['departure_date'];
                }

                if($roomStatus == "FREE")
                {
                    $dirtyStatus = $this->getDirtyStatus($row->room_id);
                    if($dirtyStatus == '1')
                    {
                        $roomStatus = "DIRTY";
                    }
                }

                $data[] = array(
                    'room' => $row->room,
                    'typename' => $row->typename,
                    'catname' => $row->catname,
                    'departdate' => $departureDate,
                    'roomstatus' => $roomStatus
                );
            }
            return $data;
        }
        else
        {
            return false;
        }
    }

    public function getReservationStatus($roomId, $daysArray)
    {
        $data = array();
        $data['reservation_status'] = "Not Reserve";
        $data['departure_date'] = '-';

        foreach($daysArray as $date)
        {
            $result = $this->db->query('select * from reservation_dates
                                    where roomId = "' . $roomId . '" and reservation_date = "' . $date . '"');
            $result = $result->result_array();

            if (count($result) > 0)
            {
                $data['reservation_status'] = "Reserved";
                $resDepartDate = $this->db->query('select departdate from reservation where resid = "' . $result[0]['resid'] . '"');
                $resDepartDate = $resDepartDate->result_array();
                $data['departure_date'] = $resDepartDate[0]['departdate'];
                break;
            }
        }
        return $data;
    }

    public function getCkeckInStatus($roomId, $daysArray)
    {
        $data = array();
        $data['checkin_status'] = "Not Check In";
        $data['departure_date'] = '-';

        foreach($daysArray as $date)
        {
            $result = $this->db->query('select * from checkin_dates
                                    where roomno = "' . $roomId . '" and checkin_date = "' . $date . '"');
            $result = $result->result_array();

            if (count($result) > 0)
            {
                $data['checkin_status'] = "CheckedIn";
                $resDepartDate = $this->db->query('select departuredate from checkin where id = "' . $result[0]['checkin_id'] . '"');
                $resDepartDate = $resDepartDate->result_array();
                $data['departure_date'] = $resDepartDate[0]['departuredate'];
            }
        }
        return $data;
    }

    public function fetch_EnterPosting($vrno)
    {
        // $this->db->where(array('id' => $id));
        // $result = $this->db->get('checkin');
        // $sql = "SELECT * from posting pos inner join  party p on pos.Partyid =  p.id 	inner join  guest g on g.id =  pos.gid
        // 		where pos.vrno = $vrno";
        // $sql = "SELECT *,r.room as roomsno,pos.checkinID as checkinid
        // 		FROM posting pos
        // 		INNER JOIN party p ON pos.Partyid = p.id
        // 		INNER JOIN guest g ON g.id = pos.gid
        // 		INNER JOIN rooms r ON r.id = pos.roomno
        // 		WHERE pos.vrno = $vrno";

        $sql = "SELECT  pos.partyid,p.name,pos.checkinID,g.guestName,pos.gid,pos.roomno,pos.roomRate,pos.bedtaxp,
                pos.bedtaxA,pos.amount,pos.gstp,pos.gstA,pos.gAmount,pos.extraBedC,pos.arrDate,pos.depDate,
                r.room AS roomsno,pos.checkinID AS checkinid,pos.vrdate as voucherdate
				FROM posting pos
				INNER JOIN party p ON pos.partyid = p.id
				INNER JOIN guest g ON g.id = pos.gid
				INNER JOIN rooms r ON r.id = pos.roomno
				WHERE pos.vrno = '" . $vrno . "' ";
        $result = $this->db->query($sql);
        if ($result->num_rows() > 0) {
            return $result->result_array();
        } else {
            return false;
        }
    }

    public function fetchNightPosting($date)
    {
    //     $sql = "SELECT ch.arrivaldate,ch.departuredate,ch.gid,ch.roomno,rooms.room,ch.roomrent,ch.bedtaxperc,
    //             ch.bamount,ch.gstperc,ch.gst,ch.extrabedcharges AS extrabed,g.guestName,ch.id checkinid,
    //             p.name AS company_name,ch.partyid AS party,(ch.roomrent + ch.bamount + ch.extrabedcharges) AS amount, ROUND(((ch.gstperc * (ch.roomrent + ch.extrabedcharges + ch.bamount)) / 100),2) AS mygst, ROUND((((ch.gstperc * (ch.roomrent + ch.extrabedcharges + ch.bamount)) / 100) +(ch.roomrent + ch.extrabedcharges + ch.bamount)),2) AS mygstamnt,
    //             p.name AS company_name,rooms.id AS roomid
    //             FROM checkin ch
    //             INNER JOIN party p ON ch.partyid = p.id
    //             INNER JOIN guest g ON g.id = ch.gid
    //             INNER JOIN rooms ON rooms.id=ch.roomno
    //             INNER JOIN checkin_dates ON checkin_dates.roomno = ch.roomno AND checkin_dates.checkin_id = ch.id
				// WHERE checkin_dates.checkin_date = '".$date."'";
        $sql = "SELECT ch.arrivaldate,ch.departuredate,ch.gid,ch.roomno,rooms.room,ch.roomrent,ch.bedtaxperc,
                 ch.bamount,ch.gstperc,ch.gst,ch.extrabedcharges AS extrabed,g.guestName,ch.id checkinid,
                 p.name AS company_name,ch.partyid AS party,(ch.roomrent + ch.bamount + ch.extrabedcharges) AS amount, 
                 p.name AS company_name,rooms.id AS roomid,(ch.roomrent +  ch.extrabedcharges) AS amount,ch.bedtaxperc,ch.bamount,ch.gstperc,ch.gst AS mygst,ch.roomrentwtax as mygstamnt
                FROM checkin ch
                INNER JOIN party p ON ch.partyid = p.id
                INNER JOIN guest g ON g.id = ch.gid
                INNER JOIN rooms ON rooms.id=ch.roomno
                INNER JOIN checkin_dates ON checkin_dates.roomno = ch.roomno AND checkin_dates.checkin_id = ch.id
                WHERE checkin_dates.checkin_date = '".$date."'";

        $result = $this->db->query($sql);
        if ($result->num_rows() > 0)
        {
            return $result->result_array();
        }
        else
        {
            return false;
        }
    }

    public function checkDateNightPosting($dates, $vrno)
    {
        $result = $this->db->query("SELECT *
									FROM posting 
									WHERE vrno<>" . $vrno . " AND vrdate ='$dates'");
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }

    }

    public function deleteCheckin($id , $company_id)
    {
        $this->db->where(array('etype' => 'checkin', 'dcno' => $id , 'company_id' => $company_id ));
        $this->db->delete('pledger');

        $this->db->where(array('id' => $id));
        $result = $this->db->get('checkin');

        if ($result->num_rows() == 0)
        {
            return false;
        }
        else
        {
            $this->db->where(array('id' => $id));
            $result = $this->db->delete('checkin');
            $this->deteleCheckInDates($id);
            $this->resettableautoincrement->resetTableAutoIncre('checkin', 'id');
            return true;
        }
    }

    public function deletePosting($vrno)
    {
        $this->db->where(array('vrno' => $vrno));
        $result = $this->db->get('posting');

        if ($result->num_rows() == 0) {
            return false;
        } else {
            $this->db->where(array('vrno' => $vrno));
            $result = $this->db->delete('posting');

            return true;
        }
    }

    public function isRoomAvailable($checkin, $arrivalDate, $departureDate)
    {
        $daysArray = $this->getdays->getTDays($arrivalDate, $departureDate);
        $status = 'free';

        $resultPosting = $this->db->query('select id from checkin where id = "' . $checkin['id'] . '" ');
        $rPosting = $resultPosting->row_array();

        if(isset($checkin['id']) && $resultPosting->num_rows() > 0)
        {
            $result = $this->db->query("select DATE_FORMAT(checkin_date,'%Y-%m-%d') as checkin_date
                                        from checkin_dates where checkin_id = '" . $checkin['id'] . "' ");
            $resArray = $result->result_array();
            $resArray = $this->createCheckInDatesArray($resArray);
            foreach ($daysArray as $key => $row)
            {
                if (!in_array($row, $resArray))
                {
                    $statusCheckin = $this->checkCheckinRoomWithReservation($row, $checkin['roomno']);
                    if($statusCheckin == "checkin")
                    {
                        $status = "checkin";
                    }
                }
            }
        }
        else
        {
            if ($checkin['resid'] != "" && $checkin['resid'] != "0")
            {
                $result = $this->db->query("select DATE_FORMAT(reservation_date,'%Y-%m-%d') as reservation_date
                                        from reservation_dates where resid = '" . $checkin['resid'] . "' ");
                $resArray = $result->result_array();
                $resArray = $this->createDatesArray($resArray);
                foreach ($daysArray as $key => $row)
                {
                    if (!in_array($row, $resArray))
                    {
                        $status = $this->checkReservedRoomWithReservation($row, $checkin['roomno']);
                        if ($status == "free")
                        {
                            $statusCheckin = $this->checkCheckinRoomWithReservation($row, $checkin['roomno']);
                            if($statusCheckin == "checkin")
                            {
                                $status = "checkin";
                            }
                        }
                    }
                    else
                    {
                        $statusCheckin = $this->checkCheckinRoomWithReservation($row, $checkin['roomno']);
                        if($statusCheckin == "checkin")
                        {
                            $status = "checkin";
                        }
                    }
                }
            }
            else
            {
                $result = $this->db->query("select * from checkin where id = '" . $checkin['id'] . "' ");
                if ($result->num_rows() == 0)
                {
                    $status = $this->checkReservedRoom($daysArray, $checkin['roomno']);
                    if ($status == 'free')
                    {
                        $status = $this->checkCheckInRoom($daysArray, $checkin['roomno']);
                    }
                }
                else
                {
                    $result = $this->db->query("select DATE_FORMAT(checkin_date,'%Y-%m-%d') as checkin_date
                                        from checkin_dates where checkin_id = '" . $checkin['id'] . "' ");
                    $resArray = $result->result_array();
                    $resArray = $this->createCheckInDatesArray($resArray);
                    foreach ($daysArray as $key => $row)
                    {
                        if (!in_array($row, $resArray))
                        {
                            $status = $this->checkReservedRoomWithReservation($row, $checkin['roomno']);
                            if ($status == "free")
                            {
                                $statusCheckin = $this->checkCheckinRoomWithReservation($row, $checkin['roomno']);
                                if($statusCheckin == "checkin")
                                {
                                    $status = "checkin";
                                }
                            }
                        }
                    }
                }
            }
        }

        $roomDirtyStatus = $this->checkRoomDirtyStatus($checkin['roomno']);
        if($roomDirtyStatus == "dirty")
        {
            $status = "dirty";
        }
        return $status;
    }

    public function checkRoomDirtyStatus($roomId)
    {
        $status = 'free';
        $result = $this->db->query("SELECT * from dirty_rooms where roomno = '" . $roomId . "'");
        if ($result->num_rows() > 0)
        {
            $status = 'dirty';
        }
        return $status;
    }

    public function checkReservedRoom($daysArray, $roomId)
    {
        $status = "free";
        foreach ($daysArray as $key => $row)
        {
            $result = $this->db->query("SELECT * from reservation_dates
                                      where reservation_date = '" . $row . "' and roomId = '" . $roomId . "'");
            if ($result->num_rows() > 0)
            {
                $status = 'reserved';
            }
        }
        return $status;
    }

    public function checkCheckInRoom($daysArray, $roomId)
    {
        $status = "free";
        foreach ($daysArray as $key => $row)
        {
            $result = $this->db->query("SELECT * from checkin_dates
                                      where checkin_date = '" . $row . "' and roomno = '" . $roomId . "'");
            if ($result->num_rows() > 0)
            {
                $status = 'checkin';
            }
        }
        return $status;
    }

    public function checkReservedRoomWithReservation($reservationDate, $roomId)
    {
        $status = 'free';
        $result = $this->db->query("SELECT * from reservation_dates
                                  where reservation_date = '" . $reservationDate . "' and roomId = '" . $roomId . "'");
        if ($result->num_rows() > 0)
        {
            $status = 'reserved';
        }
        return $status;
    }

    public function checkCheckinRoomWithReservation($reservationDate, $roomId)
    {
        $status = 'free';
        $result = $this->db->query("SELECT * from checkin_dates
                              where checkin_date = '" . $reservationDate . "' and roomno = '" . $roomId . "'");
        if ($result->num_rows() > 0)
        {
            $status = 'checkin';
        }
        return $status;
    }

    public function createDatesArray($datesArray)
    {
        $data = array();
        foreach ($datesArray as $key => $row)
        {
            $data[] = $row['reservation_date'];
        }
        return $data;
    }

    public function createCheckInDatesArray($datesArray)
    {
        $data = array();
        foreach ($datesArray as $key => $row)
        {
            $data[] = $row['checkin_date'];
        }
        return $data;
    }

    public function getDirtyStatus($roomId)
    {
        $status = '0';
        $result = $this->db->query("SELECT * from dirty_rooms
                              where roomno = '" . $roomId . "'");
        if ($result->num_rows() > 0)
        {
            $status = '1';
        }
        return $status;
    }
}