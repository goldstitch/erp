<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Minibars extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	function get_roomboy()
	{
		$sql=$this->db->get('waiter');
		return $sql->result_array();
	}
	function getroomno()
	{
		$sql=$this->db->get('rooms');
		return $sql->result_array(); 
	}
	function get_item()
	{
		$sql=$this->db->get('item');
		return $sql->result_array();
	}
	function getyear()
	{
		$sql="SELECT distinct year(vrdate) as year FROM `rsmain` order by vrdate desc";
		$query=$this->db->query($sql);

		if ($query->num_rows() > 0) {
			
			return $query->result_array();
		}
	}
	function getuser()
	{
		$sql=$this->db->get('user');
		return $sql->result_array();
	}
	public function getMaxId($etype) {

		$this->db->select_max('vrno');
		$this->db->where(array('etype' => $etype ));
		$result = $this->db->get('rsmain');

		$row = $result->row_array();
		$maxId = $row['vrno'];

		return $maxId;
	}
	public function fetchallcatogeoryromServices() {

			$result = $this->db->get('catogeory_roomservices');
			if ( $result->num_rows() === 0 ) {
				return false;
			} else {
				return $result->result_array();
			}
	}

    function save($saveMain,$saveDetail,$etype)
    	{
    		$this->db->select('stid');
			$this->db->where(array('vrno' => $saveMain['vrno'] ));
			$this->db->where(array('etype' => $etype ));

			$vrno = $this->db->get('rsmain');
			if ($vrno->num_rows() > 0) {
					$vrno = $vrno->row_array();

						$this->db->where(array('stid' => $vrno['stid'] ));
						$result = $this->db->get('rsmain');
						$affect = 0;
						if ($result->num_rows() > 0 ) {

							$this->db->where(array('stid' => $vrno['stid'] ));
							$affect 	= $this->db->update('rsmain',$saveMain);
							$this->db->delete('rsdetail', array('stid' => $vrno['stid'])); 
							foreach ($saveDetail as $sd) 
							{
								$sd['stid'] = $vrno['stid'];
								$this->db->insert('rsdetail',$sd);				
							}
						}
			// $vrnoa = $vrnoa->row_array();

			// $this->db->where(array('stid' => $vrnoa['stid'] ));
			// $result = $this->db->get('rsmain');
			// $affect = 0;
			// if ($result->num_rows() > 0 ) {

			// 	$this->db->where(array('stid' => $vrnoa['stid'] ));
			// 	$affect 	= $this->db->update('rsmain',$saveMain);
			// 	$this->db->delete('rsdetail', array('stid' => $vrnoa['stid'])); 
			// 	foreach ($saveDetail as $sd) 
			// 	{
			// 		$this->db->insert('rsdetail',$sd);				
			// 	}
			} else {
				$this->db->select('stid');
				$this->db->where(array('vrno' => $saveMain['vrno'] ));
				$vrno = $this->db->get('rsmain');
				$vrno = $vrno->row_array();
				unset($vrno['stid']);
				$this->db->insert('rsmain', $saveMain);
				$last_id	= $this->db->insert_id();
				foreach ($saveDetail as $sd)
				 {
				 	$sd['stid'] = $last_id;
					$this->db->insert('rsdetail',$sd);				
				 }
				$affect = $this->db->affected_rows();
			}


			if ( $affect === 0 ) {
				return false;
			} else {
				return true;
			}
    		/*
    		$this->db->select('vrno');
    		$this->db->where(array('vrno' => $saveMain['vrno'] ));
    		$this->db->where(array('etype' => 'miniBar' ));

    		$vrno = $this->db->get('rsmain');
    		if ($vrno->num_rows() > 0) {
    				$vrno = $vrno->row_array();

    					$this->db->where(array('vrno' => $vrno['vrno'] ));
    					$result = $this->db->get('rsmain');
    					$affect = 0;
    					if ($result->num_rows() > 0 ) {

    						$this->db->where(array('vrno' => $vrno['vrno'] ));
    						$affect 	= $this->db->update('rsmain',$saveMain);
    						$this->db->delete('rsdetail', array('vrno' => $vrno['vrno'])); 
    						foreach ($saveDetail as $sd) 
    						{
    							$sd['vrno'] = $vrno['vrno'];
    							$this->db->insert('rsdetail',$sd);				
    						}
    					}
    		
    		} else {
    			// get Max vrno
    			// $this->db->select('vrno');
    			// $this->db->where(array('vrno' => $saveMain['vrno'] ));
    			// $vrno = $this->db->get('rsmain');
    			// $vrno = $vrno->row_array();
    			// unset($vrno['vrno']);
    			$this->db->insert('rsmain', $saveMain);
    			$last_id	= $this->db->insert_id();
    			foreach ($saveDetail as $sd)
    			 {
    			 	// fid
    			 	$sd['vrno'] = $last_id;
    				$this->db->insert('rsdetail',$sd);				
    			 }
    			$affect = $this->db->affected_rows();
    		}


    		if ( $affect === 0 ) {
    			return false;
    		} else {
    			return true;
    		}*/
    	}
    public function savephoneslip( $saveMain,$etype ) {

		$this->db->where(array('vrno' => $saveMain['vrno'],'etype'=>$etype));
		$result = $this->db->get('rsmain');

		$affect = 0;
		if ($result->num_rows() > 0) {
			$id = $result->row_array();
			$i = $id['stid'];
			$this->db->where(array('stid' => $i ));
			$affect = $this->db->update('rsmain', $saveMain);
			// $affect = $this->db->affected_rows();
		} else {
			unset($saveMain['stid']);
			$result = $this->db->insert('rsmain', $saveMain);
			$affect = $this->db->affected_rows();
		}

		if ($affect === 0) {
			return false;
		} else {
			return true;
		}
	}

	public function fetchCheckin( $srno ) {

		$this->db->where(array('srno' => $srno));
		$result = $this->db->get('checkin');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}
	public function fetch_Enter( $vrno ,$etype) {

			//$sql 	= "SELECT * FROM rsmain m Inner join rsdetail d ON m.vrno = d.vrno WHERE m.vrno = $vrno AND etype = 'miniBar'";
			// $sql = "SELECT * FROM rsmain m 
			// 		Inner join rsdetail d ON m.vrno = d.vrno
			// 		inner join roomservicelist r on r.id=d.item_id
			// 		WHERE m.vrno = 1 AND etype = 'miniBar'";
			$sql = "SELECT *,m.amount AS mamount,i.item_des,m.discount as discounts,i.party_id_cr
					FROM rsmain m
					INNER JOIN rsdetail d ON m.stid = d.stid
					inner join item as i on i.id= d.item_id
					WHERE m.vrno = $vrno AND etype = '$etype' ";
			//$query 	= $this->db->query($sql);
			// if ($query->num_rows() != 0) {
			// 		return $query->result_array();
			// }
			$result =  $this->db->query($sql);
	    	if ( $result->num_rows() > 0 ) {
	    		return $result->result_array();
	    	} else {
	    		return false;
	    	}
	}
	public function fetch_telephoneslip( $vrno ,$etype) {

			$sql = "SELECT vrno,vrdate,etype,type,roomNo,gid,tamount,attentionmr,phoneno,city,country,contime,durminute,rate,operator
					FROM rsmain 
					WHERE vrno =$vrno AND etype = '".$etype."'; ";
			$query 	= $this->db->query($sql);
			if ($query->num_rows() > 0) {
				return $query->result_array();
			}
			else {
				return false;
			}
	}
	public function fetchGuestName( $roomid) {

		$sql = "select distinct c.gid from checkin c where c.roomno=$roomid ";
		$result	= $this->db->query($sql);
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}

	function fetch_model()
		{
			$sql 	= "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,						catogeory_roomservices.id as 'catid'
						FROM roomservicelist
						INNER JOIN catogeory_roomservices
						ON roomservicelist.cat_romId =catogeory_roomservices.id;";
			$query 	= $this->db->query($sql);
			if ($query->num_rows() != 0) {
					return $query->result_array();
			}
		}
	public function fetchDetailedVoucher( $vrno, $etype )
	{
		$query = $this->db->query("SELECT *,m.amount AS mamount,i.item_des,m.discount as discounts
									FROM rsmain m
									INNER JOIN rsdetail d ON m.stid = d.stid
									inner join item i on i.id=d.item_id 
									INNER JOIN waiter w ON w.id = m.roomboy
									INNER JOIN guest g ON g.id = m.gid
									WHERE m.vrno =$vrno AND etype = '".$etype."'");
		return $query->result_array();
	}
	function fetchParticulars($name)
		{
			 //$sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
			$sql = "SELECT id AS 'rslid',item_des as name,catagory as cat_romId,srate,party_id_cr
					FROM item
					WHERE catagory IN (
					SELECT catid
					FROM itemcategory
					WHERE name LIKE '$name')" ;
			$query 	= $this->db->query($sql);
			if ($query->num_rows() != 0) {
					return $query->result_array();
			}
		}
	function fetchParticularsAll()
		{
			 $sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
			//$sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId in (select id from catogeory_roomservices where name like '$name')" ;
			$query 	= $this->db->query($sql);
			if ($query->num_rows() != 0) {
					return $query->result_array();
			}
		}


	public function deleteCheckin( $srno ) {

		$this->db->where(array('srno' => $srno ));
		$result = $this->db->get('checkin');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$this->db->where(array('srno' => $srno ));
			$result = $this->db->delete('checkin');

			return true;
		}
	}

	public function delete($vrno,$etype,$company_id) {

		$this->db->where(array('etype' => $etype, 'dcno' => $vrno , 'company_id' => $company_id ));
        $this->db->delete('pledger');

		$this->db->where(array('vrno' => $vrno,'etype'=>$etype ));
		$result = $this->db->get('rsmain');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$result = $result->row_array();
			$stid = $result['stid'];
			$this->db->where(array('vrno' => $vrno,'etype'=>$etype ));
			$result = $this->db->delete('rsmain');
			$this->db->where(array('stid' => $stid ));
			$result = $this->db->delete('rsdetail');

			return true;
		}
	}

	function fetchallGuest()
	{
		$sql 	= "select distinct c.gid as id,g.guestName,c.roomno,g.partyid from checkin c inner join guest g on c.gid = g.id where c.status='checkin'";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}
	function fetchallGuests()
	{
		$sql 	= "SELECT id,guestName,partyid from guest";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
			return $query->result_array();
		}
	}

	public function fetchByCol($col) {
		$result = $this->db->query("SELECT DISTINCT $col FROM rsmain WHERE $col <> ''");
		return $result->result_array();
	}
}

/* End of file checkins.php */
/* Location: ./application/models/checkins.php */