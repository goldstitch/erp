<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Roomtransfers extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function getMaxRoomTransferId() {

		$this->db->select_max('dcno');
		$result = $this->db->get('room_transfer_main');

		$row = $result->row_array();
		$maxId = $row['dcno'];

		return $maxId;
	}

    public function save($saveMain,$saveDetail)
	{

		$this->db->select('room_transfer_id');
		$this->db->where(array('dcno' => $saveMain['dcno'] ));
		//$this->db->where(array('etype' => $etype ));

		$dcno = $this->db->get('room_transfer_main');

		if ($dcno->num_rows() > 0) {
			$dcno = $dcno->row_array();
			//die(print($dcno));
			$this->db->where(array('room_transfer_id' => $dcno['room_transfer_id'] ));
			$result = $this->db->get('room_transfer_main');
			$affect = 0;
			if ($result->num_rows() > 0 ) {

				$this->db->where(array('room_transfer_id' => $dcno['room_transfer_id'] ));
				$affect 	= $this->db->update('room_transfer_main',$saveMain);
				$this->db->delete('room_transfer_detail', array('room_transfer_id' => $dcno['room_transfer_id'])); 
				foreach ($saveDetail as $sd) 
				{
					$sd['room_transfer_id'] = $dcno['room_transfer_id'];
					$this->db->insert('room_transfer_detail',$sd);				
				}
			}
		
		} else {
			$this->db->select('room_transfer_id');
			$this->db->where(array('dcno' => $saveMain['dcno'] ));
			$dcno = $this->db->get('room_transfer_main');
			$dcno = $dcno->row_array();
			unset($dcno['room_transfer_id']);
			$this->db->insert('room_transfer_main', $saveMain);
			$last_id	= $this->db->insert_id();
			foreach ($saveDetail as $sd)
			 {
			 	$sd['room_transfer_id'] = $last_id;
				$this->db->insert('room_transfer_detail',$sd);				
			 }
			$affect = $this->db->affected_rows();
			$this->addDirtyRooms('1',$saveMain['roomno_from'],'2');
			// Total Previous Balance
			$pre_amount = $this->db->query("select pre_amount from checkin where id = '".$saveMain['checkinid']."'");
			$pre_amount = $pre_amount->row();
	        $pre_amount = $pre_amount->pre_amount;
			$tot_pre_amount = $pre_amount + $saveMain['total'];
			
			// Total Previous Complementry
			$complementry = $this->db->query("select complementry from checkin where id = '".$saveMain['checkinid']."'");
			$complementry = $complementry->row();
	        $complementry = $complementry->complementry;
			$tot_complementry = $complementry + $saveMain['complementry'];


			$this->updateRoomNoCheckin('1',$saveMain['roomno_to'],$saveMain['checkinid'],$tot_complementry,$tot_pre_amount);
			$this->updateRoomNoCheckinDates('1',$saveMain['roomno_to'],$saveMain['checkinid']);
		}
		
		if ( $affect === 0 ) {
			return false;
		} else {
			return true;
		}
	}

    public function deteleCheckInDates($checkInId)
    {
        $this->db->query("delete from checkin_dates where checkin_id = '" . $checkInId . "'");
        $result = $this->db->query('select * from checkin
                                    where id = "' . $checkInId . '"');
        $result = $result->result_array();
        if (count($result) > 0)
        {
            $resId = $result[0]['resid'];
            if($resId != "0")
            {
                $this->db->query("delete from reservation_dates where resId = '" . $resId . "'");
            }
        }
    }
    public function addDirtyRooms($affect,$roomno,$status)
    {
    	if ($affect > 0) {
    		$this->db->query("insert into dirty_rooms (roomno, room_status_id)
                                      values ('" . $roomno . "', '" . $status . "')");
    	}
    }
    public function updateRoomNoCheckin($affect,$roomno,$checkin,$complementry,$pre_amount)
    {
    	if ($affect > 0) {
    		$this->db->query("update checkin set roomno = '".$roomno."',pre_amount='".$pre_amount."',complementry= '".$complementry."' where id = '".$checkin."' ");
    	}
    }
    public function updateRoomNoCheckinDates($affect,$roomno,$checkin)
    {
    	if ($affect > 0) {
    		$this->db->query("update checkin_dates set roomno = '".$roomno."' where checkin_id = '".$checkin."' ");
    	}
    }

    public function fetch( $dcno ) {

    	$sql = "SELECT p.name partyname,m.arrival_date,m.dep_date,m.address,m.roomno_from,m.roomno_to,
				 m.gid,g.guestName,m.party_id,m.total,m.checkinid,m.dcno,d.date,d.bedtax,
				 d.rent,d.telephone,d.bedtax,d.extrabed,d.minibar,d.misc,d.food,d.laundary,d.totald,m.vrdate,r.room
				FROM room_transfer_main m
				INNER JOIN room_transfer_detail d ON d.room_transfer_id = m.room_transfer_id
				INNER JOIN party p ON p.id = m.party_id
				INNER JOIN guest g ON g.id = m.gid
				INNER JOIN rooms r ON r.id = m.roomno_from
				WHERE m.dcno =".$dcno;

    	$result =  $this->db->query($sql);
    	if ( $result->num_rows() > 0 ) {
    		return $result->result_array();
    	} else {
    		return false;
    	}
    }
        public function fetchCompelmentary( $roomno,$vrdate ) {

        	$sql = "SELECT IFNULL(sum(tamount),0) AS amount
					FROM rsmain r
					WHERE TYPE = 'Complementary' AND roomNo =$roomno AND 
					vrdate BETWEEN '$vrdate' AND r.vrdate";
        	$result =  $this->db->query($sql);
        	if ( $result->num_rows() > 0 ) {
        		$result= $result->result_array();
        		$amount = $result[0]['amount'];
        		return $amount;
        	} else {
        		return false;
        	}
        }


	public function fetchCheckin( $srno ) {

		$this->db->where(array('srno' => $srno));
		$result = $this->db->get('checkin');
		if ( $result->num_rows() > 0 ) {
			return $result->row_array();
		} else {
			return false;
		}
	}
	public function fetch_checkRoomNo( $id ) {

		$sql = "SELECT ch.arrivaldate,ch.departuredate,ch.gid,g.guestName,ch.address,ch.cardno,ch.partyid,ch.advance,ch.roomno
				FROM checkin ch
				INNER JOIN party p ON p.id = ch.partyid
				INNER JOIN guest g ON g.id = ch.gid
				WHERE ch.id =$id";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}
	public function fetchNightData( $RoomNo ) {
		$sql = "SELECT ch.departuredate,ch.arrivaldate,ch.gid,g.guestName,ch.cardno,ch.address,pos.vrdate,pos.roomRate,pos.bedtaxA,pos.extraBedC,ch.partyid,p.name as party_name
				FROM posting pos
				INNER JOIN party p ON p.id = pos.Partyid
				INNER JOIN guest g ON g.id = pos.gid
				INNER JOIN checkin ch ON ch.id = pos.checkinID
				INNER JOIN rooms rom ON rom.id=pos.roomNo
				WHERE pos.roomNo= $RoomNo AND ch.status='checkin'
				GROUP BY pos.vrdate";
		$result =  $this->db->query($sql);
        $data = array();
		if ($result->num_rows() > 0)
        {	
        	$totals=0;
            foreach($result->result() as $row)
            {	
            	$minibaramount 	= $this->roomserviceCharges($RoomNo,'MiniBar',$row->vrdate);
            	$miscamount 	= $this->roomserviceCharges($RoomNo,'Miscalenious',$row->vrdate);
            	$foodamount 	= $this->roomserviceCharges($RoomNo,'Food',$row->vrdate);
            	$laundryamount 	= $this->roomserviceCharges($RoomNo,'Laundry',$row->vrdate);
            	$telephoneslip 	= $this->roomserviceCharges($RoomNo,'telephoneslip',$row->vrdate);
            	//echo $row->vrdate;
				$data[] = array(
                    'departuredate' => $row->departuredate,
                    'arrivaldate' 	=> $row->arrivaldate,
                    'guestid'		=> $row->gid,
                    'guestName' 	=> $row->guestName,
                    'cardno' 		=> $row->cardno,
                    'partyid' 		=> $row->partyid,
                    'partyname'		=> $row->party_name,
                    'address' 		=> $row->address,
                    'newvrdate' 	=> $row->vrdate,
                    'roomrent' 		=> $row->roomRate,
                    'bedtaxA' 		=> $row->bedtaxA, 
                    'extraBedC' 	=> $row->extraBedC,
                    'minibaramount' => $minibaramount,
                    'miscamount' 	=> $miscamount,
                    'foodamount' 	=> $foodamount,
                    'laundryamount' => $laundryamount,
                    'telephoneslip' => $telephoneslip,
                    'totals' 		=> $row->roomRate+$row->bedtaxA+$row->extraBedC+$minibaramount+$miscamount+$foodamount+$laundryamount+$telephoneslip
                );
			}
			return $data;
		}
		else {
			return false;
		}
	}
	public function roomserviceCharges($room,$etype,$vrdate ) {
		$sql = "SELECT IFNULL(SUM(r.tamount),0) AS amount,r.vrdate,r.roomno
				FROM rsmain r inner join posting p on p.roomno=r.roomNo
				WHERE r.etype='".$etype."' and p.roomno=$room and p.vrdate='$vrdate' and r.vrdate= '$vrdate' and r.`type`='Bill'
				GROUP BY r.vrdate,p.roomno";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() > 0)
        {
        	$result = $query->result_array() ;
        	$amount = $result[0]['amount'];
            return $amount;
    	}
		else {
			return 0;	
		}	
	}
	public function fetch_model(){
		$sql 	= "SELECT catogeory_roomservices.name 'catRomeNames',roomservicelist.*,								
					catogeory_roomservices.id as 'catid'
					FROM roomservicelist
					INNER JOIN catogeory_roomservices
					ON roomservicelist.cat_romId =catogeory_roomservices.id;";
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}
	public function fetchDetailedVoucher( $vrno, $etype )
	{
		$query = $this->db->query("SELECT *,r.name as itemName,m.amount as mamount  FROM rsmain m 
					Inner join rsdetail d ON m.stid = d.stid
					inner join roomservicelist r on r.id=d.item_id
					inner join waiter w on w.waiter_id = m.roomboy
					inner join guest g on g.gid = m.gid  
					WHERE m.vrno = $vrno AND etype = '$etype'");
		return $query->result_array();
	}
	function fetchParticulars($name){
		//$sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
		$sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId in (select id from catogeory_roomservices where name like '$name')" ;
		$query 	= $this->db->query($sql);
		if ($query->num_rows() != 0) {
				return $query->result_array();
		}
	}
	function fetchParticularsAll()
		{
			 $sql 	= "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId = 1;";
			//$sql = "SELECT id as 'rslid' ,name,cat_romId from roomservicelist  where cat_romId in (select id from catogeory_roomservices where name like '$name')" ;
			$query 	= $this->db->query($sql);
			if ($query->num_rows() != 0) {
					return $query->result_array();
			}
		}


	public function deleteCheckin( $srno ) {

		$this->db->where(array('srno' => $srno ));
		$result = $this->db->get('checkin');

		if ($result->num_rows() == 0) {
			return false;
		} else {
			$this->db->where(array('srno' => $srno ));
			$result = $this->db->delete('checkin');

			return true;
		}
	}

	public function delete( $dcno ){//, $company_id) {

		$this->db->where(array( 'dcno' => $dcno)); //, 'company_id' => 1 ));
		$result = $this->db->get('room_transfer_main');

		if ($result->num_rows() == 0) {
			return false;
		} else {

			$result = $result->row_array();
			$room_transfer_id = $result['room_transfer_id'];

			$this->db->where(array('dcno' => $dcno ));
			$this->db->delete('room_transfer_main');
			$this->db->where(array('room_transfer_id' => $room_transfer_id ));
			$this->db->delete('room_transfer_detail');

			return true;
		}
	}
}

/* End of file checkins.php */
/* Location: ./application/models/checkins.php */